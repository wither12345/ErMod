package net.mcreator.er.procedures;

import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.monster.Blaze;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleTypes;

import net.mcreator.er.init.ErModParticleTypes;
import net.mcreator.er.init.ErModAttributes;
import net.mcreator.er.EntityHurtEvent;

import javax.annotation.Nullable;

@EventBusSubscriber
public class EntityTickProcedure {
	@SubscribeEvent
	public static void onEntityTick(EntityTickEvent.Pre event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Blaze) {
			EntityHurtEvent.PyroMultiply(world, x, y, z, (LivingEntity) entity, entity, 500);
		} else if (entity instanceof LivingEntity && entity.isInWaterRainOrBubble()) {
			EntityHurtEvent.HydroMultiply(world, x, y, z, (LivingEntity) entity, entity, 50);
		}
		if (entity.getPersistentData().getInt("Cryo") > 0) {
			entity.getPersistentData().putInt("Cryo", entity.getPersistentData().getInt("Cryo") - 1);
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_CRYO.get()), x, (entity.getBbHeight() + 0.5 + y), z, 1, 0, 0, 0, 0);
		}
		if (entity.getPersistentData().getInt("Dendro") > 0) {
			entity.getPersistentData().putInt("Dendro", entity.getPersistentData().getInt("Dendro") - 1);
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_DENDRO.get()), x, (entity.getBbHeight() + 0.5 + y), z, 1, 0, 0, 0, 0);
		}
		if (entity.getPersistentData().getInt("Electro") > 0) {
			entity.getPersistentData().putInt("Electro", entity.getPersistentData().getInt("Electro") - 1);
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_ELECTRO.get()), x, (entity.getBbHeight() + 0.5 + y), z, 1, 0, 0, 0, 0);
		}
		if (entity.getPersistentData().getInt("Hydro") > 0) {
			entity.getPersistentData().putInt("Hydro", entity.getPersistentData().getInt("Hydro") - 1);
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_HYDRO.get()), x, (entity.getBbHeight() + 0.5 + y), z, 1, 0, 0, 0, 0);
		}
		if (entity.getPersistentData().getInt("Pyro") > 0) {
			if (entity.getPersistentData().getInt("Dendro") > 0) {
				entity.getPersistentData().putInt("Dendro", entity.getPersistentData().getInt("Dendro") - 1);
				if (entity.getPersistentData().getInt("Dendro") % 10 <= 1) {
					if (world instanceof ServerLevel _level)
						_level.sendParticles(ParticleTypes.FLAME, (x - entity.getBbWidth() / 2), y, (z - entity.getBbWidth() / 2), 10, (entity.getBbWidth()), (entity.getBbHeight()), (entity.getBbWidth()), 0);
					entity.hurt(new DamageSource(world.holderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction")))),
							(float) (0.5 * (1 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.PYRO_RES) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.PYRO_RES).getValue() : 10) / 100)
									* EntityHurtEvent.getElementalMasteryMultiply(1, ((LivingEntity) entity).getLastAttacker().getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue())));
				}
			} else {
				entity.getPersistentData().putInt("Pyro", entity.getPersistentData().getInt("Pyro") - 1);
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_PYRO.get()), x, (entity.getBbHeight() + 0.5 + y), z, 1, 0, 0, 0, 0);
		}
	}
}
