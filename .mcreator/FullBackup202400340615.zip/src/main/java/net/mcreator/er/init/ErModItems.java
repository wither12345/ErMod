
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.ItemProperties;

import net.mcreator.er.procedures.WoodenClubPropertyValueProviderProcedure;
import net.mcreator.er.procedures.RarityGemstone_CountProcedure;
import net.mcreator.er.procedures.ItemLevelProcedure;
import net.mcreator.er.procedures.HuntersBow_PullingProcedure;
import net.mcreator.er.item.WoodenClubItem;
import net.mcreator.er.item.WhiteIronChunkItem;
import net.mcreator.er.item.WasterGreatswordItem;
import net.mcreator.er.item.UnownedVisionItem;
import net.mcreator.er.item.TestStellaFortunaItem;
import net.mcreator.er.item.SunsettiaItem;
import net.mcreator.er.item.StainedMaskItem;
import net.mcreator.er.item.RarityGemstoneItem;
import net.mcreator.er.item.PyroVisionItem;
import net.mcreator.er.item.PyroSwordItem;
import net.mcreator.er.item.PyroPickaxeItem;
import net.mcreator.er.item.PyroHoeItem;
import net.mcreator.er.item.PyroArmorItem;
import net.mcreator.er.item.PolarStarItem;
import net.mcreator.er.item.OminousMaskItem;
import net.mcreator.er.item.MysticEnhancementOreItem;
import net.mcreator.er.item.MoraItem;
import net.mcreator.er.item.MoraBagItem;
import net.mcreator.er.item.MistFlowerCorollaItem;
import net.mcreator.er.item.MinorUpgradesItem;
import net.mcreator.er.item.MinorAffixShardItem;
import net.mcreator.er.item.MainAffixShardItem;
import net.mcreator.er.item.LuckyDogsSilverCircletItem;
import net.mcreator.er.item.LuckyDogsHourglassItem;
import net.mcreator.er.item.LuckyDogsGobletItem;
import net.mcreator.er.item.LuckyDogsEagleFeatherItem;
import net.mcreator.er.item.LuckyDogsCloverItem;
import net.mcreator.er.item.IronChunkItem;
import net.mcreator.er.item.HydroVisionItem;
import net.mcreator.er.item.HydroSwordItem;
import net.mcreator.er.item.HydroArmorItem;
import net.mcreator.er.item.HuntersBowItem;
import net.mcreator.er.item.GeoVisionItem;
import net.mcreator.er.item.GeoSwordItem;
import net.mcreator.er.item.GeoPickaxeItem;
import net.mcreator.er.item.GeoArmorItem;
import net.mcreator.er.item.FlamingFlowerStamenItem;
import net.mcreator.er.item.FineEnhancementOreItem;
import net.mcreator.er.item.EnhancementOreItem;
import net.mcreator.er.item.ElectroVisionItem;
import net.mcreator.er.item.ElectroSwordItem;
import net.mcreator.er.item.ElectroHoeItem;
import net.mcreator.er.item.ElectroCrystalItem;
import net.mcreator.er.item.ElectroArmorItem;
import net.mcreator.er.item.DullBladeItem;
import net.mcreator.er.item.DendroVisionItem;
import net.mcreator.er.item.DendroSwordItem;
import net.mcreator.er.item.DendroArmorItem;
import net.mcreator.er.item.DandelionSeedItem;
import net.mcreator.er.item.DamagedMaskItem;
import net.mcreator.er.item.CrystalCoreItem;
import net.mcreator.er.item.CrystalChunkItem;
import net.mcreator.er.item.CryoVisionItem;
import net.mcreator.er.item.CryoSwordItem;
import net.mcreator.er.item.CryoArmorItem;
import net.mcreator.er.item.CorLapisItem;
import net.mcreator.er.item.CondensedPyroItem;
import net.mcreator.er.item.CondensedHydroItem;
import net.mcreator.er.item.CondensedGeoItem;
import net.mcreator.er.item.CondensedElectroItem;
import net.mcreator.er.item.CondensedDendroItem;
import net.mcreator.er.item.CondensedCryoItem;
import net.mcreator.er.item.CondensedAnemoItem;
import net.mcreator.er.item.ArtifactItem;
import net.mcreator.er.item.AnemoVisionItem;
import net.mcreator.er.item.AnemoSwordItem;
import net.mcreator.er.item.AnemoArmorItem;
import net.mcreator.er.ErMod;

public class ErModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(ErMod.MODID);
	public static final DeferredItem<Item> MIST_FLOWER_SPAWN_EGG = REGISTRY.register("mist_flower_spawn_egg", () -> new DeferredSpawnEggItem(ErModEntities.MIST_FLOWER, -16711681, -6684673, new Item.Properties()));
	public static final DeferredItem<Item> FLAMING_FLOWER_SPAWN_EGG = REGISTRY.register("flaming_flower_spawn_egg", () -> new DeferredSpawnEggItem(ErModEntities.FLAMING_FLOWER, -65536, -39424, new Item.Properties()));
	public static final DeferredItem<Item> MIST_FLOWER_COROLLA = REGISTRY.register("mist_flower_corolla", MistFlowerCorollaItem::new);
	public static final DeferredItem<Item> FLAMING_FLOWER_STAMEN = REGISTRY.register("flaming_flower_stamen", FlamingFlowerStamenItem::new);
	public static final DeferredItem<Item> PYRO_ARMOR_HELMET = REGISTRY.register("pyro_armor_helmet", PyroArmorItem.Helmet::new);
	public static final DeferredItem<Item> PYRO_ARMOR_CHESTPLATE = REGISTRY.register("pyro_armor_chestplate", PyroArmorItem.Chestplate::new);
	public static final DeferredItem<Item> PYRO_ARMOR_LEGGINGS = REGISTRY.register("pyro_armor_leggings", PyroArmorItem.Leggings::new);
	public static final DeferredItem<Item> PYRO_ARMOR_BOOTS = REGISTRY.register("pyro_armor_boots", PyroArmorItem.Boots::new);
	public static final DeferredItem<Item> HUNTERS_BOW = REGISTRY.register("hunters_bow", HuntersBowItem::new);
	public static final DeferredItem<Item> CRYSTAL_CORE = REGISTRY.register("crystal_core", CrystalCoreItem::new);
	public static final DeferredItem<Item> ANEMO_CRYSTALFLY_SPAWN_EGG = REGISTRY.register("anemo_crystalfly_spawn_egg", () -> new DeferredSpawnEggItem(ErModEntities.ANEMO_CRYSTALFLY, -16718409, -16719617, new Item.Properties()));
	public static final DeferredItem<Item> CONDENSED_PYRO = REGISTRY.register("condensed_pyro", CondensedPyroItem::new);
	public static final DeferredItem<Item> MORA = REGISTRY.register("mora", MoraItem::new);
	public static final DeferredItem<Item> MORA_BAG = REGISTRY.register("mora_bag", MoraBagItem::new);
	public static final DeferredItem<Item> CONDENSED_CRYO = REGISTRY.register("condensed_cryo", CondensedCryoItem::new);
	public static final DeferredItem<Item> CRYO_ARMOR_HELMET = REGISTRY.register("cryo_armor_helmet", CryoArmorItem.Helmet::new);
	public static final DeferredItem<Item> CRYO_ARMOR_CHESTPLATE = REGISTRY.register("cryo_armor_chestplate", CryoArmorItem.Chestplate::new);
	public static final DeferredItem<Item> CRYO_ARMOR_LEGGINGS = REGISTRY.register("cryo_armor_leggings", CryoArmorItem.Leggings::new);
	public static final DeferredItem<Item> CRYO_ARMOR_BOOTS = REGISTRY.register("cryo_armor_boots", CryoArmorItem.Boots::new);
	public static final DeferredItem<Item> CRYO_SWORD = REGISTRY.register("cryo_sword", CryoSwordItem::new);
	public static final DeferredItem<Item> PYRO_SWORD = REGISTRY.register("pyro_sword", PyroSwordItem::new);
	public static final DeferredItem<Item> POLAR_STAR = REGISTRY.register("polar_star", PolarStarItem::new);
	public static final DeferredItem<Item> TARTAGLIA_SPAWN_EGG = REGISTRY.register("tartaglia_spawn_egg", () -> new DeferredSpawnEggItem(ErModEntities.TARTAGLIA, -6724096, -16737793, new Item.Properties()));
	public static final DeferredItem<Item> UNOWNED_VISION = REGISTRY.register("unowned_vision", UnownedVisionItem::new);
	public static final DeferredItem<Item> TEST_STELLA_FORTUNA = REGISTRY.register("test_stella_fortuna", TestStellaFortunaItem::new);
	public static final DeferredItem<Item> PYRO_HOE = REGISTRY.register("pyro_hoe", PyroHoeItem::new);
	public static final DeferredItem<Item> PYRO_PICKAXE = REGISTRY.register("pyro_pickaxe", PyroPickaxeItem::new);
	public static final DeferredItem<Item> ELECTRO_CRYSTAL_ORE = block(ErModBlocks.ELECTRO_CRYSTAL_ORE);
	public static final DeferredItem<Item> ELECTRO_CRYSTAL = REGISTRY.register("electro_crystal", ElectroCrystalItem::new);
	public static final DeferredItem<Item> CONDENSED_ELECTRO = REGISTRY.register("condensed_electro", CondensedElectroItem::new);
	public static final DeferredItem<Item> ELECTRO_ARMOR_HELMET = REGISTRY.register("electro_armor_helmet", ElectroArmorItem.Helmet::new);
	public static final DeferredItem<Item> ELECTRO_ARMOR_CHESTPLATE = REGISTRY.register("electro_armor_chestplate", ElectroArmorItem.Chestplate::new);
	public static final DeferredItem<Item> ELECTRO_ARMOR_LEGGINGS = REGISTRY.register("electro_armor_leggings", ElectroArmorItem.Leggings::new);
	public static final DeferredItem<Item> ELECTRO_ARMOR_BOOTS = REGISTRY.register("electro_armor_boots", ElectroArmorItem.Boots::new);
	public static final DeferredItem<Item> SUMERU_ROSE = block(ErModBlocks.SUMERU_ROSE);
	public static final DeferredItem<Item> ELECTRO_SWORD = REGISTRY.register("electro_sword", ElectroSwordItem::new);
	public static final DeferredItem<Item> ELECTRO_HOE = REGISTRY.register("electro_hoe", ElectroHoeItem::new);
	public static final DeferredItem<Item> DENDRO_ARMOR_HELMET = REGISTRY.register("dendro_armor_helmet", DendroArmorItem.Helmet::new);
	public static final DeferredItem<Item> DENDRO_ARMOR_CHESTPLATE = REGISTRY.register("dendro_armor_chestplate", DendroArmorItem.Chestplate::new);
	public static final DeferredItem<Item> DENDRO_ARMOR_LEGGINGS = REGISTRY.register("dendro_armor_leggings", DendroArmorItem.Leggings::new);
	public static final DeferredItem<Item> DENDRO_ARMOR_BOOTS = REGISTRY.register("dendro_armor_boots", DendroArmorItem.Boots::new);
	public static final DeferredItem<Item> DENDRO_SWORD = REGISTRY.register("dendro_sword", DendroSwordItem::new);
	public static final DeferredItem<Item> COR_LAPIS_ORE = block(ErModBlocks.COR_LAPIS_ORE);
	public static final DeferredItem<Item> COR_LAPIS = REGISTRY.register("cor_lapis", CorLapisItem::new);
	public static final DeferredItem<Item> CONDENSED_GEO = REGISTRY.register("condensed_geo", CondensedGeoItem::new);
	public static final DeferredItem<Item> GEO_ARMOR_HELMET = REGISTRY.register("geo_armor_helmet", GeoArmorItem.Helmet::new);
	public static final DeferredItem<Item> GEO_ARMOR_CHESTPLATE = REGISTRY.register("geo_armor_chestplate", GeoArmorItem.Chestplate::new);
	public static final DeferredItem<Item> GEO_ARMOR_LEGGINGS = REGISTRY.register("geo_armor_leggings", GeoArmorItem.Leggings::new);
	public static final DeferredItem<Item> GEO_ARMOR_BOOTS = REGISTRY.register("geo_armor_boots", GeoArmorItem.Boots::new);
	public static final DeferredItem<Item> GEO_SWORD = REGISTRY.register("geo_sword", GeoSwordItem::new);
	public static final DeferredItem<Item> GEO_PICKAXE = REGISTRY.register("geo_pickaxe", GeoPickaxeItem::new);
	public static final DeferredItem<Item> DANDELION_SEED = REGISTRY.register("dandelion_seed", DandelionSeedItem::new);
	public static final DeferredItem<Item> CONDENSED_ANEMO = REGISTRY.register("condensed_anemo", CondensedAnemoItem::new);
	public static final DeferredItem<Item> CONDENSED_DENDRO = REGISTRY.register("condensed_dendro", CondensedDendroItem::new);
	public static final DeferredItem<Item> ANEMO_ARMOR_HELMET = REGISTRY.register("anemo_armor_helmet", AnemoArmorItem.Helmet::new);
	public static final DeferredItem<Item> ANEMO_ARMOR_CHESTPLATE = REGISTRY.register("anemo_armor_chestplate", AnemoArmorItem.Chestplate::new);
	public static final DeferredItem<Item> ANEMO_ARMOR_LEGGINGS = REGISTRY.register("anemo_armor_leggings", AnemoArmorItem.Leggings::new);
	public static final DeferredItem<Item> ANEMO_ARMOR_BOOTS = REGISTRY.register("anemo_armor_boots", AnemoArmorItem.Boots::new);
	public static final DeferredItem<Item> ANEMO_SWORD = REGISTRY.register("anemo_sword", AnemoSwordItem::new);
	public static final DeferredItem<Item> LOTUS_HEAD = block(ErModBlocks.LOTUS_HEAD);
	public static final DeferredItem<Item> CONDENSED_HYDRO = REGISTRY.register("condensed_hydro", CondensedHydroItem::new);
	public static final DeferredItem<Item> HYDRO_ARMOR_HELMET = REGISTRY.register("hydro_armor_helmet", HydroArmorItem.Helmet::new);
	public static final DeferredItem<Item> HYDRO_ARMOR_CHESTPLATE = REGISTRY.register("hydro_armor_chestplate", HydroArmorItem.Chestplate::new);
	public static final DeferredItem<Item> HYDRO_ARMOR_LEGGINGS = REGISTRY.register("hydro_armor_leggings", HydroArmorItem.Leggings::new);
	public static final DeferredItem<Item> HYDRO_ARMOR_BOOTS = REGISTRY.register("hydro_armor_boots", HydroArmorItem.Boots::new);
	public static final DeferredItem<Item> HYDRO_SWORD = REGISTRY.register("hydro_sword", HydroSwordItem::new);
	public static final DeferredItem<Item> MAIN_AFFIX_SHARD = REGISTRY.register("main_affix_shard", MainAffixShardItem::new);
	public static final DeferredItem<Item> MINOR_AFFIX_SHARD = REGISTRY.register("minor_affix_shard", MinorAffixShardItem::new);
	public static final DeferredItem<Item> RARITY_GEMSTONE = REGISTRY.register("rarity_gemstone", RarityGemstoneItem::new);
	public static final DeferredItem<Item> MINOR_UPGRADES = REGISTRY.register("minor_upgrades", MinorUpgradesItem::new);
	public static final DeferredItem<Item> ELEMENT_ANVIL = block(ErModBlocks.ELEMENT_ANVIL);
	public static final DeferredItem<Item> LUCKY_DOGS_CLOVER = REGISTRY.register("lucky_dogs_clover", LuckyDogsCloverItem::new);
	public static final DeferredItem<Item> ARTIFACT = REGISTRY.register("artifact", ArtifactItem::new);
	public static final DeferredItem<Item> LUCKY_DOGS_EAGLE_FEATHER = REGISTRY.register("lucky_dogs_eagle_feather", LuckyDogsEagleFeatherItem::new);
	public static final DeferredItem<Item> LUCKY_DOGS_HOURGLASS = REGISTRY.register("lucky_dogs_hourglass", LuckyDogsHourglassItem::new);
	public static final DeferredItem<Item> LUCKY_DOGS_GOBLET = REGISTRY.register("lucky_dogs_goblet", LuckyDogsGobletItem::new);
	public static final DeferredItem<Item> LUCKY_DOGS_SILVER_CIRCLET = REGISTRY.register("lucky_dogs_silver_circlet", LuckyDogsSilverCircletItem::new);
	public static final DeferredItem<Item> DULL_BLADE = REGISTRY.register("dull_blade", DullBladeItem::new);
	public static final DeferredItem<Item> WASTER_GREATSWORD = REGISTRY.register("waster_greatsword", WasterGreatswordItem::new);
	public static final DeferredItem<Item> IRON_CHUNK = REGISTRY.register("iron_chunk", IronChunkItem::new);
	public static final DeferredItem<Item> WHITE_IRON_CHUNK = REGISTRY.register("white_iron_chunk", WhiteIronChunkItem::new);
	public static final DeferredItem<Item> WHITE_IRON_ORE = block(ErModBlocks.WHITE_IRON_ORE);
	public static final DeferredItem<Item> DEEPSLATE_WHITE_IRON_ORE = block(ErModBlocks.DEEPSLATE_WHITE_IRON_ORE);
	public static final DeferredItem<Item> CRYSTAL_CHUNK = REGISTRY.register("crystal_chunk", CrystalChunkItem::new);
	public static final DeferredItem<Item> MYSTIC_ENHANCEMENT_ORE = REGISTRY.register("mystic_enhancement_ore", MysticEnhancementOreItem::new);
	public static final DeferredItem<Item> FINE_ENHANCEMENT_ORE = REGISTRY.register("fine_enhancement_ore", FineEnhancementOreItem::new);
	public static final DeferredItem<Item> ENHANCEMENT_ORE = REGISTRY.register("enhancement_ore", EnhancementOreItem::new);
	public static final DeferredItem<Item> BURNING_DIRT = block(ErModBlocks.BURNING_DIRT);
	public static final DeferredItem<Item> PYRO_VISION = REGISTRY.register("pyro_vision", PyroVisionItem::new);
	public static final DeferredItem<Item> ANEMO_VISION = REGISTRY.register("anemo_vision", AnemoVisionItem::new);
	public static final DeferredItem<Item> CRYO_VISION = REGISTRY.register("cryo_vision", CryoVisionItem::new);
	public static final DeferredItem<Item> HYDRO_VISION = REGISTRY.register("hydro_vision", HydroVisionItem::new);
	public static final DeferredItem<Item> ELECTRO_VISION = REGISTRY.register("electro_vision", ElectroVisionItem::new);
	public static final DeferredItem<Item> DENDRO_VISION = REGISTRY.register("dendro_vision", DendroVisionItem::new);
	public static final DeferredItem<Item> GEO_VISION = REGISTRY.register("geo_vision", GeoVisionItem::new);
	public static final DeferredItem<Item> HILICHURL_SPAWN_EGG = REGISTRY.register("hilichurl_spawn_egg", () -> new DeferredSpawnEggItem(ErModEntities.HILICHURL, -13421773, -6780581, new Item.Properties()));
	public static final DeferredItem<Item> WOODEN_CLUB = REGISTRY.register("wooden_club", WoodenClubItem::new);
	public static final DeferredItem<Item> CRATE = block(ErModBlocks.CRATE);
	public static final DeferredItem<Item> CUIHUA_LOG = block(ErModBlocks.CUIHUA_LOG);
	public static final DeferredItem<Item> CUIHUA_LEAVES = block(ErModBlocks.CUIHUA_LEAVES);
	public static final DeferredItem<Item> CUIHUA_SAPLING = block(ErModBlocks.CUIHUA_SAPLING);
	public static final DeferredItem<Item> CUIHUA_PLANKS = block(ErModBlocks.CUIHUA_PLANKS);
	public static final DeferredItem<Item> CUIHUA_STAIRS = block(ErModBlocks.CUIHUA_STAIRS);
	public static final DeferredItem<Item> CUIHUA_SLAB = block(ErModBlocks.CUIHUA_SLAB);
	public static final DeferredItem<Item> CUIHUA_FENCE = block(ErModBlocks.CUIHUA_FENCE);
	public static final DeferredItem<Item> CUIHUA_FENCE_GATE = block(ErModBlocks.CUIHUA_FENCE_GATE);
	public static final DeferredItem<Item> DAMAGED_MASK = REGISTRY.register("damaged_mask", DamagedMaskItem::new);
	public static final DeferredItem<Item> STAINED_MASK = REGISTRY.register("stained_mask", StainedMaskItem::new);
	public static final DeferredItem<Item> OMINOUS_MASK = REGISTRY.register("ominous_mask", OminousMaskItem::new);
	public static final DeferredItem<Item> SUNSETTIA = REGISTRY.register("sunsettia", SunsettiaItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ItemsClientSideHandler {
		@SubscribeEvent
		@OnlyIn(Dist.CLIENT)
		public static void clientLoad(FMLClientSetupEvent event) {
			event.enqueueWork(() -> {
				ItemProperties.register(HUNTERS_BOW.get(), ResourceLocation.parse("er:hunters_bow_pulling"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) HuntersBow_PullingProcedure.execute(itemStackToRender));
				ItemProperties.register(POLAR_STAR.get(), ResourceLocation.parse("er:polar_star_pulling"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) HuntersBow_PullingProcedure.execute(itemStackToRender));
				ItemProperties.register(RARITY_GEMSTONE.get(), ResourceLocation.parse("er:rarity_gemstone_item_count"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) RarityGemstone_CountProcedure.execute(itemStackToRender));
				ItemProperties.register(DULL_BLADE.get(), ResourceLocation.parse("er:dull_blade_level"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) ItemLevelProcedure.execute(itemStackToRender));
				ItemProperties.register(WASTER_GREATSWORD.get(), ResourceLocation.parse("er:waster_greatsword_level"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) ItemLevelProcedure.execute(itemStackToRender));
				ItemProperties.register(WOODEN_CLUB.get(), ResourceLocation.parse("er:wooden_club_pyro"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) WoodenClubPropertyValueProviderProcedure.execute(itemStackToRender));
			});
		}
	}
}
