package net.mcreator.er.procedures;

import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.entity.projectile.windcharge.WindCharge;
import net.minecraft.world.entity.projectile.windcharge.BreezeWindCharge;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Stray;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.monster.Blaze;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.er.network.ErModVariables;
import net.mcreator.er.init.ErModItems;
import net.mcreator.er.init.ErModAttributes;
import net.mcreator.er.entity.TartagliaEntity;
import net.mcreator.er.entity.MistFlowerEntity;
import net.mcreator.er.entity.FlamingFlowerEntity;

import javax.annotation.Nullable;

@EventBusSubscriber
public class EntitySpawnProcedure {
	@SubscribeEvent
	public static void onEntitySpawned(EntityJoinLevelEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Projectile) {
			if (((Projectile) entity).getOwner() instanceof Stray) {
				entity.getPersistentData().putDouble("Element", 2);
			}
			if (((Projectile) entity).getOwner() instanceof TartagliaEntity) {
				entity.getPersistentData().putDouble("Element", 6);
			} else if (entity instanceof WindCharge || entity instanceof BreezeWindCharge) {
				entity.getPersistentData().putDouble("Element", 1);
			} else if (entity instanceof Arrow && ((Projectile) entity).getOwner() instanceof Player) {
				if (((Projectile) entity).getOwner().getData(ErModVariables.PLAYER_VARIABLES).Vision.getItem() == ErModItems.ANEMO_VISION.get()) {
					entity.getPersistentData().putDouble("Element", 1);
				} else if (((Projectile) entity).getOwner().getData(ErModVariables.PLAYER_VARIABLES).Vision.getItem() == ErModItems.CRYO_VISION.get()) {
					entity.getPersistentData().putDouble("Element", 2);
				} else if (((Projectile) entity).getOwner().getData(ErModVariables.PLAYER_VARIABLES).Vision.getItem() == ErModItems.DENDRO_VISION.get()) {
					entity.getPersistentData().putDouble("Element", 3);
				} else if (((Projectile) entity).getOwner().getData(ErModVariables.PLAYER_VARIABLES).Vision.getItem() == ErModItems.ELECTRO_VISION.get()) {
					entity.getPersistentData().putDouble("Element", 4);
				} else if (((Projectile) entity).getOwner().getData(ErModVariables.PLAYER_VARIABLES).Vision.getItem() == ErModItems.GEO_VISION.get()) {
					entity.getPersistentData().putDouble("Element", 5);
				} else if (((Projectile) entity).getOwner().getData(ErModVariables.PLAYER_VARIABLES).Vision.getItem() == ErModItems.HYDRO_VISION.get()) {
					entity.getPersistentData().putDouble("Element", 6);
				} else if (((Projectile) entity).getOwner().getData(ErModVariables.PLAYER_VARIABLES).Vision.getItem() == ErModItems.PYRO_VISION.get()) {
					entity.getPersistentData().putDouble("Element", 7);
				}
			}
			if (entity instanceof SmallFireball || entity instanceof LargeFireball) {
				entity.getPersistentData().putDouble("Element", 7);
			}
		} else if (entity instanceof EnderMan) {
			if (entity instanceof LivingEntity _livingEntity27 && _livingEntity27.getAttributes().hasAttribute(ErModAttributes.HYDRO_RES))
				_livingEntity27.getAttribute(ErModAttributes.HYDRO_RES).setBaseValue((-100));
		} else if (entity instanceof Blaze || entity instanceof FlamingFlowerEntity) {
			if (entity instanceof LivingEntity _livingEntity30 && _livingEntity30.getAttributes().hasAttribute(ErModAttributes.PYRO_RES))
				_livingEntity30.getAttribute(ErModAttributes.PYRO_RES).setBaseValue(200);
		} else if (entity instanceof MistFlowerEntity) {
			if (entity instanceof LivingEntity _livingEntity32 && _livingEntity32.getAttributes().hasAttribute(ErModAttributes.CRYO_RES))
				_livingEntity32.getAttribute(ErModAttributes.CRYO_RES).setBaseValue(200);
		} else if (entity instanceof Stray) {
			if (entity instanceof LivingEntity _livingEntity34 && _livingEntity34.getAttributes().hasAttribute(ErModAttributes.CRYO_RES))
				_livingEntity34.getAttribute(ErModAttributes.CRYO_RES).setBaseValue(25);
		}
	}
}
