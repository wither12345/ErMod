package net.mcreator.er.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.particles.SimpleParticleType;

import net.mcreator.er.init.ErModParticleTypes;

public class AnemoTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double front = 0;
		world.addParticle((SimpleParticleType) (ErModParticleTypes.P_ANEMO.get()), x, (y + entity.getBbHeight() + 0.5), z, 0, 0, 0);
	}
}
