/**
 * The code of this mod element is always locked.
 *
 * You can register new events in this class too.
 *
 * If you want to make a plain independent class, create it using
 * Project Browser -> New... and make sure to make the class
 * outside net.mcreator.er as this package is managed by MCreator.
 *
 * If you change workspace package, modid or prefix, you will need
 * to manually adapt this file to these changes or remake it.
 *
 * This class will be added in the mod root package.
*/
package net.mcreator.er;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.ItemProperties;

import net.mcreator.er.init.ErModItems;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ItemAttrSet {
	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	private static class GlobalTrigger {
		@SubscribeEvent
		public static void propertyOverrideRegistry(FMLClientSetupEvent event) {
			//event.enqueueWork(() -> {
			//	ItemPropertyFunction CMDF = (itemStack , world , entity , amount) -> { //customModelDataFunction
			//		return itemStack.getOrCreateTag().getInt("custom_model_data");
			//	};
			//	ItemProperties.register(ErModItems.HUNTERS_BOW.get(), new ResourceLocation("custom_model_data"), CMDF);
			//});
			event.enqueueWork(() -> {
				ItemProperties.register(
					ErModItems.HUNTERS_BOW.get(), new ResourceLocation("pull"), (p_174635_, p_174636_, p_174637_, p_174638_) -> {
						if (p_174637_ == null) {
							return 0;
						} 
						else {
							return p_174637_.getUseItem() != p_174635_ ? 0 : (p_174635_.getOrCreateTag().getInt("custom_model_data"));
						}
					}
				);
			});
				
		}
	}
}
