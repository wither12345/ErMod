
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import net.mcreator.er.ErMod;

public class ErModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, ErMod.MODID);
	public static final RegistryObject<SimpleParticleType> P_CRYO = REGISTRY.register("p_cryo", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> P_ANEMO = REGISTRY.register("p_anemo", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> P_DENDRO = REGISTRY.register("p_dendro", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> P_ELECTRO = REGISTRY.register("p_electro", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> P_GEO = REGISTRY.register("p_geo", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> P_HYDRO = REGISTRY.register("p_hydro", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> P_PYRO = REGISTRY.register("p_pyro", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> P_DENDRO_EXPLOSION = REGISTRY.register("p_dendro_explosion", () -> new SimpleParticleType(false));
}
