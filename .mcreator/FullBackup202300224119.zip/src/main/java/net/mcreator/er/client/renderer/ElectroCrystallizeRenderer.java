
package net.mcreator.er.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.er.entity.ElectroCrystallizeEntity;
import net.mcreator.er.client.model.ModelCrystallize;

public class ElectroCrystallizeRenderer extends MobRenderer<ElectroCrystallizeEntity, ModelCrystallize<ElectroCrystallizeEntity>> {
	public ElectroCrystallizeRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelCrystallize(context.bakeLayer(ModelCrystallize.LAYER_LOCATION)), 0.5f);
		this.addLayer(new EyesLayer<ElectroCrystallizeEntity, ModelCrystallize<ElectroCrystallizeEntity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("er:textures/entities/electro_crystallize.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(ElectroCrystallizeEntity entity) {
		return new ResourceLocation("er:textures/entities/electro_crystallize.png");
	}
}
