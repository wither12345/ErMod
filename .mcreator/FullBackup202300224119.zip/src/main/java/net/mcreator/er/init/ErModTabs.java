
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.CreativeModeTabEvent;

import net.minecraft.world.item.CreativeModeTabs;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ErModTabs {
	@SubscribeEvent
	public static void buildTabContentsVanilla(CreativeModeTabEvent.BuildContents tabData) {

		if (tabData.getTab() == CreativeModeTabs.COMBAT) {
			tabData.accept(ErModItems.PYRO_ARMOR_HELMET.get());
			tabData.accept(ErModItems.PYRO_ARMOR_CHESTPLATE.get());
			tabData.accept(ErModItems.PYRO_ARMOR_LEGGINGS.get());
			tabData.accept(ErModItems.PYRO_ARMOR_BOOTS.get());
			tabData.accept(ErModItems.HUNTERS_BOW.get());
			tabData.accept(ErModItems.CRYO_ARMOR_HELMET.get());
			tabData.accept(ErModItems.CRYO_ARMOR_CHESTPLATE.get());
			tabData.accept(ErModItems.CRYO_ARMOR_LEGGINGS.get());
			tabData.accept(ErModItems.CRYO_ARMOR_BOOTS.get());
		}

		if (tabData.getTab() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(ErModItems.MIST_FLOWER_SPAWN_EGG.get());
			tabData.accept(ErModItems.FLAMING_FLOWER_SPAWN_EGG.get());
			tabData.accept(ErModItems.ANEMO_CRYSTALFLY_SPAWN_EGG.get());
		}

		if (tabData.getTab() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(ErModItems.MIST_FLOWER_COROLLA.get());
			tabData.accept(ErModItems.FLAMING_FLOWER_STAMEN.get());
			tabData.accept(ErModItems.CRYSTAL_CORE.get());
			tabData.accept(ErModItems.CONDENSED_PYRO.get());
			tabData.accept(ErModItems.MORA.get());
			tabData.accept(ErModItems.MORA_BAG.get());
			tabData.accept(ErModItems.CONDENSED_CRYO.get());
		}
	}
}
