
package net.mcreator.er.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.er.entity.AnemoCrystalflyEntity;
import net.mcreator.er.client.model.ModelCrystalfly;

public class AnemoCrystalflyRenderer extends MobRenderer<AnemoCrystalflyEntity, ModelCrystalfly<AnemoCrystalflyEntity>> {
	public AnemoCrystalflyRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelCrystalfly(context.bakeLayer(ModelCrystalfly.LAYER_LOCATION)), 0.5f);
		this.addLayer(new EyesLayer<AnemoCrystalflyEntity, ModelCrystalfly<AnemoCrystalflyEntity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("er:textures/entities/anemo_crystalfly.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(AnemoCrystalflyEntity entity) {
		return new ResourceLocation("er:textures/entities/anemo_crystalfly.png");
	}
}
