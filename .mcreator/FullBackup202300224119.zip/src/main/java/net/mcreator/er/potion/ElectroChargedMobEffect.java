
package net.mcreator.er.potion;

import net.minecraftforge.client.extensions.common.IClientMobEffectExtensions;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.er.procedures.ElectroChargedDoProcedure;
import net.mcreator.er.procedures.ElectroChargedActiveProcedure;

public class ElectroChargedMobEffect extends MobEffect {
	public ElectroChargedMobEffect() {
		super(MobEffectCategory.HARMFUL, -6749953);
	}

	@Override
	public String getDescriptionId() {
		return "effect.er.electro_charged";
	}

	@Override
	public void applyEffectTick(LivingEntity entity, int amplifier) {
		ElectroChargedDoProcedure.execute(entity, amplifier);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return ElectroChargedActiveProcedure.execute(duration);
	}

	@Override
	public void initializeClient(java.util.function.Consumer<IClientMobEffectExtensions> consumer) {
		consumer.accept(new IClientMobEffectExtensions() {
			@Override
			public boolean isVisibleInGui(MobEffectInstance effect) {
				return false;
			}
		});
	}
}
