package net.mcreator.er.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModEnchantments;
import net.mcreator.er.init.ErModAttributes;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class EntityAttackProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingHurtEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level, event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity(), event.getSource().getEntity(), event.getAmount());
		}
	}

	public static double execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity, double amount) {
		return execute(null, world, x, y, z, entity, sourceentity, amount);
	}

	private static double execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity, double amount) {
		if (entity == null || sourceentity == null)
			return 0;
		double multiply = 0;
		if (sourceentity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(ErModMobEffects.ELEMENT_BAN.get())) {
			return 1;
		}
		multiply = 1;
		if (((LivingEntity) entity).getAbsorptionAmount() > 0) {
			multiply = 1 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.SHIELDSTRENGTH.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.SHIELDSTRENGTH.get()).getValue() : 10)
					/ ((entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.SHIELDSTRENGTH.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.SHIELDSTRENGTH.get()).getValue() : 10) + 100);
		}
		if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.CRYO_INFUSION_ENCHANTMENT.get(), (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)) != 0) {
			return multiply * CryoMultiplyProcedure.execute(world, x, y, z, entity, sourceentity);
		} else if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.DENDRO_INFUSION_ENCHANTMENT.get(), (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)) != 0) {
			return multiply * DendroMultiplyProcedure.execute(world, x, y, z, entity, sourceentity, amount);
		} else if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.ELECTRO_INFUSION_ENCHANTMENT.get(), (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)) != 0) {
			return multiply * ElectroMultiplyProcedure.execute(world, x, y, z, entity, sourceentity, amount);
		} else if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.GEO_INFUSION_ENCHANTMENT.get(), (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)) != 0) {
			return multiply * GeoMultiplyProcedure.execute(world, x, y, z, entity, sourceentity);
		} else if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.HYDRO_INFUSION_ENCHANTMENT.get(), (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)) != 0) {
			return multiply * HydroMultiplyProcedure.execute(entity, sourceentity);
		} else if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.ANEMO_INFUSION_ENCHANTMENT.get(), (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)) != 0) {
			return multiply * AnemoMultiplyProcedure.execute(world, x, y, z, entity, sourceentity, amount);
		} else if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.PYRO_INFUSION_ENCHANTMENT.get(), (sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)) != 0) {
			return multiply * PyroMultiplyProcedure.execute(world, x, y, z, entity, sourceentity);
		}
		return multiply;
	}
}
