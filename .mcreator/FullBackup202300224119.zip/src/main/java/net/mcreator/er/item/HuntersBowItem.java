
package net.mcreator.er.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.network.chat.Component;

import net.mcreator.er.procedures.HuntersBow_DoProcedure;
import net.minecraft.world.item.BowItem;

public class HuntersBowItem extends BowItem {
	public HuntersBowItem() {
		super(new Item.Properties().durability(384).rarity(Rarity.COMMON));
	}

	@Override
	public UseAnim getUseAnimation(ItemStack itemstack) {
		return UseAnim.BOW;
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level world, Player entity, InteractionHand hand) {
		entity.startUsingItem(hand);
		return new InteractionResultHolder(InteractionResult.SUCCESS, entity.getItemInHand(hand));
	}


	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 72000;
	}
	

	
	@Override
	public void releaseUsing(ItemStack itemstack, Level world, LivingEntity entity, int time) {
		HuntersBow_DoProcedure.execute(world , entity, itemstack , time);
	}
	public void onUseTick (Level world, LivingEntity entity, ItemStack stack ,int time){
		if(time > 71992)
			stack.getOrCreateTag().putInt("custom_model_data", 1) ;
		else if(time > 71984)
			stack.getOrCreateTag().putInt("custom_model_data", 2) ;
		else
			stack.getOrCreateTag().putInt("custom_model_data", 3) ;

	}
	
}

