
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.er.world.inventory.MoraBagGUIMenu;
import net.mcreator.er.ErMod;

public class ErModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, ErMod.MODID);
	public static final RegistryObject<MenuType<MoraBagGUIMenu>> MORA_BAG_GUI = REGISTRY.register("mora_bag_gui", () -> IForgeMenuType.create(MoraBagGUIMenu::new));
}
