/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLConstructModEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeModificationEvent;

import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.EntityType;

import net.mcreator.er.ErMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ErModAttributes {
	public static final DeferredRegister<Attribute> ATTRIBUTES = DeferredRegister.create(ForgeRegistries.ATTRIBUTES, ErMod.MODID);
	public static final RegistryObject<Attribute> CIRTCHANCE = ATTRIBUTES.register("cirt_chance", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".cirt_chance", 5, 0, 200)).setSyncable(true));
	public static final RegistryObject<Attribute> CIRTDAMAGE = ATTRIBUTES.register("cirt_damage", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".cirt_damage", 0, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> ELEMENTALMASTERY = ATTRIBUTES.register("elemental_mastery", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".elemental_mastery", 0, 0, 32768)).setSyncable(true));
	public static final RegistryObject<Attribute> ENERGYRECHARGE = ATTRIBUTES.register("energy_recharge", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".energy_recharge", 100, 0, 1024)).setSyncable(true));
	public static final RegistryObject<Attribute> SHIELDSTRENGTH = ATTRIBUTES.register("shield_strength", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".shield_strength", 0, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> ANEMODMGBONUS = ATTRIBUTES.register("anemo_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".anemo_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> CRYODMGBONUS = ATTRIBUTES.register("cryo_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".cryo_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> DENDRODMGBONUS = ATTRIBUTES.register("dendro_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".dendro_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> ELECTRODMGBONUS = ATTRIBUTES.register("electro_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".electro_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> GEODMGBONUS = ATTRIBUTES.register("geo_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".geo_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> HYDRODMGBONUS = ATTRIBUTES.register("hydro_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".hydro_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> PYRODMGBONUS = ATTRIBUTES.register("pyro_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".pyro_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> PHYSICALDMGBONUS = ATTRIBUTES.register("physical_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".physical_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> ANEMORES = ATTRIBUTES.register("anemo_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".anemo_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> CRYORES = ATTRIBUTES.register("cryo_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".cryo_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> DENDRORES = ATTRIBUTES.register("dendro_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".dendro_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> ELECTRORES = ATTRIBUTES.register("electro_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".electro_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> GEORES = ATTRIBUTES.register("geo_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".geo_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> HYDRORES = ATTRIBUTES.register("hydro_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".hydro_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> PYRORES = ATTRIBUTES.register("pyro_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".pyro_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> PHYSICALRES = ATTRIBUTES.register("physical_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".physical_res", 0, 0, 100)).setSyncable(true));

	@SubscribeEvent
	public static void register(FMLConstructModEvent event) {
		event.enqueueWork(() -> {
			ATTRIBUTES.register(FMLJavaModLoadingContext.get().getModEventBus());
		});
	}

	@SubscribeEvent
	public static void addAttributes(EntityAttributeModificationEvent event) {
		event.add(EntityType.PLAYER, CIRTCHANCE.get());
		event.add(EntityType.PLAYER, CIRTDAMAGE.get());
		event.add(EntityType.PLAYER, ELEMENTALMASTERY.get());
		event.add(EntityType.PLAYER, ENERGYRECHARGE.get());
		event.add(EntityType.PLAYER, SHIELDSTRENGTH.get());
		event.add(EntityType.PLAYER, ANEMODMGBONUS.get());
		event.add(EntityType.PLAYER, CRYODMGBONUS.get());
		event.add(EntityType.PLAYER, DENDRODMGBONUS.get());
		event.add(EntityType.PLAYER, ELECTRODMGBONUS.get());
		event.add(EntityType.PLAYER, GEODMGBONUS.get());
		event.add(EntityType.PLAYER, HYDRODMGBONUS.get());
		event.add(EntityType.PLAYER, PYRODMGBONUS.get());
		event.add(EntityType.PLAYER, PHYSICALDMGBONUS.get());
		event.add(EntityType.PLAYER, ANEMORES.get());
		event.add(EntityType.PLAYER, CRYORES.get());
		event.add(EntityType.PLAYER, DENDRORES.get());
		event.add(EntityType.PLAYER, ELECTRORES.get());
		event.add(EntityType.PLAYER, GEORES.get());
		event.add(EntityType.PLAYER, HYDRORES.get());
		event.add(EntityType.PLAYER, PYRORES.get());
		event.add(EntityType.PLAYER, PHYSICALRES.get());
	}
}
