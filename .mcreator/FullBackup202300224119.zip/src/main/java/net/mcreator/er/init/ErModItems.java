
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;

import net.mcreator.er.item.PyroArmorItem;
import net.mcreator.er.item.MoraItem;
import net.mcreator.er.item.MoraBagItem;
import net.mcreator.er.item.MistFlowerCorollaItem;
import net.mcreator.er.item.HuntersBowItem;
import net.mcreator.er.item.FlamingFlowerStamenItem;
import net.mcreator.er.item.CrystalCoreItem;
import net.mcreator.er.item.CryoArmorItem;
import net.mcreator.er.item.CondensedPyroItem;
import net.mcreator.er.item.CondensedCryoItem;
import net.mcreator.er.ErMod;

public class ErModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ErMod.MODID);
	public static final RegistryObject<Item> MIST_FLOWER_SPAWN_EGG = REGISTRY.register("mist_flower_spawn_egg", () -> new ForgeSpawnEggItem(ErModEntities.MIST_FLOWER, -16711681, -6684673, new Item.Properties()));
	public static final RegistryObject<Item> FLAMING_FLOWER_SPAWN_EGG = REGISTRY.register("flaming_flower_spawn_egg", () -> new ForgeSpawnEggItem(ErModEntities.FLAMING_FLOWER, -65536, -39424, new Item.Properties()));
	public static final RegistryObject<Item> MIST_FLOWER_COROLLA = REGISTRY.register("mist_flower_corolla", () -> new MistFlowerCorollaItem());
	public static final RegistryObject<Item> FLAMING_FLOWER_STAMEN = REGISTRY.register("flaming_flower_stamen", () -> new FlamingFlowerStamenItem());
	public static final RegistryObject<Item> PYRO_ARMOR_HELMET = REGISTRY.register("pyro_armor_helmet", () -> new PyroArmorItem.Helmet());
	public static final RegistryObject<Item> PYRO_ARMOR_CHESTPLATE = REGISTRY.register("pyro_armor_chestplate", () -> new PyroArmorItem.Chestplate());
	public static final RegistryObject<Item> PYRO_ARMOR_LEGGINGS = REGISTRY.register("pyro_armor_leggings", () -> new PyroArmorItem.Leggings());
	public static final RegistryObject<Item> PYRO_ARMOR_BOOTS = REGISTRY.register("pyro_armor_boots", () -> new PyroArmorItem.Boots());
	public static final RegistryObject<Item> HUNTERS_BOW = REGISTRY.register("hunters_bow", () -> new HuntersBowItem());
	public static final RegistryObject<Item> CRYSTAL_CORE = REGISTRY.register("crystal_core", () -> new CrystalCoreItem());
	public static final RegistryObject<Item> ANEMO_CRYSTALFLY_SPAWN_EGG = REGISTRY.register("anemo_crystalfly_spawn_egg", () -> new ForgeSpawnEggItem(ErModEntities.ANEMO_CRYSTALFLY, -16718409, -16719617, new Item.Properties()));
	public static final RegistryObject<Item> CONDENSED_PYRO = REGISTRY.register("condensed_pyro", () -> new CondensedPyroItem());
	public static final RegistryObject<Item> MORA = REGISTRY.register("mora", () -> new MoraItem());
	public static final RegistryObject<Item> MORA_BAG = REGISTRY.register("mora_bag", () -> new MoraBagItem());
	public static final RegistryObject<Item> CONDENSED_CRYO = REGISTRY.register("condensed_cryo", () -> new CondensedCryoItem());
	public static final RegistryObject<Item> CRYO_ARMOR_HELMET = REGISTRY.register("cryo_armor_helmet", () -> new CryoArmorItem.Helmet());
	public static final RegistryObject<Item> CRYO_ARMOR_CHESTPLATE = REGISTRY.register("cryo_armor_chestplate", () -> new CryoArmorItem.Chestplate());
	public static final RegistryObject<Item> CRYO_ARMOR_LEGGINGS = REGISTRY.register("cryo_armor_leggings", () -> new CryoArmorItem.Leggings());
	public static final RegistryObject<Item> CRYO_ARMOR_BOOTS = REGISTRY.register("cryo_armor_boots", () -> new CryoArmorItem.Boots());
}
