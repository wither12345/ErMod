
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.er.client.particle.PPyroParticle;
import net.mcreator.er.client.particle.PHydroParticle;
import net.mcreator.er.client.particle.PGeoParticle;
import net.mcreator.er.client.particle.PElectroParticle;
import net.mcreator.er.client.particle.PDendroParticle;
import net.mcreator.er.client.particle.PDendroExplosionParticle;
import net.mcreator.er.client.particle.PCryoParticle;
import net.mcreator.er.client.particle.PAnemoParticle;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ErModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(ErModParticleTypes.P_CRYO.get(), PCryoParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.P_ANEMO.get(), PAnemoParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.P_DENDRO.get(), PDendroParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.P_ELECTRO.get(), PElectroParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.P_GEO.get(), PGeoParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.P_HYDRO.get(), PHydroParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.P_PYRO.get(), PPyroParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.P_DENDRO_EXPLOSION.get(), PDendroExplosionParticle::provider);
	}
}
