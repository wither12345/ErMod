
package net.mcreator.er.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.er.entity.PyroCrystallizeEntity;
import net.mcreator.er.client.model.ModelCrystallize;

public class PyroCrystallizeRenderer extends MobRenderer<PyroCrystallizeEntity, ModelCrystallize<PyroCrystallizeEntity>> {
	public PyroCrystallizeRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelCrystallize(context.bakeLayer(ModelCrystallize.LAYER_LOCATION)), 0.5f);
		this.addLayer(new EyesLayer<PyroCrystallizeEntity, ModelCrystallize<PyroCrystallizeEntity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("er:textures/entities/pyro_crystallize.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(PyroCrystallizeEntity entity) {
		return new ResourceLocation("er:textures/entities/pyro_crystallize.png");
	}
}
