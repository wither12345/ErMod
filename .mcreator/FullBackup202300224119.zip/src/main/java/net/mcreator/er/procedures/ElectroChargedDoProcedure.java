package net.mcreator.er.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.core.registries.Registries;

import net.mcreator.er.init.ErModAttributes;

public class ElectroChargedDoProcedure {
	public static void execute(Entity entity, double amplifier) {
		if (entity == null)
			return;
		{
			Entity _entToDamage = entity;
			_entToDamage.hurt(new DamageSource(_entToDamage.level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.LIGHTNING_BOLT)),
					(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) * (1 + 16 * (amplifier / (amplifier + 20))) * 0.1
							* (1 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.ELECTRORES.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.ELECTRORES.get()).getValue() : 10) / 100)));
		}
	}
}
