package net.mcreator.er.procedures;

import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.er.init.ErModMobEffects;
import net.minecraft.world.level.LevelAccessor;
import net.mcreator.er.init.ErModEntities;
import net.mcreator.er.init.ErModAttributes;
import net.mcreator.er.entity.BloomEntityEntity;

public class DendroMultiplyProcedure {
	public static double execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity, double amount){
		if (entity == null || sourceentity == null)
			return 0;
		double multiply = 0;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(ErModMobEffects.QUICKEN.get())) {
			multiply = 1 + (25 * ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
					? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
					: 100)
					/ ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
							? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
							: 100) + 1200)))
					/ amount;
		} else {
			multiply = 1;
		}
		if (entity instanceof LivingEntity _livEnt5 && _livEnt5.hasEffect(ErModMobEffects.INTERNAL_COOLDOWN.get())) {
			if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
				_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
		} else {
			if (entity instanceof LivingEntity _livEnt7 && _livEnt7.hasEffect(ErModMobEffects.HYDRO.get())) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new BloomEntityEntity(ErModEntities.BLOOM_ENTITY.get(), _level);
					entityToSpawn.getPersistentData().putString("UUID", sourceentity.getStringUUID());
					entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, _level.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					_level.addFreshEntity(entityToSpawn);
				}
			} else if (entity instanceof LivingEntity _livEnt9 && _livEnt9.hasEffect(ErModMobEffects.ELECTRO.get())) {
				if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.QUICKEN.get(), 200, 0));
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.ELECTRO.get());
			} else {
				if (entity instanceof LivingEntity _livEnt12 && _livEnt12.hasEffect(ErModMobEffects.PYRO.get())) {
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(ErModMobEffects.DENDRO.get(), 200, 0));
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(ErModMobEffects.PYRO.get(),
								(int) (200 + (entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ErModMobEffects.PYRO.get()) ? _livEnt.getEffect(ErModMobEffects.PYRO.get()).getDuration() : 0)),
								(int) ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
										? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
										: 100) / 100)));
				} else {
					if (entity instanceof LivingEntity _entity && !_entity.level.isClientSide())
						_entity.addEffect(new MobEffectInstance(ErModMobEffects.DENDRO.get(), 200, 0));
				}
			}
		}
		return multiply
				* ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.DENDRODMGBONUS.get()) != null ? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.DENDRODMGBONUS.get()).getValue() : 100) / 100)
				* ((100 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.DENDRORES.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.DENDRORES.get()).getValue() : 10)) / 100);
	}
}
