
package net.mcreator.er.enchantment;

import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.entity.EquipmentSlot;

import net.mcreator.er.init.ErModEnchantments;

import java.util.List;

public class DendroInfusionEnchantmentEnchantment extends Enchantment {
	public DendroInfusionEnchantmentEnchantment(EquipmentSlot... slots) {
		super(Enchantment.Rarity.VERY_RARE, EnchantmentCategory.WEAPON, slots);
	}

	@Override
	public int getMaxLevel() {
		return 3;
	}

	@Override
	protected boolean checkCompatibility(Enchantment ench) {
		return this != ench && !List.of(ErModEnchantments.ELECTRO_INFUSION_ENCHANTMENT.get(), ErModEnchantments.ANEMO_INFUSION_ENCHANTMENT.get(), ErModEnchantments.CRYO_INFUSION_ENCHANTMENT.get(), ErModEnchantments.GEO_INFUSION_ENCHANTMENT.get(),
				ErModEnchantments.HYDRO_INFUSION_ENCHANTMENT.get(), ErModEnchantments.PYRO_INFUSION_ENCHANTMENT.get()).contains(ench);
	}

	@Override
	public boolean isTreasureOnly() {
		return true;
	}
}
