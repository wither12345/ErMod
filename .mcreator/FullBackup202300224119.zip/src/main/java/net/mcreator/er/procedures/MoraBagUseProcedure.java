package net.mcreator.er.procedures;

import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;

import net.mcreator.er.init.ErModItems;

import java.util.concurrent.atomic.AtomicReference;
import java.util.Map;

public class MoraBagUseProcedure {
	public static void execute(LevelAccessor world, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		double count = 0;
		if (EnchantmentHelper.getItemEnchantmentLevel(Enchantments.UNBREAKING, itemstack) != 0) {
			{
				Map<Enchantment, Integer> _enchantments = EnchantmentHelper.getEnchantments(itemstack);
				if (_enchantments.containsKey(Enchantments.UNBREAKING)) {
					_enchantments.remove(Enchantments.UNBREAKING);
					EnchantmentHelper.setEnchantments(_enchantments, itemstack);
				}
			}
		}
		if (entity.isShiftKeyDown()) {
			{
				AtomicReference<IItemHandler> _iitemhandlerref = new AtomicReference<>();
				entity.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(_iitemhandlerref::set);
				if (_iitemhandlerref.get() != null) {
					for (int _idx = 0; _idx < _iitemhandlerref.get().getSlots(); _idx++) {
						ItemStack itemstackiterator = _iitemhandlerref.get().getStackInSlot(_idx).copy();
						if (itemstackiterator.getItem() == ErModItems.MORA.get()) {
							if (count + itemstackiterator.getCount() < itemstack.getDamageValue()) {
								count = count + itemstackiterator.getCount();
							} else {
								count = itemstack.getDamageValue();
							}
						}
					}
				}
			}
			if (entity instanceof Player _player) {
				ItemStack _stktoremove = new ItemStack(ErModItems.MORA.get());
				_player.getInventory().clearOrCountMatchingItems(p -> _stktoremove.getItem() == p.getItem(), (int) count, _player.inventoryMenu.getCraftSlots());
			}
			itemstack.setDamageValue((int) (itemstack.getDamageValue() - count));
		} else {
			if (itemstack.getMaxDamage() - itemstack.getDamageValue() > 64) {
				if (entity instanceof Player _player) {
					ItemStack _setstack = new ItemStack(ErModItems.MORA.get());
					_setstack.setCount(64);
					ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
				}
				{
					ItemStack _ist = itemstack;
					if (_ist.hurt(64, RandomSource.create(), null)) {
						_ist.shrink(1);
						_ist.setDamageValue(0);
					}
				}
			} else {
				if (entity instanceof Player _player) {
					ItemStack _setstack = new ItemStack(ErModItems.MORA.get());
					_setstack.setCount((int) ((itemstack.getMaxDamage() - itemstack.getDamageValue()) - 1));
					ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
				}
				{
					ItemStack _ist = itemstack;
					if (_ist.hurt((int) ((itemstack.getMaxDamage() - itemstack.getDamageValue()) - 1), RandomSource.create(), null)) {
						_ist.shrink(1);
						_ist.setDamageValue(0);
					}
				}
			}
		}
	}
}
