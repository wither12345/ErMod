package net.mcreator.er.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.ItemAttributeModifierEvent;

import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.EquipmentSlot;

import net.mcreator.er.init.ErModItems;
import net.mcreator.er.init.ErModEnchantments;
import net.mcreator.er.init.ErModAttributes;
import net.mcreator.er.ErMod;

import javax.annotation.Nullable;

import java.util.UUID;

@Mod.EventBusSubscriber
public class ItemAttrProcedure {
	@SubscribeEvent
	public static void addAttributeModifier(ItemAttributeModifierEvent event) {
		execute(event, event.getItemStack());
	}

	public static boolean execute(ItemStack itemstack) {
		return execute(null, itemstack);
	}

	private static boolean execute(@Nullable Event event, ItemStack itemstack) {
		if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.ANEMO_INFUSION_ENCHANTMENT.get(), itemstack) != 0) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.MAINHAND) {
				_event.addModifier(ErModAttributes.ANEMODMGBONUS.get(), (new AttributeModifier(UUID.fromString("4e82306f-1690-4d02-95b4-86563ac9d7b4"), ErMod.MODID + "." + "Anemo_Enchant",
						((itemstack.getEnchantmentLevel(ErModEnchantments.ANEMO_INFUSION_ENCHANTMENT.get()) - 1) * 20), AttributeModifier.Operation.ADDITION)));
			}
		} else if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.CRYO_INFUSION_ENCHANTMENT.get(), itemstack) != 0) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.MAINHAND) {
				_event.addModifier(ErModAttributes.CRYODMGBONUS.get(), (new AttributeModifier(UUID.fromString("4e82306f-1690-4d02-95b4-86563ac9d7b4"), ErMod.MODID + "." + "Cryo_Enchant",
						((itemstack.getEnchantmentLevel(ErModEnchantments.CRYO_INFUSION_ENCHANTMENT.get()) - 1) * 20), AttributeModifier.Operation.ADDITION)));
			}
		} else if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.DENDRO_INFUSION_ENCHANTMENT.get(), itemstack) != 0) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.MAINHAND) {
				_event.addModifier(ErModAttributes.DENDRODMGBONUS.get(), (new AttributeModifier(UUID.fromString("4e82306f-1690-4d02-95b4-86563ac9d7b4"), ErMod.MODID + "." + "Dendro_Enchant",
						((itemstack.getEnchantmentLevel(ErModEnchantments.DENDRO_INFUSION_ENCHANTMENT.get()) - 1) * 20), AttributeModifier.Operation.ADDITION)));
			}
		} else if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.ELECTRO_INFUSION_ENCHANTMENT.get(), itemstack) != 0) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.MAINHAND) {
				_event.addModifier(ErModAttributes.ELECTRODMGBONUS.get(), (new AttributeModifier(UUID.fromString("4e82306f-1690-4d02-95b4-86563ac9d7b4"), ErMod.MODID + "." + "Electro_Enchant",
						((itemstack.getEnchantmentLevel(ErModEnchantments.ELECTRO_INFUSION_ENCHANTMENT.get()) - 1) * 20), AttributeModifier.Operation.ADDITION)));
			}
		} else if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.GEO_INFUSION_ENCHANTMENT.get(), itemstack) != 0) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.MAINHAND) {
				_event.addModifier(ErModAttributes.GEODMGBONUS.get(), (new AttributeModifier(UUID.fromString("4e82306f-1690-4d02-95b4-86563ac9d7b4"), ErMod.MODID + "." + "Geo_Enchant",
						((itemstack.getEnchantmentLevel(ErModEnchantments.GEO_INFUSION_ENCHANTMENT.get()) - 1) * 20), AttributeModifier.Operation.ADDITION)));
			}
		} else if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.HYDRO_INFUSION_ENCHANTMENT.get(), itemstack) != 0) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.MAINHAND) {
				_event.addModifier(ErModAttributes.HYDRODMGBONUS.get(), (new AttributeModifier(UUID.fromString("4e82306f-1690-4d02-95b4-86563ac9d7b4"), ErMod.MODID + "." + "Hydro_Enchant",
						((itemstack.getEnchantmentLevel(ErModEnchantments.HYDRO_INFUSION_ENCHANTMENT.get()) - 1) * 20), AttributeModifier.Operation.ADDITION)));
			}
		} else if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.PYRO_INFUSION_ENCHANTMENT.get(), itemstack) != 0) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.MAINHAND) {
				_event.addModifier(ErModAttributes.PYRODMGBONUS.get(), (new AttributeModifier(UUID.fromString("4e82306f-1690-4d02-95b4-86563ac9d7b4"), ErMod.MODID + "." + "Pyro_Enchant",
						((itemstack.getEnchantmentLevel(ErModEnchantments.PYRO_INFUSION_ENCHANTMENT.get()) - 1) * 20), AttributeModifier.Operation.ADDITION)));
			}
		}
		if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.ELEMENTAL_MASTER.get(), itemstack) != 0) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.MAINHAND) {
				_event.addModifier(ErModAttributes.ELEMENTALMASTERY.get(), (new AttributeModifier(UUID.fromString("d0ca7956-9b7b-4b7d-9477-db08d83d60ae"), ErMod.MODID + "." + "Elemental_Master",
						(itemstack.getEnchantmentLevel(ErModEnchantments.ELEMENTAL_MASTER.get()) * 25), AttributeModifier.Operation.ADDITION)));
			}
		}
		if (EnchantmentHelper.getItemEnchantmentLevel(ErModEnchantments.HARD.get(), itemstack) != 0) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.CHEST) {
				_event.addModifier(ErModAttributes.SHIELDSTRENGTH.get(),
						(new AttributeModifier(UUID.fromString("edd5e66a-30d0-47a8-a66d-b0859b363d4a"), ErMod.MODID + "." + "Hard", (itemstack.getEnchantmentLevel(ErModEnchantments.HARD.get()) * 30), AttributeModifier.Operation.ADDITION)));
			}
		}
		if (itemstack.getItem() == ErModItems.PYRO_ARMOR_HELMET.get()) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.HEAD) {
				_event.addModifier(ErModAttributes.PYRORES.get(), (new AttributeModifier(UUID.fromString("05f5915f-9867-6ad2-a2ab-c1978f0e8051"), ErMod.MODID + "." + "hyro_armor", 10, AttributeModifier.Operation.ADDITION)));
			}
		} else if (itemstack.getItem() == ErModItems.PYRO_ARMOR_CHESTPLATE.get()) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.CHEST) {
				_event.addModifier(ErModAttributes.PYRORES.get(), (new AttributeModifier(UUID.fromString("af424956-a55e-608a-2539-3450a9759ccc"), ErMod.MODID + "." + "hyro_armor", 10, AttributeModifier.Operation.ADDITION)));
			}
		} else if (itemstack.getItem() == ErModItems.PYRO_ARMOR_LEGGINGS.get()) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.LEGS) {
				_event.addModifier(ErModAttributes.PYRORES.get(), (new AttributeModifier(UUID.fromString("f4905640-69d9-d047-b63c-fb596a5175d4"), ErMod.MODID + "." + "hyro_armor", 10, AttributeModifier.Operation.ADDITION)));
			}
		} else if (itemstack.getItem() == ErModItems.PYRO_ARMOR_BOOTS.get()) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.FEET) {
				_event.addModifier(ErModAttributes.PYRORES.get(), (new AttributeModifier(UUID.fromString("8055f14c-79cb-10fa-8f96-b86b6bd1ba44"), ErMod.MODID + "." + "hyro_armor", 10, AttributeModifier.Operation.ADDITION)));
			}
		} else if (itemstack.getItem() == ErModItems.CRYO_ARMOR_HELMET.get()) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.HEAD) {
				_event.addModifier(ErModAttributes.CRYORES.get(), (new AttributeModifier(UUID.fromString("05f5915f-1867-6cd2-a2ab-c1978f0e8051"), ErMod.MODID + "." + "cryo_armor", 10, AttributeModifier.Operation.ADDITION)));
			}
		} else if (itemstack.getItem() == ErModItems.CRYO_ARMOR_CHESTPLATE.get()) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.CHEST) {
				_event.addModifier(ErModAttributes.CRYORES.get(), (new AttributeModifier(UUID.fromString("af420f56-a55e-608a-2539-3450a9759c0c"), ErMod.MODID + "." + "cryo_armor", 10, AttributeModifier.Operation.ADDITION)));
			}
		} else if (itemstack.getItem() == ErModItems.CRYO_ARMOR_LEGGINGS.get()) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.LEGS) {
				_event.addModifier(ErModAttributes.CRYORES.get(), (new AttributeModifier(UUID.fromString("f4905640-69d9-d197-b63c-fb596a5175d4"), ErMod.MODID + "." + "cryo_armor", 10, AttributeModifier.Operation.ADDITION)));
			}
		} else if (itemstack.getItem() == ErModItems.CRYO_ARMOR_BOOTS.get()) {
			if (event instanceof ItemAttributeModifierEvent _event && _event.getSlotType() == EquipmentSlot.FEET) {
				_event.addModifier(ErModAttributes.CRYORES.get(), (new AttributeModifier(UUID.fromString("8055f14c-79cb-10fa-8f96-be1b6bd1ba44"), ErMod.MODID + "." + "cryo_armor", 10, AttributeModifier.Operation.ADDITION)));
			}
		}
		return true;
	}
}
