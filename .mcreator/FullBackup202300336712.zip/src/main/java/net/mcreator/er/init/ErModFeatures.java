
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.levelgen.feature.Feature;

import net.mcreator.er.world.features.plants.SumeruRoseFeature;
import net.mcreator.er.world.features.plants.LotusHeadFeature;
import net.mcreator.er.world.features.ores.ElectroCrystalOreFeature;
import net.mcreator.er.world.features.ores.CorLapisOreFeature;
import net.mcreator.er.ErMod;

@Mod.EventBusSubscriber
public class ErModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, ErMod.MODID);
	public static final RegistryObject<Feature<?>> SUMERU_ROSE = REGISTRY.register("sumeru_rose", SumeruRoseFeature::new);
	public static final RegistryObject<Feature<?>> ELECTRO_CRYSTAL_ORE = REGISTRY.register("electro_crystal_ore", ElectroCrystalOreFeature::new);
	public static final RegistryObject<Feature<?>> COR_LAPIS_ORE = REGISTRY.register("cor_lapis_ore", CorLapisOreFeature::new);
	public static final RegistryObject<Feature<?>> LOTUS_HEAD = REGISTRY.register("lotus_head", LotusHeadFeature::new);
}
