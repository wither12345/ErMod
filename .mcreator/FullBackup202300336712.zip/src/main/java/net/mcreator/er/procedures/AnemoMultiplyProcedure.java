package net.mcreator.er.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.core.registries.Registries;

import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModAttributes;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Comparator;

public class AnemoMultiplyProcedure {
	public static double execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity , double amount) {
		if (entity == null || sourceentity == null)
			return 0;
		double multiply = 0;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(ErModMobEffects.INTERNAL_COOLDOWN.get())) {
			return ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELECTRODMGBONUS.get()) != null ? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELECTRODMGBONUS.get()).getValue() : 100)
					/ 100) * ((100 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.ELECTRORES.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.ELECTRORES.get()).getValue() : 10)) / 100);
		}
		if (entity instanceof LivingEntity _livEnt5 && _livEnt5.hasEffect(ErModMobEffects.HYDRO.get())) {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELEMENT_BAN.get(), 10, 0, false, false));
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
						.collect(Collectors.toList());
				for (Entity entityiterator : _entfound) {
					if (sourceentity == entityiterator) {
						continue;
					}
					((LivingEntity) entityiterator).invulnerableTime = 0;
					entityiterator.hurt(new DamageSource(entityiterator.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.GENERIC), sourceentity),
							(float) (5 * HydroMultiplyProcedure.execute(world, x, y, z,entityiterator, sourceentity)));
					if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				}
			}
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(ErModMobEffects.HYDRO.get());
		} else if (entity instanceof LivingEntity _livEnt11 && _livEnt11.hasEffect(ErModMobEffects.CRYO.get())) {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELEMENT_BAN.get(), 10, 0, false, false));
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
						.collect(Collectors.toList());
				for (Entity entityiterator : _entfound) {
					if (sourceentity == entityiterator) {
						continue;
					}
					((LivingEntity) entityiterator).invulnerableTime = 0;
					entityiterator.hurt(new DamageSource(entityiterator.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.GENERIC), sourceentity),
							(float) (5 * CryoMultiplyProcedure.execute(world, x, y, z, entityiterator, sourceentity)));
					if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				}
			}
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(ErModMobEffects.CRYO.get());
		} else if (entity instanceof LivingEntity _livEnt17 && _livEnt17.hasEffect(ErModMobEffects.ELECTRO.get())) {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELEMENT_BAN.get(), 10, 0, false, false));
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
						.collect(Collectors.toList());
				for (Entity entityiterator : _entfound) {
					if (sourceentity == entityiterator) {
						continue;
					}
					((LivingEntity) entityiterator).invulnerableTime = 0;
					entityiterator.hurt(new DamageSource(entityiterator.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.GENERIC), sourceentity),
							(float) (5 * ElectroMultiplyProcedure.execute(world, x, y, z, entityiterator, sourceentity, amount)));
					if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				}
			}
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(ErModMobEffects.ELECTRO.get());
		} else if (entity instanceof LivingEntity _livEnt23 && _livEnt23.hasEffect(ErModMobEffects.PYRO.get())) {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELEMENT_BAN.get(), 10, 0, false, false));
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
						.collect(Collectors.toList());
				for (Entity entityiterator : _entfound) {
					if (sourceentity == entityiterator) {
						continue;
					}
					((LivingEntity) entityiterator).invulnerableTime = 0;
					entityiterator.hurt(new DamageSource(entityiterator.level().registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.GENERIC), sourceentity),
							(float) (5 * PyroMultiplyProcedure.execute(world, x, y, z, entityiterator, sourceentity)));
					if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				}
			}
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(ErModMobEffects.PYRO.get());
		}
		return ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ANEMODMGBONUS.get()) != null ? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ANEMODMGBONUS.get()).getValue() : 100) / 100)
				* ((100 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.ANEMORES.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.ANEMORES.get()).getValue() : 10)) / 100);
	}
}
