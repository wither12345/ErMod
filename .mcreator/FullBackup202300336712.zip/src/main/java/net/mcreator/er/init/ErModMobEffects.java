
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.er.potion.SuperconductMobEffect;
import net.mcreator.er.potion.QuickenMobEffect;
import net.mcreator.er.potion.PyroMobEffect;
import net.mcreator.er.potion.InternalCooldownMobEffect;
import net.mcreator.er.potion.HydroMobEffect;
import net.mcreator.er.potion.GeoMobEffect;
import net.mcreator.er.potion.FrozenMobEffect;
import net.mcreator.er.potion.ElementBanMobEffect;
import net.mcreator.er.potion.ElectroMobEffect;
import net.mcreator.er.potion.ElectroChargedMobEffect;
import net.mcreator.er.potion.DendroMobEffect;
import net.mcreator.er.potion.CrystallizeShieldMobEffect;
import net.mcreator.er.potion.CryoMobEffect;
import net.mcreator.er.potion.AnemoMobEffect;
import net.mcreator.er.ErMod;

public class ErModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, ErMod.MODID);
	public static final RegistryObject<MobEffect> ANEMO = REGISTRY.register("anemo", () -> new AnemoMobEffect());
	public static final RegistryObject<MobEffect> CRYO = REGISTRY.register("cryo", () -> new CryoMobEffect());
	public static final RegistryObject<MobEffect> DENDRO = REGISTRY.register("dendro", () -> new DendroMobEffect());
	public static final RegistryObject<MobEffect> ELECTRO = REGISTRY.register("electro", () -> new ElectroMobEffect());
	public static final RegistryObject<MobEffect> GEO = REGISTRY.register("geo", () -> new GeoMobEffect());
	public static final RegistryObject<MobEffect> HYDRO = REGISTRY.register("hydro", () -> new HydroMobEffect());
	public static final RegistryObject<MobEffect> PYRO = REGISTRY.register("pyro", () -> new PyroMobEffect());
	public static final RegistryObject<MobEffect> FROZEN = REGISTRY.register("frozen", () -> new FrozenMobEffect());
	public static final RegistryObject<MobEffect> QUICKEN = REGISTRY.register("quicken", () -> new QuickenMobEffect());
	public static final RegistryObject<MobEffect> INTERNAL_COOLDOWN = REGISTRY.register("internal_cooldown", () -> new InternalCooldownMobEffect());
	public static final RegistryObject<MobEffect> ELECTRO_CHARGED = REGISTRY.register("electro_charged", () -> new ElectroChargedMobEffect());
	public static final RegistryObject<MobEffect> SUPERCONDUCT = REGISTRY.register("superconduct", () -> new SuperconductMobEffect());
	public static final RegistryObject<MobEffect> CRYSTALLIZE_SHIELD = REGISTRY.register("crystallize_shield", () -> new CrystallizeShieldMobEffect());
	public static final RegistryObject<MobEffect> ELEMENT_BAN = REGISTRY.register("element_ban", () -> new ElementBanMobEffect());
}
