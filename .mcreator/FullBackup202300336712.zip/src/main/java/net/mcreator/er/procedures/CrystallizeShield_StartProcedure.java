package net.mcreator.er.procedures;

import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import java.util.UUID;

public class CrystallizeShield_StartProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		((LivingEntity) entity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE)
				.addTransientModifier((new AttributeModifier(UUID.fromString("547662BF-B275-9085-9829-17C8751E9F0E"), "knockback_res", 100, AttributeModifier.Operation.ADDITION)));
	}
}
