
package net.mcreator.er.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;

import net.mcreator.er.procedures.HuntersBow_DoProcedure;

public class PolarStarItem extends BowItem {
	public PolarStarItem() {
		super(new Item.Properties().durability(384).rarity(Rarity.COMMON));
	}

	@Override
	public UseAnim getUseAnimation(ItemStack itemstack) {
		return UseAnim.BOW;
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 72000;
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level world, Player entity, InteractionHand hand) {
		InteractionResultHolder<ItemStack> ar = super.use(world, entity, hand);
		ItemStack itemstack = ar.getObject();
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		entity.startUsingItem(hand);
		return ar;
	}

	public void onUseTick(Level world, LivingEntity entity, ItemStack stack, int time) {
		if (time > 71992)
			stack.getOrCreateTag().putInt("pulling", 1);
		else if (time > 71984)
			stack.getOrCreateTag().putInt("pulling", 2);
		else
			stack.getOrCreateTag().putInt("pulling", 3);
	}

	@Override
	public void releaseUsing(ItemStack itemstack, Level world, LivingEntity entity, int time) {
		HuntersBow_DoProcedure.execute(world, entity, itemstack, time);
	}
}
