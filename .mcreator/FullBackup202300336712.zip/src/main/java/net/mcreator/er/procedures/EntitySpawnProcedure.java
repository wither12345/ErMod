package net.mcreator.er.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;

import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.monster.Stray;
import net.minecraft.world.entity.Entity;

import net.mcreator.er.entity.TartagliaEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class EntitySpawnProcedure {
	@SubscribeEvent
	public static void onEntityJoin(EntityJoinLevelEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Projectile) {
			if (((Projectile) entity).getOwner() instanceof Stray) {
				entity.getPersistentData().putDouble("Element", 2);
			}
			if (((Projectile) entity).getOwner() instanceof TartagliaEntity) {
				entity.getPersistentData().putDouble("Element", 6);
			}
			if (entity instanceof SmallFireball || entity instanceof LargeFireball) {
				entity.getPersistentData().putDouble("Element", 7);
			}
		}
	}
}
