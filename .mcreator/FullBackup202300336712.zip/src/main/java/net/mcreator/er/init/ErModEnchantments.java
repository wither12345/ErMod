
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.er.enchantment.WealthEnchantment;
import net.mcreator.er.enchantment.PyroInfusionEnchantmentEnchantment;
import net.mcreator.er.enchantment.HydroInfusionEnchantmentEnchantment;
import net.mcreator.er.enchantment.HardEnchantment;
import net.mcreator.er.enchantment.GeoInfusionEnchantmentEnchantment;
import net.mcreator.er.enchantment.ElementalMasterEnchantment;
import net.mcreator.er.enchantment.ElectroInfusionEnchantmentEnchantment;
import net.mcreator.er.enchantment.DendroInfusionEnchantmentEnchantment;
import net.mcreator.er.enchantment.DeathBarterEnchantment;
import net.mcreator.er.enchantment.CryoInfusionEnchantmentEnchantment;
import net.mcreator.er.enchantment.AnemoInfusionEnchantmentEnchantment;
import net.mcreator.er.ErMod;

public class ErModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, ErMod.MODID);
	public static final RegistryObject<Enchantment> ELECTRO_INFUSION_ENCHANTMENT = REGISTRY.register("electro_infusion_enchantment", () -> new ElectroInfusionEnchantmentEnchantment());
	public static final RegistryObject<Enchantment> ANEMO_INFUSION_ENCHANTMENT = REGISTRY.register("anemo_infusion_enchantment", () -> new AnemoInfusionEnchantmentEnchantment());
	public static final RegistryObject<Enchantment> CRYO_INFUSION_ENCHANTMENT = REGISTRY.register("cryo_infusion_enchantment", () -> new CryoInfusionEnchantmentEnchantment());
	public static final RegistryObject<Enchantment> DENDRO_INFUSION_ENCHANTMENT = REGISTRY.register("dendro_infusion_enchantment", () -> new DendroInfusionEnchantmentEnchantment());
	public static final RegistryObject<Enchantment> GEO_INFUSION_ENCHANTMENT = REGISTRY.register("geo_infusion_enchantment", () -> new GeoInfusionEnchantmentEnchantment());
	public static final RegistryObject<Enchantment> HYDRO_INFUSION_ENCHANTMENT = REGISTRY.register("hydro_infusion_enchantment", () -> new HydroInfusionEnchantmentEnchantment());
	public static final RegistryObject<Enchantment> PYRO_INFUSION_ENCHANTMENT = REGISTRY.register("pyro_infusion_enchantment", () -> new PyroInfusionEnchantmentEnchantment());
	public static final RegistryObject<Enchantment> ELEMENTAL_MASTER = REGISTRY.register("elemental_master", () -> new ElementalMasterEnchantment());
	public static final RegistryObject<Enchantment> HARD = REGISTRY.register("hard", () -> new HardEnchantment());
	public static final RegistryObject<Enchantment> WEALTH = REGISTRY.register("wealth", () -> new WealthEnchantment());
	public static final RegistryObject<Enchantment> DEATH_BARTER = REGISTRY.register("death_barter", () -> new DeathBarterEnchantment());
}
