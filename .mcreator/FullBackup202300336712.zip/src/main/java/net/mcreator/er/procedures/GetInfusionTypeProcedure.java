package net.mcreator.er.procedures;

import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.Entity;

public class GetInfusionTypeProcedure {
	public static double execute(Entity entity, Entity immediatesourceentity) {
		if (entity == null)
			return 0;
		if (immediatesourceentity == entity) {
			if (IsAnemoInfusionProcedure.execute(entity)) {
				return 1;
			} else if (IsCryoInfusionProcedure.execute(entity)) {
				return 2;
			} else if (IsDendroInfusionProcedure.execute(entity)) {
				return 3;
			} else if (IsElectroInfusionProcedure.execute(entity)) {
				return 4;
			} else if (IsGeoInfusionProcedure.execute(entity)) {
				return 5;
			} else if (IsHydroInfusionProcedure.execute(entity)) {
				return 6;
			} else if (IsPyroInfusionProcedure.execute(entity)) {
				return 7;
			}
		} else {
			if (immediatesourceentity instanceof LargeFireball || immediatesourceentity instanceof SmallFireball) {
				return 7;
			} else {
				return immediatesourceentity.getPersistentData().getDouble("Element");
			}
		}
		return 0;
	}
}
