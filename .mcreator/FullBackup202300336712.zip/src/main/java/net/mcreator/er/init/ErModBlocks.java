
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.er.block.SumeruRoseBlock;
import net.mcreator.er.block.LotusHeadBlock;
import net.mcreator.er.block.ElectroCrystalOreBlock;
import net.mcreator.er.block.CorLapisOreBlock;
import net.mcreator.er.ErMod;

public class ErModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ErMod.MODID);
	public static final RegistryObject<Block> SUMERU_ROSE = REGISTRY.register("sumeru_rose", () -> new SumeruRoseBlock());
	public static final RegistryObject<Block> ELECTRO_CRYSTAL_ORE = REGISTRY.register("electro_crystal_ore", () -> new ElectroCrystalOreBlock());
	public static final RegistryObject<Block> COR_LAPIS_ORE = REGISTRY.register("cor_lapis_ore", () -> new CorLapisOreBlock());
	public static final RegistryObject<Block> LOTUS_HEAD = REGISTRY.register("lotus_head", () -> new LotusHeadBlock());
}
