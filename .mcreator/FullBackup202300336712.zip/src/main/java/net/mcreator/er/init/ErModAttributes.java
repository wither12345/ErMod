/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLConstructModEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeModificationEvent;

import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.ai.attributes.RangedAttribute;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.er.ErMod;

import java.util.List;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ErModAttributes {
	public static final DeferredRegister<Attribute> ATTRIBUTES = DeferredRegister.create(ForgeRegistries.ATTRIBUTES, ErMod.MODID);
	public static final RegistryObject<Attribute> ELEMENTALMASTERY = ATTRIBUTES.register("elemental_mastery", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".elemental_mastery", 0, 0, 32768)).setSyncable(true));
	public static final RegistryObject<Attribute> ENERGYRECHARGE = ATTRIBUTES.register("energy_recharge", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".energy_recharge", 100, 0, 1024)).setSyncable(true));
	public static final RegistryObject<Attribute> SHIELDSTRENGTH = ATTRIBUTES.register("shield_strength", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".shield_strength", 0, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> ANEMODMGBONUS = ATTRIBUTES.register("anemo_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".anemo_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> CRYODMGBONUS = ATTRIBUTES.register("cryo_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".cryo_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> DENDRODMGBONUS = ATTRIBUTES.register("dendro_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".dendro_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> ELECTRODMGBONUS = ATTRIBUTES.register("electro_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".electro_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> GEODMGBONUS = ATTRIBUTES.register("geo_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".geo_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> HYDRODMGBONUS = ATTRIBUTES.register("hydro_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".hydro_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> PYRODMGBONUS = ATTRIBUTES.register("pyro_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".pyro_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> PHYSICALDMGBONUS = ATTRIBUTES.register("physical_dmg_bonus", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".physical_dmg_bonus", 100, 0, 65536)).setSyncable(true));
	public static final RegistryObject<Attribute> ANEMORES = ATTRIBUTES.register("anemo_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".anemo_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> CRYORES = ATTRIBUTES.register("cryo_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".cryo_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> DENDRORES = ATTRIBUTES.register("dendro_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".dendro_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> ELECTRORES = ATTRIBUTES.register("electro_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".electro_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> GEORES = ATTRIBUTES.register("geo_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".geo_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> HYDRORES = ATTRIBUTES.register("hydro_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".hydro_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> PYRORES = ATTRIBUTES.register("pyro_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".pyro_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> PHYSICALRES = ATTRIBUTES.register("physical_res", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".physical_res", 0, 0, 100)).setSyncable(true));
	public static final RegistryObject<Attribute> CRITDAMAGE = ATTRIBUTES.register("crit_damage", () -> (new RangedAttribute("attribute." + ErMod.MODID + ".crit_damage", 50, 0, 1024)).setSyncable(true));

	@SubscribeEvent
	public static void register(FMLConstructModEvent event) {
		event.enqueueWork(() -> {
			ATTRIBUTES.register(FMLJavaModLoadingContext.get().getModEventBus());
		});
	}

	@SubscribeEvent
	public static void addAttributes(EntityAttributeModificationEvent event) {
		List<EntityType<? extends LivingEntity>> entityTypes = event.getTypes();
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Monster.class)) {
				event.add(e, ELEMENTALMASTERY.get());
			}
		});
		event.add(EntityType.PLAYER, ENERGYRECHARGE.get());
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Mob.class)) {
				event.add(e, SHIELDSTRENGTH.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Monster.class)) {
				event.add(e, ANEMODMGBONUS.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Monster.class)) {
				event.add(e, CRYODMGBONUS.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Monster.class)) {
				event.add(e, DENDRODMGBONUS.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Monster.class)) {
				event.add(e, ELECTRODMGBONUS.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Monster.class)) {
				event.add(e, GEODMGBONUS.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Monster.class)) {
				event.add(e, HYDRODMGBONUS.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Monster.class)) {
				event.add(e, PYRODMGBONUS.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Monster.class)) {
				event.add(e, PHYSICALDMGBONUS.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Mob.class)) {
				event.add(e, ANEMORES.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Mob.class)) {
				event.add(e, CRYORES.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Mob.class)) {
				event.add(e, DENDRORES.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Mob.class)) {
				event.add(e, ELECTRORES.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Mob.class)) {
				event.add(e, GEORES.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Mob.class)) {
				event.add(e, HYDRORES.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Mob.class)) {
				event.add(e, PYRORES.get());
			}
		});
		entityTypes.forEach((e) -> {
			Class<? extends Entity> baseClass = e.getBaseClass();
			if (baseClass.isAssignableFrom(Mob.class)) {
				event.add(e, PHYSICALRES.get());
			}
		});
		event.add(EntityType.PLAYER, CRITDAMAGE.get());
	}
}
