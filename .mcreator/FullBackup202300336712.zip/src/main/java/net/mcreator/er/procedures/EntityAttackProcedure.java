package net.mcreator.er.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModAttributes;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class EntityAttackProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingHurtEvent event) {
		if (event != null && event.getEntity() != null) {
			event.setAmount((float)(execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity(), event.getSource().getEntity(), event.getAmount(), event.getSource().getDirectEntity()
			)));
		}
	}

	public static double execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity, double amount, Entity Ientity) {
		return execute(null, world, x, y, z, entity, sourceentity, amount, Ientity);
	}

	private static double execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity, double amount, Entity Ientity) {
		if (entity == null)
			return 0;
		double multiply = 1;
		double amounts = 0;
		double type = 0;
		if (((LivingEntity) entity).getAbsorptionAmount() > 0) {
			multiply = 1 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.SHIELDSTRENGTH.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.SHIELDSTRENGTH.get()).getValue() : 10)
					/ ((entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.SHIELDSTRENGTH.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.SHIELDSTRENGTH.get()).getValue() : 10) + 100);
		}
		if (sourceentity == null)
			return amount * multiply + amounts;
		if (sourceentity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(ErModMobEffects.ELEMENT_BAN.get())) {
			return amount * multiply + amounts;
		}
		type = GetInfusionTypeProcedure.execute(sourceentity, Ientity);

		if (type == 2) {
			multiply = multiply * CryoMultiplyProcedure.execute(world, x, y, z, entity, sourceentity);
		} else if (type == 3) {
			multiply = multiply * DendroMultiplyProcedure.execute(world, x, y, z, entity, sourceentity, amount);
		} else if (type == 4) {
			multiply = multiply * ElectroMultiplyProcedure.execute(world, x, y, z, entity, sourceentity, amount);
		} else if (type == 5) {
			multiply = multiply * GeoMultiplyProcedure.execute(world, x, y, z, entity, sourceentity);
		} else if (type == 6) {
			multiply = multiply * HydroMultiplyProcedure.execute(world, x, y, z, entity, sourceentity);
		} else if (type == 1) {
			multiply = multiply * AnemoMultiplyProcedure.execute(world, x, y, z, entity, sourceentity , amount);
		} else if (type == 7) {
			multiply = multiply * PyroMultiplyProcedure.execute(world, x, y, z, entity, sourceentity);
		}
		return amount * multiply + amounts;
	}
}
