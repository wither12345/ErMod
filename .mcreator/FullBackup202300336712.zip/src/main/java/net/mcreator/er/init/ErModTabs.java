
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.er.ErMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ErModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ErMod.MODID);
	public static final RegistryObject<CreativeModeTab> ER_MATERIALS = REGISTRY.register("er_materials",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.er.er_materials")).icon(() -> new ItemStack(ErModItems.UNOWNED_VISION.get())).displayItems((parameters, tabData) -> {
				tabData.accept(ErModItems.MIST_FLOWER_COROLLA.get());
				tabData.accept(ErModItems.CONDENSED_CRYO.get());
				tabData.accept(ErModItems.FLAMING_FLOWER_STAMEN.get());
				tabData.accept(ErModItems.CONDENSED_PYRO.get());
				tabData.accept(ErModItems.ELECTRO_CRYSTAL.get());
				tabData.accept(ErModItems.CONDENSED_ELECTRO.get());
				tabData.accept(ErModBlocks.SUMERU_ROSE.get().asItem());
				tabData.accept(ErModItems.CONDENSED_DENDRO.get());
				tabData.accept(ErModItems.COR_LAPIS.get());
				tabData.accept(ErModItems.CONDENSED_GEO.get());
				tabData.accept(ErModItems.CRYSTAL_CORE.get());
				tabData.accept(ErModItems.DANDELION_SEED.get());
				tabData.accept(ErModItems.CONDENSED_ANEMO.get());
				tabData.accept(ErModItems.CONDENSED_HYDRO.get());
			})

					.build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {

		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(ErModItems.PYRO_ARMOR_HELMET.get());
			tabData.accept(ErModItems.PYRO_ARMOR_CHESTPLATE.get());
			tabData.accept(ErModItems.PYRO_ARMOR_LEGGINGS.get());
			tabData.accept(ErModItems.PYRO_ARMOR_BOOTS.get());
			tabData.accept(ErModItems.HUNTERS_BOW.get());
			tabData.accept(ErModItems.CRYO_ARMOR_HELMET.get());
			tabData.accept(ErModItems.CRYO_ARMOR_CHESTPLATE.get());
			tabData.accept(ErModItems.CRYO_ARMOR_LEGGINGS.get());
			tabData.accept(ErModItems.CRYO_ARMOR_BOOTS.get());
			tabData.accept(ErModItems.CRYO_SWORD.get());
			tabData.accept(ErModItems.PYRO_SWORD.get());
			tabData.accept(ErModItems.POLAR_STAR.get());
			tabData.accept(ErModItems.ELECTRO_ARMOR_HELMET.get());
			tabData.accept(ErModItems.ELECTRO_ARMOR_CHESTPLATE.get());
			tabData.accept(ErModItems.ELECTRO_ARMOR_LEGGINGS.get());
			tabData.accept(ErModItems.ELECTRO_ARMOR_BOOTS.get());
			tabData.accept(ErModItems.ELECTRO_SWORD.get());
			tabData.accept(ErModItems.DENDRO_ARMOR_HELMET.get());
			tabData.accept(ErModItems.DENDRO_ARMOR_CHESTPLATE.get());
			tabData.accept(ErModItems.DENDRO_ARMOR_LEGGINGS.get());
			tabData.accept(ErModItems.DENDRO_ARMOR_BOOTS.get());
			tabData.accept(ErModItems.DENDRO_SWORD.get());
			tabData.accept(ErModItems.GEO_ARMOR_HELMET.get());
			tabData.accept(ErModItems.GEO_ARMOR_CHESTPLATE.get());
			tabData.accept(ErModItems.GEO_ARMOR_LEGGINGS.get());
			tabData.accept(ErModItems.GEO_ARMOR_BOOTS.get());
			tabData.accept(ErModItems.GEO_SWORD.get());
			tabData.accept(ErModItems.ANEMO_ARMOR_HELMET.get());
			tabData.accept(ErModItems.ANEMO_ARMOR_CHESTPLATE.get());
			tabData.accept(ErModItems.ANEMO_ARMOR_LEGGINGS.get());
			tabData.accept(ErModItems.ANEMO_ARMOR_BOOTS.get());
			tabData.accept(ErModItems.ANEMO_SWORD.get());
			tabData.accept(ErModItems.HYDRO_ARMOR_HELMET.get());
			tabData.accept(ErModItems.HYDRO_ARMOR_CHESTPLATE.get());
			tabData.accept(ErModItems.HYDRO_ARMOR_LEGGINGS.get());
			tabData.accept(ErModItems.HYDRO_ARMOR_BOOTS.get());
			tabData.accept(ErModItems.HYDRO_SWORD.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(ErModItems.MIST_FLOWER_SPAWN_EGG.get());
			tabData.accept(ErModItems.FLAMING_FLOWER_SPAWN_EGG.get());
			tabData.accept(ErModItems.ANEMO_CRYSTALFLY_SPAWN_EGG.get());
			tabData.accept(ErModItems.TARTAGLIA_SPAWN_EGG.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(ErModItems.MORA.get());
			tabData.accept(ErModItems.MORA_BAG.get());
			tabData.accept(ErModItems.TEST_STELLA_FORTUNA.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(ErModItems.PYRO_HOE.get());
			tabData.accept(ErModItems.PYRO_PICKAXE.get());
			tabData.accept(ErModItems.ELECTRO_HOE.get());
			tabData.accept(ErModItems.GEO_PICKAXE.get());
		}

		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(ErModBlocks.ELECTRO_CRYSTAL_ORE.get().asItem());
			tabData.accept(ErModBlocks.COR_LAPIS_ORE.get().asItem());
			tabData.accept(ErModBlocks.LOTUS_HEAD.get().asItem());
		}
	}
}
