
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.item.ItemProperties;

import net.mcreator.er.procedures.HuntersBow_PullingProcedure;
import net.mcreator.er.item.UnownedVisionItem;
import net.mcreator.er.item.TestStellaFortunaItem;
import net.mcreator.er.item.PyroSwordItem;
import net.mcreator.er.item.PyroPickaxeItem;
import net.mcreator.er.item.PyroHoeItem;
import net.mcreator.er.item.PyroArmorItem;
import net.mcreator.er.item.PolarStarItem;
import net.mcreator.er.item.MoraItem;
import net.mcreator.er.item.MoraBagItem;
import net.mcreator.er.item.MistFlowerCorollaItem;
import net.mcreator.er.item.HydroSwordItem;
import net.mcreator.er.item.HydroArmorItem;
import net.mcreator.er.item.HuntersBowItem;
import net.mcreator.er.item.GeoSwordItem;
import net.mcreator.er.item.GeoPickaxeItem;
import net.mcreator.er.item.GeoArmorItem;
import net.mcreator.er.item.FlamingFlowerStamenItem;
import net.mcreator.er.item.ElectroSwordItem;
import net.mcreator.er.item.ElectroHoeItem;
import net.mcreator.er.item.ElectroCrystalItem;
import net.mcreator.er.item.ElectroArmorItem;
import net.mcreator.er.item.DendroSwordItem;
import net.mcreator.er.item.DendroArmorItem;
import net.mcreator.er.item.DandelionSeedItem;
import net.mcreator.er.item.CrystalCoreItem;
import net.mcreator.er.item.CryoSwordItem;
import net.mcreator.er.item.CryoArmorItem;
import net.mcreator.er.item.CorLapisItem;
import net.mcreator.er.item.CondensedPyroItem;
import net.mcreator.er.item.CondensedHydroItem;
import net.mcreator.er.item.CondensedGeoItem;
import net.mcreator.er.item.CondensedElectroItem;
import net.mcreator.er.item.CondensedDendroItem;
import net.mcreator.er.item.CondensedCryoItem;
import net.mcreator.er.item.CondensedAnemoItem;
import net.mcreator.er.item.AnemoSwordItem;
import net.mcreator.er.item.AnemoArmorItem;
import net.mcreator.er.ErMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ErModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ErMod.MODID);
	public static final RegistryObject<Item> MIST_FLOWER_SPAWN_EGG = REGISTRY.register("mist_flower_spawn_egg", () -> new ForgeSpawnEggItem(ErModEntities.MIST_FLOWER, -16711681, -6684673, new Item.Properties()));
	public static final RegistryObject<Item> FLAMING_FLOWER_SPAWN_EGG = REGISTRY.register("flaming_flower_spawn_egg", () -> new ForgeSpawnEggItem(ErModEntities.FLAMING_FLOWER, -65536, -39424, new Item.Properties()));
	public static final RegistryObject<Item> ANEMO_CRYSTALFLY_SPAWN_EGG = REGISTRY.register("anemo_crystalfly_spawn_egg", () -> new ForgeSpawnEggItem(ErModEntities.ANEMO_CRYSTALFLY, -16718409, -16719617, new Item.Properties()));
	public static final RegistryObject<Item> TARTAGLIA_SPAWN_EGG = REGISTRY.register("tartaglia_spawn_egg", () -> new ForgeSpawnEggItem(ErModEntities.TARTAGLIA, -6724096, -16737793, new Item.Properties()));
	public static final RegistryObject<Item> MIST_FLOWER_COROLLA = REGISTRY.register("mist_flower_corolla", () -> new MistFlowerCorollaItem());
	public static final RegistryObject<Item> CONDENSED_CRYO = REGISTRY.register("condensed_cryo", () -> new CondensedCryoItem());
	public static final RegistryObject<Item> FLAMING_FLOWER_STAMEN = REGISTRY.register("flaming_flower_stamen", () -> new FlamingFlowerStamenItem());
	public static final RegistryObject<Item> CONDENSED_PYRO = REGISTRY.register("condensed_pyro", () -> new CondensedPyroItem());
	public static final RegistryObject<Item> ELECTRO_CRYSTAL = REGISTRY.register("electro_crystal", () -> new ElectroCrystalItem());
	public static final RegistryObject<Item> CONDENSED_ELECTRO = REGISTRY.register("condensed_electro", () -> new CondensedElectroItem());
	public static final RegistryObject<Item> SUMERU_ROSE = block(ErModBlocks.SUMERU_ROSE);
	public static final RegistryObject<Item> CONDENSED_DENDRO = REGISTRY.register("condensed_dendro", () -> new CondensedDendroItem());
	public static final RegistryObject<Item> COR_LAPIS = REGISTRY.register("cor_lapis", () -> new CorLapisItem());
	public static final RegistryObject<Item> CONDENSED_GEO = REGISTRY.register("condensed_geo", () -> new CondensedGeoItem());
	public static final RegistryObject<Item> CRYSTAL_CORE = REGISTRY.register("crystal_core", () -> new CrystalCoreItem());
	public static final RegistryObject<Item> DANDELION_SEED = REGISTRY.register("dandelion_seed", () -> new DandelionSeedItem());
	public static final RegistryObject<Item> CONDENSED_ANEMO = REGISTRY.register("condensed_anemo", () -> new CondensedAnemoItem());
	public static final RegistryObject<Item> PYRO_ARMOR_HELMET = REGISTRY.register("pyro_armor_helmet", () -> new PyroArmorItem.Helmet());
	public static final RegistryObject<Item> PYRO_ARMOR_CHESTPLATE = REGISTRY.register("pyro_armor_chestplate", () -> new PyroArmorItem.Chestplate());
	public static final RegistryObject<Item> PYRO_ARMOR_LEGGINGS = REGISTRY.register("pyro_armor_leggings", () -> new PyroArmorItem.Leggings());
	public static final RegistryObject<Item> PYRO_ARMOR_BOOTS = REGISTRY.register("pyro_armor_boots", () -> new PyroArmorItem.Boots());
	public static final RegistryObject<Item> HUNTERS_BOW = REGISTRY.register("hunters_bow", () -> new HuntersBowItem());
	public static final RegistryObject<Item> CRYO_ARMOR_HELMET = REGISTRY.register("cryo_armor_helmet", () -> new CryoArmorItem.Helmet());
	public static final RegistryObject<Item> CRYO_ARMOR_CHESTPLATE = REGISTRY.register("cryo_armor_chestplate", () -> new CryoArmorItem.Chestplate());
	public static final RegistryObject<Item> CRYO_ARMOR_LEGGINGS = REGISTRY.register("cryo_armor_leggings", () -> new CryoArmorItem.Leggings());
	public static final RegistryObject<Item> CRYO_ARMOR_BOOTS = REGISTRY.register("cryo_armor_boots", () -> new CryoArmorItem.Boots());
	public static final RegistryObject<Item> CRYO_SWORD = REGISTRY.register("cryo_sword", () -> new CryoSwordItem());
	public static final RegistryObject<Item> PYRO_SWORD = REGISTRY.register("pyro_sword", () -> new PyroSwordItem());
	public static final RegistryObject<Item> POLAR_STAR = REGISTRY.register("polar_star", () -> new PolarStarItem());
	public static final RegistryObject<Item> ELECTRO_ARMOR_HELMET = REGISTRY.register("electro_armor_helmet", () -> new ElectroArmorItem.Helmet());
	public static final RegistryObject<Item> ELECTRO_ARMOR_CHESTPLATE = REGISTRY.register("electro_armor_chestplate", () -> new ElectroArmorItem.Chestplate());
	public static final RegistryObject<Item> ELECTRO_ARMOR_LEGGINGS = REGISTRY.register("electro_armor_leggings", () -> new ElectroArmorItem.Leggings());
	public static final RegistryObject<Item> ELECTRO_ARMOR_BOOTS = REGISTRY.register("electro_armor_boots", () -> new ElectroArmorItem.Boots());
	public static final RegistryObject<Item> ELECTRO_SWORD = REGISTRY.register("electro_sword", () -> new ElectroSwordItem());
	public static final RegistryObject<Item> DENDRO_ARMOR_HELMET = REGISTRY.register("dendro_armor_helmet", () -> new DendroArmorItem.Helmet());
	public static final RegistryObject<Item> DENDRO_ARMOR_CHESTPLATE = REGISTRY.register("dendro_armor_chestplate", () -> new DendroArmorItem.Chestplate());
	public static final RegistryObject<Item> DENDRO_ARMOR_LEGGINGS = REGISTRY.register("dendro_armor_leggings", () -> new DendroArmorItem.Leggings());
	public static final RegistryObject<Item> DENDRO_ARMOR_BOOTS = REGISTRY.register("dendro_armor_boots", () -> new DendroArmorItem.Boots());
	public static final RegistryObject<Item> DENDRO_SWORD = REGISTRY.register("dendro_sword", () -> new DendroSwordItem());
	public static final RegistryObject<Item> GEO_ARMOR_HELMET = REGISTRY.register("geo_armor_helmet", () -> new GeoArmorItem.Helmet());
	public static final RegistryObject<Item> GEO_ARMOR_CHESTPLATE = REGISTRY.register("geo_armor_chestplate", () -> new GeoArmorItem.Chestplate());
	public static final RegistryObject<Item> GEO_ARMOR_LEGGINGS = REGISTRY.register("geo_armor_leggings", () -> new GeoArmorItem.Leggings());
	public static final RegistryObject<Item> GEO_ARMOR_BOOTS = REGISTRY.register("geo_armor_boots", () -> new GeoArmorItem.Boots());
	public static final RegistryObject<Item> GEO_SWORD = REGISTRY.register("geo_sword", () -> new GeoSwordItem());
	public static final RegistryObject<Item> MORA = REGISTRY.register("mora", () -> new MoraItem());
	public static final RegistryObject<Item> MORA_BAG = REGISTRY.register("mora_bag", () -> new MoraBagItem());
	public static final RegistryObject<Item> TEST_STELLA_FORTUNA = REGISTRY.register("test_stella_fortuna", () -> new TestStellaFortunaItem());
	public static final RegistryObject<Item> PYRO_HOE = REGISTRY.register("pyro_hoe", () -> new PyroHoeItem());
	public static final RegistryObject<Item> PYRO_PICKAXE = REGISTRY.register("pyro_pickaxe", () -> new PyroPickaxeItem());
	public static final RegistryObject<Item> ELECTRO_HOE = REGISTRY.register("electro_hoe", () -> new ElectroHoeItem());
	public static final RegistryObject<Item> GEO_PICKAXE = REGISTRY.register("geo_pickaxe", () -> new GeoPickaxeItem());
	public static final RegistryObject<Item> ELECTRO_CRYSTAL_ORE = block(ErModBlocks.ELECTRO_CRYSTAL_ORE);
	public static final RegistryObject<Item> COR_LAPIS_ORE = block(ErModBlocks.COR_LAPIS_ORE);
	public static final RegistryObject<Item> UNOWNED_VISION = REGISTRY.register("unowned_vision", () -> new UnownedVisionItem());
	public static final RegistryObject<Item> ANEMO_ARMOR_HELMET = REGISTRY.register("anemo_armor_helmet", () -> new AnemoArmorItem.Helmet());
	public static final RegistryObject<Item> ANEMO_ARMOR_CHESTPLATE = REGISTRY.register("anemo_armor_chestplate", () -> new AnemoArmorItem.Chestplate());
	public static final RegistryObject<Item> ANEMO_ARMOR_LEGGINGS = REGISTRY.register("anemo_armor_leggings", () -> new AnemoArmorItem.Leggings());
	public static final RegistryObject<Item> ANEMO_ARMOR_BOOTS = REGISTRY.register("anemo_armor_boots", () -> new AnemoArmorItem.Boots());
	public static final RegistryObject<Item> ANEMO_SWORD = REGISTRY.register("anemo_sword", () -> new AnemoSwordItem());
	public static final RegistryObject<Item> LOTUS_HEAD = block(ErModBlocks.LOTUS_HEAD);
	public static final RegistryObject<Item> CONDENSED_HYDRO = REGISTRY.register("condensed_hydro", () -> new CondensedHydroItem());
	public static final RegistryObject<Item> HYDRO_ARMOR_HELMET = REGISTRY.register("hydro_armor_helmet", () -> new HydroArmorItem.Helmet());
	public static final RegistryObject<Item> HYDRO_ARMOR_CHESTPLATE = REGISTRY.register("hydro_armor_chestplate", () -> new HydroArmorItem.Chestplate());
	public static final RegistryObject<Item> HYDRO_ARMOR_LEGGINGS = REGISTRY.register("hydro_armor_leggings", () -> new HydroArmorItem.Leggings());
	public static final RegistryObject<Item> HYDRO_ARMOR_BOOTS = REGISTRY.register("hydro_armor_boots", () -> new HydroArmorItem.Boots());
	public static final RegistryObject<Item> HYDRO_SWORD = REGISTRY.register("hydro_sword", () -> new HydroSwordItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}

	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			ItemProperties.register(HUNTERS_BOW.get(), new ResourceLocation("er:hunters_bow_pulling"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) HuntersBow_PullingProcedure.execute(itemStackToRender));
			ItemProperties.register(POLAR_STAR.get(), new ResourceLocation("er:polar_star_pulling"), (itemStackToRender, clientWorld, entity, itemEntityId) -> (float) HuntersBow_PullingProcedure.execute(itemStackToRender));
		});
	}
}
