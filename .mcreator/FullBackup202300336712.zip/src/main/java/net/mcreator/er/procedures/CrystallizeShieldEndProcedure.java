package net.mcreator.er.procedures;

import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import java.util.UUID;

public class CrystallizeShieldEndProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		((LivingEntity) entity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.KNOCKBACK_RESISTANCE)
				.removeModifier((new AttributeModifier(UUID.fromString("547662BF-B275-9085-9829-17C8751E9F0E"), "knockback_res", 100, AttributeModifier.Operation.ADDITION)));
		((LivingEntity) entity).setAbsorptionAmount(Math.max(((LivingEntity) entity).getAbsorptionAmount() - 10, 0));
	}
}
