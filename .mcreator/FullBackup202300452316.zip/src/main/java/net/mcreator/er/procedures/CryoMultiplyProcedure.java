package net.mcreator.er.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModAttributes;

import java.util.List;
import java.util.Comparator;

public class CryoMultiplyProcedure {
	public static double execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return 0;
		double multiply = 0;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(ErModMobEffects.INTERNAL_COOLDOWN.get())) {
			multiply = 1;
		} else {
			if (entity instanceof LivingEntity _livEnt1 && _livEnt1.hasEffect(ErModMobEffects.PYRO.get())) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.PYRO.get());
				multiply = 1.5 + 2.78 * ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
						? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
						: 100)
						/ ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
								? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
								: 100) + 1400));
			} else if (entity instanceof LivingEntity _livEnt8 && _livEnt8.hasEffect(ErModMobEffects.HYDRO.get())) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.FROZEN.get(), 100, 0));
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.HYDRO.get());
				multiply = 1;
			} else if (entity instanceof LivingEntity _livEnt12 && _livEnt12.hasEffect(ErModMobEffects.ELECTRO.get())) {
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (Entity entityiterator : _entfound) {
						if (!(entityiterator == sourceentity)) {
							if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
							if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELEMENT_BAN.get(), 10, 0, false, false));
							entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("er:reaction"))), sourceentity),
									(float) (5 * (1 + 5 * ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
											? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
											: 0)
											/ (1200 + (entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
													? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
													: 0))))));
							if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(ErModMobEffects.SUPERCONDUCT.get(), 100, 0, false, false));
						}
					}
				}
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.ELECTRO.get());
				multiply = 1;
			} else {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.CRYO.get(), 200, 0));
				multiply = 1;
			}
		}
		return multiply * (entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.CRYODMGBONUS.get()) != null ? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.CRYODMGBONUS.get()).getValue() : 1)
				* ((100 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.CRYORES.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.CRYORES.get()).getValue() : 10)) / 100);
	}
}
