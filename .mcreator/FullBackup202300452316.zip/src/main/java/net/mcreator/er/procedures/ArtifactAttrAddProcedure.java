package net.mcreator.er.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.er.item.ArtifactItem;

import java.util.UUID;

public class ArtifactAttrAddProcedure {
	public static void execute(Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		ItemStack item = ItemStack.EMPTY;
		double count = 0;
		String type = "";
		String uuid = "";
		if (entity instanceof Player && itemstack.getItem() instanceof ArtifactItem) {
			type = itemstack.getOrCreateTag().getString("main_attribute_name");
			Attribute attr = ForgeRegistries.ATTRIBUTES.getValue(new ResourceLocation(type));
			uuid = ArtifactFunctionsProcedure.getUuid(itemstack, 4);
			count = ArtifactFunctionsProcedure.final_attribute(itemstack, 0);
			if (attr != null && ((LivingEntity) entity).getAttribute(attr).getModifier(UUID.fromString(uuid)) == null) {
				((LivingEntity) entity).getAttribute(attr)
						.addTransientModifier((itemstack.getOrCreateTag().getBoolean("main_attribute_multiplied")
								? new AttributeModifier(UUID.fromString(uuid), "artifact", count, AttributeModifier.Operation.MULTIPLY_BASE)
								: new AttributeModifier(UUID.fromString(uuid), "artifact", count, AttributeModifier.Operation.ADDITION)));
			}
			for (int index0 = 0; index0 < 4; index0++) {
				type = itemstack.getOrCreateTag().getString(("minor_attribute_name_" + new java.text.DecimalFormat("#").format(index0)));
				uuid = ArtifactFunctionsProcedure.getUuid(itemstack, index0);
				attr = ForgeRegistries.ATTRIBUTES.getValue(new ResourceLocation(type));
				count = ArtifactFunctionsProcedure.final_attribute(itemstack, index0 + 1);
				if (attr != null && ((LivingEntity) entity).getAttribute(attr).getModifier(UUID.fromString(uuid)) == null) {
					((LivingEntity) entity).getAttribute(attr)
							.addTransientModifier((itemstack.getOrCreateTag().getBoolean("minor_attribute_multiplied_" + new java.text.DecimalFormat("#").format(index0))
									? new AttributeModifier(UUID.fromString(uuid), "artifact", count, AttributeModifier.Operation.MULTIPLY_BASE)
									: new AttributeModifier(UUID.fromString(uuid), "artifact", count, AttributeModifier.Operation.ADDITION)));
				}
			}
		}
	}
}
