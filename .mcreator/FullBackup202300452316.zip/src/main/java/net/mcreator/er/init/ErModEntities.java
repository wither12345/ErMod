
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.er.entity.TartagliaEntity;
import net.mcreator.er.entity.PyroCrystallizeEntity;
import net.mcreator.er.entity.MistFlowerEntity;
import net.mcreator.er.entity.HydroCrystallizeEntity;
import net.mcreator.er.entity.HilichurlEntity;
import net.mcreator.er.entity.FlamingFlowerEntity;
import net.mcreator.er.entity.ElectroCrystallizeEntity;
import net.mcreator.er.entity.CryoCrystallizeEntity;
import net.mcreator.er.entity.BloomEntityEntity;
import net.mcreator.er.entity.AnemoCrystalflyEntity;
import net.mcreator.er.ErMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ErModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ErMod.MODID);
	public static final RegistryObject<EntityType<PyroCrystallizeEntity>> PYRO_CRYSTALLIZE = register("pyro_crystallize", EntityType.Builder.<PyroCrystallizeEntity>of(PyroCrystallizeEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(PyroCrystallizeEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<CryoCrystallizeEntity>> CRYO_CRYSTALLIZE = register("cryo_crystallize", EntityType.Builder.<CryoCrystallizeEntity>of(CryoCrystallizeEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(CryoCrystallizeEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<ElectroCrystallizeEntity>> ELECTRO_CRYSTALLIZE = register("electro_crystallize", EntityType.Builder.<ElectroCrystallizeEntity>of(ElectroCrystallizeEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ElectroCrystallizeEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<HydroCrystallizeEntity>> HYDRO_CRYSTALLIZE = register("hydro_crystallize", EntityType.Builder.<HydroCrystallizeEntity>of(HydroCrystallizeEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(HydroCrystallizeEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<MistFlowerEntity>> MIST_FLOWER = register("mist_flower",
			EntityType.Builder.<MistFlowerEntity>of(MistFlowerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(MistFlowerEntity::new)

					.sized(0.6f, 0.9f));
	public static final RegistryObject<EntityType<FlamingFlowerEntity>> FLAMING_FLOWER = register("flaming_flower",
			EntityType.Builder.<FlamingFlowerEntity>of(FlamingFlowerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(FlamingFlowerEntity::new)

					.sized(0.6f, 0.9f));
	public static final RegistryObject<EntityType<AnemoCrystalflyEntity>> ANEMO_CRYSTALFLY = register("anemo_crystalfly",
			EntityType.Builder.<AnemoCrystalflyEntity>of(AnemoCrystalflyEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(AnemoCrystalflyEntity::new)

					.sized(0.5f, 0.3f));
	public static final RegistryObject<EntityType<TartagliaEntity>> TARTAGLIA = register("tartaglia",
			EntityType.Builder.<TartagliaEntity>of(TartagliaEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(TartagliaEntity::new)

					.sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<BloomEntityEntity>> BLOOM_ENTITY = register("bloom_entity", EntityType.Builder.<BloomEntityEntity>of(BloomEntityEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BloomEntityEntity::new).fireImmune().sized(0.4f, 0.4f));
	public static final RegistryObject<EntityType<HilichurlEntity>> HILICHURL = register("hilichurl",
			EntityType.Builder.<HilichurlEntity>of(HilichurlEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(HilichurlEntity::new)

					.sized(0.6f, 1.8f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			PyroCrystallizeEntity.init();
			CryoCrystallizeEntity.init();
			ElectroCrystallizeEntity.init();
			HydroCrystallizeEntity.init();
			MistFlowerEntity.init();
			FlamingFlowerEntity.init();
			AnemoCrystalflyEntity.init();
			TartagliaEntity.init();
			BloomEntityEntity.init();
			HilichurlEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(PYRO_CRYSTALLIZE.get(), PyroCrystallizeEntity.createAttributes().build());
		event.put(CRYO_CRYSTALLIZE.get(), CryoCrystallizeEntity.createAttributes().build());
		event.put(ELECTRO_CRYSTALLIZE.get(), ElectroCrystallizeEntity.createAttributes().build());
		event.put(HYDRO_CRYSTALLIZE.get(), HydroCrystallizeEntity.createAttributes().build());
		event.put(MIST_FLOWER.get(), MistFlowerEntity.createAttributes().build());
		event.put(FLAMING_FLOWER.get(), FlamingFlowerEntity.createAttributes().build());
		event.put(ANEMO_CRYSTALFLY.get(), AnemoCrystalflyEntity.createAttributes().build());
		event.put(TARTAGLIA.get(), TartagliaEntity.createAttributes().build());
		event.put(BLOOM_ENTITY.get(), BloomEntityEntity.createAttributes().build());
		event.put(HILICHURL.get(), HilichurlEntity.createAttributes().build());
	}
}
