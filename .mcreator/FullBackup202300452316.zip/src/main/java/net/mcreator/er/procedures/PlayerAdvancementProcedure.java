package net.mcreator.er.procedures;

import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.AdvancementEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.advancements.Advancement;

import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModItems;

@Mod.EventBusSubscriber
public class PlayerAdvancementProcedure {
	@SubscribeEvent
	public static void onAdvancement(AdvancementEvent event) {
		Player player = event.getEntity();
		Advancement adv = event.getAdvancement();
		if (player.level().getServer().getAdvancements().getAdvancement(new ResourceLocation("minecraft:recipes/root")).equals(adv.getParent())) {
			return;
		}
		if (!(player.hasEffect(ErModMobEffects.VISION_COOL_DOWN.get())) && Math.random() <= 0.05) {
			if (!player.level().isClientSide())
				player.addEffect(new MobEffectInstance(ErModMobEffects.VISION_COOL_DOWN.get(), 60, 0, false, false));
				player.displayClientMessage(Component.literal((Component.translatable("message.er.get_vision").getString())), false);
			ItemStack _setstack = new ItemStack(ErModItems.UNOWNED_VISION.get());
			_setstack.setCount(1);
			ItemHandlerHelper.giveItemToPlayer(player, _setstack);
		}
	}
}
