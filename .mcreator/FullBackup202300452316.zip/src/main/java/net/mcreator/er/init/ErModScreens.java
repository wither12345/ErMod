
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.er.client.gui.MoraBagGUIScreen;
import net.mcreator.er.client.gui.ErEquipmentGUIScreen;
import net.mcreator.er.client.gui.ElementAnvilGUIScreen;
import net.mcreator.er.client.gui.ArtifactGUIScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ErModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(ErModMenus.MORA_BAG_GUI.get(), MoraBagGUIScreen::new);
			MenuScreens.register(ErModMenus.ER_EQUIPMENT_GUI.get(), ErEquipmentGUIScreen::new);
			MenuScreens.register(ErModMenus.ARTIFACT_GUI.get(), ArtifactGUIScreen::new);
			MenuScreens.register(ErModMenus.ELEMENT_ANVIL_GUI.get(), ElementAnvilGUIScreen::new);
		});
	}
}
