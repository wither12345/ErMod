package net.mcreator.er.procedures;

import net.minecraftforge.network.NetworkHooks;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.MenuProvider;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;
import net.minecraft.client.Minecraft;

import net.mcreator.er.world.inventory.ArtifactGUIMenu;
import net.mcreator.er.init.ErModItems;

import java.util.function.Supplier;
import java.util.Map;

import io.netty.buffer.Unpooled;

public class ArtifactItem_Right_ClickProcedure {
	public static void execute(LevelAccessor world, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		ItemStack item = ItemStack.EMPTY;
		if (new Object() {
			public boolean checkGamemode(Entity _ent) {
				if (_ent instanceof ServerPlayer _serverPlayer) {
					return _serverPlayer.gameMode.getGameModeForPlayer() == GameType.CREATIVE;
				} else if (_ent.level().isClientSide() && _ent instanceof Player _player) {
					return Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()) != null && Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()).getGameMode() == GameType.CREATIVE;
				}
				return false;
			}
		}.checkGamemode(entity)) {
			if (entity instanceof ServerPlayer _ent) {
				BlockPos _bpos = new BlockPos(0, -64, 0);
				NetworkHooks.openScreen((ServerPlayer) _ent, new MenuProvider() {
					@Override
					public Component getDisplayName() {
						return Component.literal("ArtifactGUI");
					}

					@Override
					public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
						return new ArtifactGUIMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
					}
				}, _bpos);
			}
			if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
				ItemStack _setstack = itemstack;
				_setstack.setCount(1);
				((Slot) _slots.get(0)).set(_setstack);
				_player.containerMenu.broadcastChanges();
			}
			item = new ItemStack(ErModItems.RARITY_GEMSTONE.get());
			item.setCount((int) (itemstack.getOrCreateTag().getDouble("rarity") + 1));
			if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
				ItemStack _setstack = item;
				_setstack.setCount((int) (itemstack.getOrCreateTag().getDouble("rarity") + 1));
				((Slot) _slots.get(6)).set(_setstack);
				_player.containerMenu.broadcastChanges();
			}
			item = new ItemStack(ErModItems.MINOR_UPGRADES.get());
			item.setCount((int) itemstack.getOrCreateTag().getDouble("minor_upgrade_times"));
			if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
				ItemStack _setstack = item;
				_setstack.setCount((int) itemstack.getOrCreateTag().getDouble("minor_upgrade_times"));
				((Slot) _slots.get(7)).set(_setstack);
				_player.containerMenu.broadcastChanges();
			}
			item = new ItemStack(ErModItems.MAIN_AFFIX_SHARD.get());
			item.getOrCreateTag().putString("attribute_name", (itemstack.getOrCreateTag().getString("main_attribute_name")));
			item.getOrCreateTag().putDouble("attribute_count", (itemstack.getOrCreateTag().getDouble("main_attribute_count")));
			item.getOrCreateTag().putBoolean("multiplied", (itemstack.getOrCreateTag().getBoolean("main_attribute_multiplied")));
			if (itemstack.getOrCreateTag().getDouble("main_attribute_count") != 0) {
				if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
					ItemStack _setstack = item;
					_setstack.setCount(1);
					((Slot) _slots.get(1)).set(_setstack);
					_player.containerMenu.broadcastChanges();
				}
			}
			for (int index = 0; index < 4; index++) {
				item = new ItemStack(ErModItems.MINOR_AFFIX_SHARD.get());
				item.getOrCreateTag().putString("attribute_name", (itemstack.getOrCreateTag().getString(("minor_attribute_name_" + new java.text.DecimalFormat("##").format(index)))));
				item.getOrCreateTag().putDouble("attribute_count", (itemstack.getOrCreateTag().getDouble(("minor_attribute_count_" + new java.text.DecimalFormat("##").format(index)))));
				item.getOrCreateTag().putDouble("count_multiplier", (itemstack.getOrCreateTag().getDouble(("minor_count_multiplier_" + new java.text.DecimalFormat("##").format(index)))));
				item.getOrCreateTag().putBoolean("multiplied", (itemstack.getOrCreateTag().getBoolean(("minor_attribute_multiplied_" + new java.text.DecimalFormat("##").format(index)))));
				if (itemstack.getOrCreateTag().getDouble(("minor_attribute_count_" + new java.text.DecimalFormat("##").format(index))) != 0) {
					if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
						ItemStack _setstack = item;
						_setstack.setCount(1);
						((Slot) _slots.get((int) index + 2)).set(_setstack);
						_player.containerMenu.broadcastChanges();
					}
				}
			}
		}
	}
}
