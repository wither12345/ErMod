package net.mcreator.er.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.er.item.ArtifactItem;
import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModItems;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class PlayerObtainItemProcedure {
	@SubscribeEvent
	public static void onPickup(EntityItemPickupEvent event) {
		execute(event, event.getEntity(), event.getItem().getItem());
	}

	public static void execute(Entity entity, ItemStack itemstack) {
		execute(null, entity, itemstack);
	}

	private static void execute(@Nullable Event event, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (itemstack.getItem() instanceof ArtifactItem) {
			if (itemstack.getOrCreateTag().getDouble("main_attribute_count") == 0) {
				ArtifactFunctionsProcedure.main_attribute_rolling(itemstack);
			}
			for (int index0 = 0; index0 < (int) itemstack.getOrCreateTag().getDouble("minor_upgrade_times"); index0++) {
				RollMinorAttributeProcedure.execute(itemstack);
			}
			itemstack.getOrCreateTag().putDouble("minor_upgrade_times", 0);
		}
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ErModMobEffects.LUCKY_DOG.get()) ? _livEnt.getEffect(ErModMobEffects.LUCKY_DOG.get()).getAmplifier() : 0) >= 3 && itemstack.getItem() == ErModItems.MORA.get()) {
			((LivingEntity) entity).heal(3);
		}
	}
}
