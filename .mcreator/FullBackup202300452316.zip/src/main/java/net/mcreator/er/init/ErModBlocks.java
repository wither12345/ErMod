
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.er.block.WhiteIronOreBlock;
import net.mcreator.er.block.SumeruRoseBlock;
import net.mcreator.er.block.LotusHeadBlock;
import net.mcreator.er.block.ElementAnvilBlock;
import net.mcreator.er.block.ElectroCrystalOreBlock;
import net.mcreator.er.block.DeepslateWhiteIronOreBlock;
import net.mcreator.er.block.CrateBlock;
import net.mcreator.er.block.CorLapisOreBlock;
import net.mcreator.er.block.BurningDirtBlock;
import net.mcreator.er.ErMod;

public class ErModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, ErMod.MODID);
	public static final RegistryObject<Block> SUMERU_ROSE = REGISTRY.register("sumeru_rose", () -> new SumeruRoseBlock());
	public static final RegistryObject<Block> ELEMENT_ANVIL = REGISTRY.register("element_anvil", () -> new ElementAnvilBlock());
	public static final RegistryObject<Block> BURNING_DIRT = REGISTRY.register("burning_dirt", () -> new BurningDirtBlock());
	public static final RegistryObject<Block> LOTUS_HEAD = REGISTRY.register("lotus_head", () -> new LotusHeadBlock());
	public static final RegistryObject<Block> ELECTRO_CRYSTAL_ORE = REGISTRY.register("electro_crystal_ore", () -> new ElectroCrystalOreBlock());
	public static final RegistryObject<Block> COR_LAPIS_ORE = REGISTRY.register("cor_lapis_ore", () -> new CorLapisOreBlock());
	public static final RegistryObject<Block> WHITE_IRON_ORE = REGISTRY.register("white_iron_ore", () -> new WhiteIronOreBlock());
	public static final RegistryObject<Block> DEEPSLATE_WHITE_IRON_ORE = REGISTRY.register("deepslate_white_iron_ore", () -> new DeepslateWhiteIronOreBlock());
	public static final RegistryObject<Block> CRATE = REGISTRY.register("crate", () -> new CrateBlock());
}
