package net.mcreator.er.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModEntities;
import net.mcreator.er.init.ErModAttributes;
import net.mcreator.er.entity.PyroCrystallizeEntity;
import net.mcreator.er.entity.HydroCrystallizeEntity;
import net.mcreator.er.entity.ElectroCrystallizeEntity;
import net.mcreator.er.entity.CryoCrystallizeEntity;

public class GeoMultiplyProcedure {
	public static double execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return 0;
		double multiply = 0;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(ErModMobEffects.INTERNAL_COOLDOWN.get())) {
			multiply = 1;
		} else {
			if (entity instanceof LivingEntity _livEnt1 && _livEnt1.hasEffect(ErModMobEffects.PYRO.get())) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.PYRO.get());
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new PyroCrystallizeEntity(ErModEntities.PYRO_CRYSTALLIZE.get(), _level);
					entityToSpawn.getPersistentData().putString("UUID", sourceentity.getStringUUID());
					entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, _level.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					_level.addFreshEntity(entityToSpawn);
				}
				multiply = 1;
			} else if (entity instanceof LivingEntity _livEnt5 && _livEnt5.hasEffect(ErModMobEffects.HYDRO.get())) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.HYDRO.get());
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new HydroCrystallizeEntity(ErModEntities.HYDRO_CRYSTALLIZE.get(), _level);
					entityToSpawn.getPersistentData().putString("UUID", sourceentity.getStringUUID());
					entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, _level.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					_level.addFreshEntity(entityToSpawn);
				}
				multiply = 1;
			} else if (entity instanceof LivingEntity _livEnt9 && _livEnt9.hasEffect(ErModMobEffects.ELECTRO.get())) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.ELECTRO.get());
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new ElectroCrystallizeEntity(ErModEntities.ELECTRO_CRYSTALLIZE.get(), _level);
					entityToSpawn.getPersistentData().putString("UUID", sourceentity.getStringUUID());
					entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, _level.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					_level.addFreshEntity(entityToSpawn);
				}
				multiply = 1;
			} else if (entity instanceof LivingEntity _livEnt13 && _livEnt13.hasEffect(ErModMobEffects.CRYO.get())) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.CRYO.get());
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new CryoCrystallizeEntity(ErModEntities.CRYO_CRYSTALLIZE.get(), _level);
					entityToSpawn.getPersistentData().putString("UUID", sourceentity.getStringUUID());
					entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, _level.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					_level.addFreshEntity(entityToSpawn);
				}
				multiply = 1;
			} else {
				multiply = 1;
			}
		}
		return multiply * (entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.GEODMGBONUS.get()) != null ? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.GEODMGBONUS.get()).getValue() : 100)
				* ((100 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.GEORES.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.GEORES.get()).getValue() : 10)) / 100);
	}
}
