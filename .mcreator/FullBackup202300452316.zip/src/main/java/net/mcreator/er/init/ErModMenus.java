
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.er.world.inventory.MoraBagGUIMenu;
import net.mcreator.er.world.inventory.ErEquipmentGUIMenu;
import net.mcreator.er.world.inventory.ElementAnvilGUIMenu;
import net.mcreator.er.world.inventory.ArtifactGUIMenu;
import net.mcreator.er.ErMod;

public class ErModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, ErMod.MODID);
	public static final RegistryObject<MenuType<MoraBagGUIMenu>> MORA_BAG_GUI = REGISTRY.register("mora_bag_gui", () -> IForgeMenuType.create(MoraBagGUIMenu::new));
	public static final RegistryObject<MenuType<ErEquipmentGUIMenu>> ER_EQUIPMENT_GUI = REGISTRY.register("er_equipment_gui", () -> IForgeMenuType.create(ErEquipmentGUIMenu::new));
	public static final RegistryObject<MenuType<ArtifactGUIMenu>> ARTIFACT_GUI = REGISTRY.register("artifact_gui", () -> IForgeMenuType.create(ArtifactGUIMenu::new));
	public static final RegistryObject<MenuType<ElementAnvilGUIMenu>> ELEMENT_ANVIL_GUI = REGISTRY.register("element_anvil_gui", () -> IForgeMenuType.create(ElementAnvilGUIMenu::new));
}
