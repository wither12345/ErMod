package net.mcreator.er.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.item.ItemStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;

import net.mcreator.er.init.ErModItems;

public class AffixShard_DescriptionProcedure {
	public static String execute(ItemStack itemstack) {
		String attr_name = "";
		if (ForgeRegistries.ATTRIBUTES.getValue(new ResourceLocation((itemstack.getOrCreateTag().getString("attribute_name")))) != null) {
			attr_name = ForgeRegistries.ATTRIBUTES.getValue(new ResourceLocation((itemstack.getOrCreateTag().getString("attribute_name")))).getDescriptionId();
		}
		if (itemstack.getItem() == ErModItems.MAIN_AFFIX_SHARD.get()) {
			return Component.translatable(attr_name).getString() + ":" + new java.text.DecimalFormat(itemstack.getOrCreateTag().getBoolean("multiplied") ? "##.#%" : "##.#").format(itemstack.getOrCreateTag().getDouble("attribute_count"));
		}
		return Component.translatable(attr_name).getString() + ":" + new java.text.DecimalFormat(itemstack.getOrCreateTag().getBoolean("multiplied") ? "##.#%" : "##.#").format(itemstack.getOrCreateTag().getDouble("attribute_count")) + " x "
				+ new java.text.DecimalFormat("##.#").format(itemstack.getOrCreateTag().getDouble("count_multiplier"));
	}
}
