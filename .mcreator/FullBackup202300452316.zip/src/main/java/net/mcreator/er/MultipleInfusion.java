
package net.mcreator.er;

import net.minecraft.world.item.ItemStack;

public interface MultipleInfusion {
	int getInfusion(ItemStack itemstack);
}
