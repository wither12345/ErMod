package net.mcreator.er.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;

import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModEntities;
import net.mcreator.er.init.ErModAttributes;
import net.mcreator.er.entity.BloomEntityEntity;

public class HydroMultiplyProcedure {
	public static double execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return 0;
		double multiply = 0;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(ErModMobEffects.INTERNAL_COOLDOWN.get())) {
			multiply = 1;
		} else {
			if (entity instanceof LivingEntity _livEnt1 && _livEnt1.hasEffect(ErModMobEffects.PYRO.get())) {
				multiply = 2 + 2.78 * ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
						? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
						: 100)
						/ ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
								? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
								: 100) + 1400));
			} else if (entity instanceof LivingEntity _livEnt6 && _livEnt6.hasEffect(ErModMobEffects.ELECTRO.get())) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELECTRO_CHARGED.get(), 60,
							(int) ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
									? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
									: 100) / 100)));
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.HYDRO.get());
				multiply = 1;
			} else if (entity instanceof LivingEntity _livEnt12 && _livEnt12.hasEffect(ErModMobEffects.CRYO.get())) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.FROZEN.get(), 100, 0, false, false));
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.CRYO.get());
				multiply = 1;
			} else if (entity instanceof LivingEntity _livEnt16 && _livEnt16.hasEffect(ErModMobEffects.DENDRO.get())) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new BloomEntityEntity(ErModEntities.BLOOM_ENTITY.get(), _level);
					entityToSpawn.getPersistentData().putString("UUID", sourceentity.getStringUUID());
					entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, _level.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
					_level.addFreshEntity(entityToSpawn);
				}
				if (world instanceof ServerLevel _level)
					_level.sendParticles(ParticleTypes.HAPPY_VILLAGER, x, y, z, 5, 1, 1, 1, 0);
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.DENDRO.get());
				multiply = 1;
			} else {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.HYDRO.get(), 200, 0));
				multiply = 1;
			}
		}
		return multiply * (entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.HYDRODMGBONUS.get()) != null ? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.HYDRODMGBONUS.get()).getValue() : 100)
				* ((100 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.HYDRORES.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.HYDRORES.get()).getValue() : 10)) / 100);
	}
}
