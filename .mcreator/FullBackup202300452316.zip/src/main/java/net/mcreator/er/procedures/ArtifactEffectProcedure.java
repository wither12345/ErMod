package net.mcreator.er.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.er.network.ErModVariables;
import net.mcreator.er.item.ArtifactItem;

public class ArtifactEffectProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		ItemStack item = ItemStack.EMPTY;
		String[] effects_type = new String[5];
		int[] effects_count = new int[5];
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Flower_Of_Life);
		if (item.getItem() instanceof ArtifactItem) {
			effects_type[0] = ((ArtifactItem) item.getItem()).getEffect();
			effects_count[0]++;
		}
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Plume_of_Death);
		if (item.getItem() instanceof ArtifactItem) {
			for (int index0 = 0; index0 < 5; index0++) {
				if (effects_count[index0] == 0) {
					effects_type[index0] = ((ArtifactItem) item.getItem()).getEffect();
					break;
				} else if (effects_type[index0] == ((ArtifactItem) item.getItem()).getEffect()) {
					effects_count[index0]++;
					break;
				}
			}
		}
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Sands_Of_Eon);
		if (item.getItem() instanceof ArtifactItem) {
			for (int index1 = 0; index1 < 5; index1++) {
				if (effects_count[index1] == 0) {
					effects_type[index1] = ((ArtifactItem) item.getItem()).getEffect();
					break;
				} else if (effects_type[index1] == ((ArtifactItem) item.getItem()).getEffect()) {
					effects_count[index1]++;
					break;
				}
			}
		}
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Goblet_Of_Eonothem);
		if (item.getItem() instanceof ArtifactItem) {
			for (int index2 = 0; index2 < 5; index2++) {
				if (effects_count[index2] == 0) {
					effects_type[index2] = ((ArtifactItem) item.getItem()).getEffect();
					break;
				} else if (effects_type[index2] == ((ArtifactItem) item.getItem()).getEffect()) {
					effects_count[index2]++;
					break;
				}
			}
		}
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Circlet_Of_Logos);
		if (item.getItem() instanceof ArtifactItem) {
			for (int index3 = 0; index3 < 5; index3++) {
				if (effects_count[index3] == 0) {
					effects_type[index3] = ((ArtifactItem) item.getItem()).getEffect();
					break;
				} else if (effects_type[index3] == ((ArtifactItem) item.getItem()).getEffect()) {
					effects_count[index3]++;
					break;
				}
			}
		}
		for (int index4 = 0; index4 < 5; index4++) {
			if (effects_count[index4] != 0) {
				MobEffect eff = ForgeRegistries.MOB_EFFECTS.getValue(new ResourceLocation(effects_type[index4]));
				if (eff != null) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(eff, 40, effects_count[index4] - 1, false, false));
				}
			}
		}
	}
}
