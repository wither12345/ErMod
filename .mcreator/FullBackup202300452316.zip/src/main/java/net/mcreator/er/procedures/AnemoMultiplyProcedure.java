package net.mcreator.er.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;

import net.mcreator.er.init.ErModParticleTypes;
import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModBlocks;
import net.mcreator.er.init.ErModAttributes;

import java.util.List;
import java.util.Comparator;

public class AnemoMultiplyProcedure {
	public static double execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return 0;
		double multiply = 0;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(ErModMobEffects.INTERNAL_COOLDOWN.get())) {
			return ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELECTRODMGBONUS.get()) != null ? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELECTRODMGBONUS.get()).getValue() : 100)
					/ 100) * ((100 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.ELECTRORES.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.ELECTRORES.get()).getValue() : 10)) / 100);
		}
		if (entity instanceof LivingEntity _livEnt5 && _livEnt5.hasEffect(ErModMobEffects.HYDRO.get())) {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELEMENT_BAN.get(), 10, 0, false, false));
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
				for (Entity entityiterator : _entfound) {
					if (sourceentity == entityiterator) {
						continue;
					}
					entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("er:reaction"))), sourceentity),
							(float) (5 * HydroMultiplyProcedure.execute(world, x, y, z, entityiterator, sourceentity)
									* (1 + 16 * ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
											? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
											: 0)
											/ (2000 + (entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
													? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
													: 0))))));
					if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				}
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.SMALL_HYDRO_PARTICLE.get()), (x - 1.5), (y + entity.getBbHeight() / 2), (z - 1.5), 8, 1.5, 0, 1.5, 0);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(ErModMobEffects.HYDRO.get());
		} else if (entity instanceof LivingEntity _livEnt19 && _livEnt19.hasEffect(ErModMobEffects.CRYO.get())) {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELEMENT_BAN.get(), 10, 0, false, false));
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
				for (Entity entityiterator : _entfound) {
					if (sourceentity == entityiterator) {
						continue;
					}
					entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("er:reaction"))), sourceentity),
							(float) (5 * CryoMultiplyProcedure.execute(world, x, y, z, entityiterator, sourceentity)
									* (1 + 16 * ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
											? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
											: 0)
											/ (2000 + (entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
													? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
													: 0))))));
					if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				}
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.SMALL_CRYO_PARTICLE.get()), (x - 1.5), (y + entity.getBbHeight() / 2), (z - 1.5), 8, 1.5, 0, 1.5, 0);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(ErModMobEffects.CRYO.get());
		} else if (entity instanceof LivingEntity _livEnt33 && _livEnt33.hasEffect(ErModMobEffects.ELECTRO.get())) {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELEMENT_BAN.get(), 10, 0, false, false));
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
				for (Entity entityiterator : _entfound) {
					if (sourceentity == entityiterator) {
						continue;
					}
					entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("er:reaction"))), sourceentity),
							(float) (5 * ElectroMultiplyProcedure.execute(world, x, y, z, entityiterator, sourceentity)
									* (1 + 16 * ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
											? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
											: 0)
											/ (2000 + (entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
													? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
													: 0))))));
					if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				}
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.SMALL_ELECTRO_PARTICLE.get()), (x - 1.5), (y + entity.getBbHeight() / 2), (z - 1.5), 8, 1.5, 0, 1.5, 0);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(ErModMobEffects.ELECTRO.get());
		} else if (entity instanceof LivingEntity _livEnt47 && _livEnt47.hasEffect(ErModMobEffects.PYRO.get())) {
			if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELEMENT_BAN.get(), 10, 0, false, false));
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
				for (Entity entityiterator : _entfound) {
					if (sourceentity == entityiterator) {
						continue;
					}
					entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("er:reaction"))), sourceentity),
							(float) (5 * PyroMultiplyProcedure.execute(world, x, y, z, entityiterator, sourceentity)
									* (1 + 16 * ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
											? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
											: 0)
											/ (2000 + (entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
													? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
													: 0))))));
					if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				}
			}
			for (int i = -2; i <= 2; i++)
				for (int j = -2; j <= 2; j++)
					for (int k = -1; k <= 1; k++)
						if ((world.getBlockState(BlockPos.containing(x + i, y + k, z + j))).getBlock() == Blocks.GRASS_BLOCK) {
							world.setBlock(BlockPos.containing(x + i, y + k, z + j), ErModBlocks.BURNING_DIRT.get().defaultBlockState(), 3);
							if (!world.isClientSide()) {
								BlockPos _bp = BlockPos.containing(x + i, y + k, z + j);
								BlockEntity _blockEntity = world.getBlockEntity(_bp);
								BlockState _bs = world.getBlockState(_bp);
								if (_blockEntity != null)
									_blockEntity.getPersistentData().putString("UUID", sourceentity.getStringUUID());
								if (world instanceof Level _level)
									_level.sendBlockUpdated(_bp, _bs, _bs, 3);
							}
						}
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.SMALL_PYRO_PARTICLE.get()), (x - 1.5), (y + entity.getBbHeight() / 2), (z - 1.5), 8, 1.5, 0, 1.5, 0);
			if (entity instanceof LivingEntity _entity)
				_entity.removeEffect(ErModMobEffects.PYRO.get());
		}
		return (entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ANEMODMGBONUS.get()) != null ? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ANEMODMGBONUS.get()).getValue() : 100)
				* ((100 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.ANEMORES.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.ANEMORES.get()).getValue() : 10)) / 100);
	}
}
