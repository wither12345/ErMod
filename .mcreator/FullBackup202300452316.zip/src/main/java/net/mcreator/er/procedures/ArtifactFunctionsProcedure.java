package net.mcreator.er.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.ItemTags;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.er.item.ArtifactItem;
import net.mcreator.er.ERConfig;

import java.util.Random;

public class ArtifactFunctionsProcedure {
	public static String getUuid(ItemStack itemstack, int sort) {
		if (itemstack.is(ItemTags.create(new ResourceLocation("er:flower_of_life")))) {
			if (sort == 4)
				return "3933889B-78FD-BFA7-C8D0-36CCE4E72F29";
			else
				return "220A8F9E-FB21-F6DB-0FFC-00985335671" + new java.text.DecimalFormat("#").format(sort);
		}
		if (itemstack.is(ItemTags.create(new ResourceLocation("er:plume_of_death")))) {
			if (sort == 4)
				return "BD782FF7-E900-4404-07EA-1B07804C7D25";
			else
				return "54E5FC9A-DD20-E029-296D-D48A8C9DFCC" + new java.text.DecimalFormat("#").format(sort);
		}
		if (itemstack.is(ItemTags.create(new ResourceLocation("er:sands_of_eon")))) {
			if (sort == 4)
				return "B2794C01-D4CC-018B-C97F-8F12F8A08E5E";
			else
				return "96D8CA0C-5D85-E80D-F1C5-DE19D781C14" + new java.text.DecimalFormat("#").format(sort);
		}
		if (itemstack.is(ItemTags.create(new ResourceLocation("er:goblet_of_eonothem")))) {
			if (sort == 4)
				return "8D904011-4D9C-5692-FCA7-996253FFA6E3";
			else
				return "F276F1C5-BFEB-D846-83DE-F8D2BE515E1" + new java.text.DecimalFormat("#").format(sort);
		}
		if (itemstack.is(ItemTags.create(new ResourceLocation("er:circlet_of_logos.")))) {
			if (sort == 4)
				return "1C677FB3-CA5C-1DF0-C065-71838C36A0EF";
			else
				return "48E790A5-AA97-804B-1EB7-D0C29D38361" + new java.text.DecimalFormat("#").format(sort);
		}
		return "00000000-0000-0000-0000-000000000000";
	}

	public static double final_attribute(ItemStack itemstack, double sort) {
		String attr_name = "";
		boolean mult = false;
		double original_count = 0;
		double rarity = 0;
		if (itemstack.getItem() instanceof ArtifactItem) {
			if (sort == 0) {
				attr_name = itemstack.getOrCreateTag().getString("main_attribute_name");
				original_count = itemstack.getOrCreateTag().getDouble("main_attribute_count");
				rarity = itemstack.getOrCreateTag().getDouble("rarity");
				mult = itemstack.getOrCreateTag().getBoolean("main_attribute_multiplied");
				original_count *= itemstack.getOrCreateTag().getDouble("level") * 0.285 + 1;
			} else {
				attr_name = itemstack.getOrCreateTag().getString(("minor_attribute_name_" + new java.text.DecimalFormat("#").format(sort - 1)));
				original_count = itemstack.getOrCreateTag().getDouble(("minor_attribute_count_" + new java.text.DecimalFormat("#").format(sort - 1)));
				rarity = itemstack.getOrCreateTag().getDouble("rarity");
				mult = itemstack.getOrCreateTag().getBoolean(("minor_attribute_multiplied_" + new java.text.DecimalFormat("#").format(sort - 1)));
				original_count *= itemstack.getOrCreateTag().getDouble(("minor_count_multiplier_" + new java.text.DecimalFormat("#").format(sort - 1)));
			}
			if (!mult && (attr_name).equals("generic.attack_damage")) {
				if (rarity >= 5) {
					return ERConfig.MYTHIC_DMG_SCALING.get() * original_count;
				} else if (rarity >= 4) {
					return ERConfig.LEGENDARY_DMG_SCALING.get() * original_count;
				} else if (rarity >= 3) {
					return ERConfig.EPIC_DMG_SCALING.get() * original_count;
				} else if (rarity >= 2) {
					return ERConfig.RARE_DMG_SCALING.get() * original_count;
				} else if (rarity >= 1) {
					return ERConfig.UNCOMMON_DMG_SCALING.get() * original_count;
				} else {
					return ERConfig.COMMON_DMG_SCALING.get() * original_count;
				}
			} else if (!mult && (attr_name).equals("generic.max_health")) {
				if (rarity >= 5) {
					return ERConfig.MYTHIC_HP_SCALING.get() * original_count;
				} else if (rarity >= 4) {
					return ERConfig.LEGENDARY_HP_SCALING.get() * original_count;
				} else if (rarity >= 3) {
					return ERConfig.EPIC_HP_SCALING.get() * original_count;
				} else if (rarity >= 2) {
					return ERConfig.RARE_HP_SCALING.get() * original_count;
				} else if (rarity >= 1) {
					return ERConfig.UNCOMMON_HP_SCALING.get() * original_count;
				} else {
					return ERConfig.COMMON_HP_SCALING.get() * original_count;
				}
			} else {
				if (rarity >= 5) {
					return ERConfig.MYTHIC_OTHER_SCALING.get() * original_count;
				} else if (rarity >= 4) {
					return ERConfig.LEGENDARY_OTHER_SCALING.get() * original_count;
				} else if (rarity >= 3) {
					return ERConfig.EPIC_OTHER_SCALING.get() * original_count;
				} else if (rarity >= 2) {
					return ERConfig.RARE_OTHER_SCALING.get() * original_count;
				} else if (rarity >= 1) {
					return ERConfig.UNCOMMON_OTHER_SCALING.get() * original_count;
				} else {
					return ERConfig.COMMON_OTHER_SCALING.get() * original_count;
				}
			}
		}
		return 0;
	}

	public static void main_attribute_rolling(ItemStack itemstack) {
		String[] effects_type = null;
		if (itemstack.is(ItemTags.create(new ResourceLocation("er:flower_of_life")))) {
			effects_type = ERConfig.FLOWER_OF_LIFE_MAIN_ATTR.get().split(";");
		}
		else if(itemstack.is(ItemTags.create(new ResourceLocation("er:plume_of_death")))) {
			effects_type = ERConfig.FLOWER_OF_LIFE_MAIN_ATTR.get().split(";");
		}
		else if(itemstack.is(ItemTags.create(new ResourceLocation("er:sands_of_eon")))) {
			effects_type = ERConfig.SANDS_OF_EON_ATTR.get().split(";");
		}
		else if(itemstack.is(ItemTags.create(new ResourceLocation("er:goblet_of_eonothem")))) {
			effects_type = ERConfig.GOBLET_OF_EONOTHEM_ATTR.get().split(";");
		}
		else if(itemstack.is(ItemTags.create(new ResourceLocation("er:circlet_of_logos")))) {
			effects_type = ERConfig.CIRCLET_OF_LOGOS_ATTR.get().split(";");
		}
		int index = new Random().nextInt(effects_type.length);
		String type[] = effects_type[index].replaceAll(" ","").split(",");
		if(type.length < 2) return ;
		itemstack.getOrCreateTag().putString("main_attribute_name", type[0]);
		itemstack.getOrCreateTag().putDouble("main_attribute_count", Double.valueOf(type[1].toString()));
		if (type[2].equals("0"))
			itemstack.getOrCreateTag().putBoolean("main_attribute_multiplied", false);
		else
			itemstack.getOrCreateTag().putBoolean("main_attribute_multiplied", true);
		/*
		if (itemstack.is(ItemTags.create(new ResourceLocation("er:plume_of_death")))) {
			itemstack.getOrCreateTag().putString("main_attribute_name", "minecraft:generic.attack_damage");
			itemstack.getOrCreateTag().putDouble("main_attribute_count", 3.0);
			itemstack.getOrCreateTag().putBoolean("main_attribute_multiplied", false);
		}
		*/
	}

	public static double experience_percentage(ItemStack itemstack) {
		if (itemstack.getItem() instanceof ArtifactItem) {
			return Math.min(1, itemstack.getOrCreateTag().getDouble("experience") / ((600 + 175 * itemstack.getOrCreateTag().getDouble("level")) * (itemstack.getOrCreateTag().getDouble("rarity") + 1)));
		}
		return 0;
	}

	public static double max_level(ItemStack itemstack) {
		int rarity = itemstack.getOrCreateTag().getInt("rarity");
		if (rarity <= 1)
			return 4;
		if (rarity <= 2)
			return 12;
		if (rarity <= 3)
			return 16;
		return 20;
	}

	public static boolean minor_attribute_rolling(ItemStack itemstack) {
		String attr_name = "";
		boolean mult = false;
		boolean find = false;
		double attr_count = 0;
		double sort = 0;
		for (int index0 = 0; index0 < 4; index0++) {
			if (itemstack.getOrCreateTag().getDouble(("minor_attribute_count_" + new java.text.DecimalFormat("###").format(index0))) <= 0) {
				while (true) {
					mult = false;
					if (Math.random() <= 0.1111111) {
						attr_name = "minecraft:generic.max_health";
						attr_count = 5;
					} else if (Math.random() <= 0.125) {
						attr_name = "minecraft:generic.armor";
						attr_count = 0.0729;
						mult = true;
					} else if (Math.random() <= 0.142857) {
						attr_name = "minecraft:generic.armor";
						attr_count = 3;
					} else if (Math.random() <= 0.16666) {
						attr_name = "er:elemental_mastery";
						attr_count = 23.31;
					} else if (Math.random() <= 0.2) {
						attr_name = "er:energy_recharge";
						attr_count = 0.0648;
						mult = true;
					} else if (Math.random() <= 0.25) {
						attr_name = "er:crit_damage";
						attr_count = 0.0777;
						mult = true;
					} else if (Math.random() <= 0.33333) {
						attr_name = "minecraft:generic.attack_damage";
						attr_count = 0.0583;
						mult = true;
					} else if (Math.random() <= 0.5) {
						attr_name = "minecraft:generic.max_health";
						attr_count = 0.0583;
						mult = true;
					} else {
						attr_name = "minecraft:generic.attack_damage";
						attr_count = 3;
					}
					find = true;
					if ((itemstack.getOrCreateTag().getString("main_attribute_name")).equals(attr_name) && itemstack.getOrCreateTag().getBoolean("main_attribute_multiplied") == mult) {
						find = false;
					}
					for (int index2 = 0; index2 < 4; index2++) {
						if ((itemstack.getOrCreateTag().getString(("minor_attribute_name_" + new java.text.DecimalFormat("###").format(index2)))).equals(attr_name)
								&& itemstack.getOrCreateTag().getBoolean(("minor_attribute_multiplied_" + new java.text.DecimalFormat("###").format(index2))) == mult) {
							find = false;
						}
					}
					if (find) {
						itemstack.getOrCreateTag().putString(("minor_attribute_name_" + new java.text.DecimalFormat("###").format(index0)), attr_name);
						itemstack.getOrCreateTag().putDouble(("minor_attribute_count_" + new java.text.DecimalFormat("###").format(index0)), attr_count);
						itemstack.getOrCreateTag().putBoolean(("minor_attribute_multiplied_" + new java.text.DecimalFormat("###").format(index0)), mult);
						itemstack.getOrCreateTag().putDouble(("minor_count_multiplier_" + new java.text.DecimalFormat("###").format(index0)), 1);
						break;
					}
				}
				return true;
			}
		}
		sort = Mth.nextInt(RandomSource.create(), 0, 3);
		itemstack.getOrCreateTag().putDouble(("minor_count_multiplier_" + new java.text.DecimalFormat("###").format(sort)), (itemstack.getOrCreateTag().getDouble(("minor_count_multiplier_" + new java.text.DecimalFormat("###").format(sort))) + 1));
		return false;
	}
}
