package net.mcreator.er.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;

import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Stray;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.entity.monster.Blaze;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.er.network.ErModVariables;
import net.mcreator.er.init.ErModItems;
import net.mcreator.er.init.ErModAttributes;
import net.mcreator.er.entity.TartagliaEntity;
import net.mcreator.er.entity.MistFlowerEntity;
import net.mcreator.er.entity.FlamingFlowerEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class EntitySpawnProcedure {
	@SubscribeEvent
	public static void onEntityJoin(EntityJoinLevelEvent event) {
		execute(event, event.getEntity());
	}

	public static void execute(Entity entity) {
		execute(null, entity);
	}

	private static void execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Projectile) {
			if (((Projectile) entity).getOwner() instanceof Stray) {
				entity.getPersistentData().putDouble("Element", 2);
			}
			if (((Projectile) entity).getOwner() instanceof TartagliaEntity) {
				entity.getPersistentData().putDouble("Element", 6);
			} else if (entity instanceof Arrow && ((Projectile) entity).getOwner() instanceof Player) {
				if (((((Projectile) entity).getOwner().getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Vision).getItem() == ErModItems.ANEMO_VISION.get()) {
					entity.getPersistentData().putDouble("Element", 1);
				} else if (((((Projectile) entity).getOwner().getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Vision).getItem() == ErModItems.CRYO_VISION.get()) {
					entity.getPersistentData().putDouble("Element", 2);
				} else if (((((Projectile) entity).getOwner().getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Vision).getItem() == ErModItems.DENDRO_VISION.get()) {
					entity.getPersistentData().putDouble("Element", 3);
				} else if (((((Projectile) entity).getOwner().getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Vision).getItem() == ErModItems.ELECTRO_VISION.get()) {
					entity.getPersistentData().putDouble("Element", 4);
				} else if (((((Projectile) entity).getOwner().getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Vision).getItem() == ErModItems.GEO_VISION.get()) {
					entity.getPersistentData().putDouble("Element", 5);
				} else if (((((Projectile) entity).getOwner().getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Vision).getItem() == ErModItems.HYDRO_VISION.get()) {
					entity.getPersistentData().putDouble("Element", 6);
				} else if (((((Projectile) entity).getOwner().getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Vision).getItem() == ErModItems.PYRO_VISION.get()) {
					entity.getPersistentData().putDouble("Element", 7);
				}
			}
			if (entity instanceof SmallFireball || entity instanceof LargeFireball) {
				entity.getPersistentData().putDouble("Element", 7);
			}
		} else if (entity instanceof EnderMan) {
			((LivingEntity) entity).getAttribute(ErModAttributes.HYDRORES.get()).setBaseValue((-50));
		} else if (entity instanceof FlamingFlowerEntity || entity instanceof Blaze) {
			((LivingEntity) entity).getAttribute(ErModAttributes.PYRORES.get()).setBaseValue(200);
		} else if (entity instanceof MistFlowerEntity) {
			((LivingEntity) entity).getAttribute(ErModAttributes.CRYORES.get()).setBaseValue(200);
		}
	}
}
