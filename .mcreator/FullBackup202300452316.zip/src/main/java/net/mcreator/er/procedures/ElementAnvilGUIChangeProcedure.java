package net.mcreator.er.procedures;

import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.ItemTags;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.er.item.ArtifactItem;
import net.mcreator.er.init.ErModItems;

import java.util.function.Supplier;
import java.util.Map;

public class ElementAnvilGUIChangeProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		ItemStack item_0 = ItemStack.EMPTY;
		item_0 = ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(0)).getItem() : ItemStack.EMPTY).copy());
		if (item_0.getItem() instanceof ArtifactItem) {
			for (int index0 = 0; index0 < 9; index0++) {
				if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
						.getItem() instanceof ArtifactItem) {
					item_0.getOrCreateTag().putDouble("experience", (item_0.getOrCreateTag().getDouble("experience")
							+ 420 * ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
									.getOrCreateTag().getDouble("rarity") >= 3
											? (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
													.getOrCreateTag().getDouble("rarity") * 2
											: (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
													.getOrCreateTag().getDouble("rarity") + 1)
							+ 0.8 * (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
									.getOrCreateTag().getDouble("total_experience")));
					item_0.getOrCreateTag().putDouble("total_experience", (item_0.getOrCreateTag().getDouble("total_experience")
							+ 420 * ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
									.getOrCreateTag().getDouble("rarity") >= 3
											? (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
													.getOrCreateTag().getDouble("rarity") * 2
											: (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
													.getOrCreateTag().getDouble("rarity") + 1)
							+ 0.8 * (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
									.getOrCreateTag().getDouble("total_experience")));
				}
			}
			while (item_0.getOrCreateTag().getDouble("experience") >= (600 + 175 * item_0.getOrCreateTag().getDouble("level")) * (item_0.getOrCreateTag().getDouble("rarity") + 1)
					&& item_0.getOrCreateTag().getDouble("level") < ArtifactFunctionsProcedure.max_level(item_0)) {
				item_0.getOrCreateTag().putDouble("experience", (item_0.getOrCreateTag().getDouble("experience") - (600 + 175 * item_0.getOrCreateTag().getDouble("level")) * (item_0.getOrCreateTag().getDouble("rarity") + 1)));
				item_0.getOrCreateTag().putDouble("level", (item_0.getOrCreateTag().getDouble("level") + 1));
				if (item_0.getOrCreateTag().getDouble("level") % 4 == 0) {
					item_0.getOrCreateTag().putDouble("minor_upgrade_times", (item_0.getOrCreateTag().getDouble("minor_upgrade_times") + 1));
				}
			}
		} else if (item_0.getItem() instanceof SwordItem || item_0.getItem() instanceof BowItem) {
			for (int index2 = 0; index2 < 9; index2++) {
				if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
						.getItem() == ErModItems.ENHANCEMENT_ORE.get()) {
					item_0.getOrCreateTag().putDouble("experience", (item_0.getOrCreateTag().getDouble("experience") + 400));
					item_0.getOrCreateTag().putDouble("total_experience", (item_0.getOrCreateTag().getDouble("total_experience") + 400));
				} else if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
						.getItem() == ErModItems.FINE_ENHANCEMENT_ORE.get()) {
					item_0.getOrCreateTag().putDouble("experience", (item_0.getOrCreateTag().getDouble("experience") + 2000));
					item_0.getOrCreateTag().putDouble("total_experience", (item_0.getOrCreateTag().getDouble("total_experience") + 2000));
				} else if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
						.getItem() == ErModItems.MYSTIC_ENHANCEMENT_ORE.get()) {
					item_0.getOrCreateTag().putDouble("experience", (item_0.getOrCreateTag().getDouble("experience") + 10000));
					item_0.getOrCreateTag().putDouble("total_experience", (item_0.getOrCreateTag().getDouble("total_experience") + 10000));
				} else if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
						.is(ItemTags.create(new ResourceLocation("er:one_star_weapon")))) {
					item_0.getOrCreateTag().putDouble("experience",
							(item_0.getOrCreateTag().getDouble("experience") + 600
									+ 0.8 * (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
											.getOrCreateTag().getDouble("total_experience")));
					item_0.getOrCreateTag().putDouble("total_experience",
							(item_0.getOrCreateTag().getDouble("total_experience") + 600
									+ 0.8 * (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
											.getOrCreateTag().getDouble("total_experience")));
				} else if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
						.is(ItemTags.create(new ResourceLocation("er:five_star_weapon")))) {
					item_0.getOrCreateTag().putDouble("experience",
							(item_0.getOrCreateTag().getDouble("experience") + 300000
									+ 0.8 * (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
											.getOrCreateTag().getDouble("total_experience")));
					item_0.getOrCreateTag().putDouble("total_experience",
							(item_0.getOrCreateTag().getDouble("total_experience") + 300000
									+ 0.8 * (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
											.getOrCreateTag().getDouble("total_experience")));
				}
			}
			while (item_0.getOrCreateTag().getDouble("experience") >= GetWeaponMaxExpProcedure.execute(item_0) && item_0.getOrCreateTag().getDouble("level") < (item_0.is(ItemTags.create(new ResourceLocation("er:one_star_weapon"))) ? 69 : 89)) {
				item_0.getOrCreateTag().putDouble("experience", (item_0.getOrCreateTag().getDouble("experience") - GetWeaponMaxExpProcedure.execute(item_0)));
				item_0.getOrCreateTag().putDouble("level", (item_0.getOrCreateTag().getDouble("level") + 1));
				if (item_0.getOrCreateTag().getDouble("level") % 4 == 0) {
					item_0.getOrCreateTag().putDouble("minor_upgrade_times", (item_0.getOrCreateTag().getDouble("minor_upgrade_times") + 1));
				}
			}
		}
		if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
			ItemStack _setstack = item_0;
			_setstack.setCount(1);
			((Slot) _slots.get(10)).set(_setstack);
			_player.containerMenu.broadcastChanges();
		}
	}
}
