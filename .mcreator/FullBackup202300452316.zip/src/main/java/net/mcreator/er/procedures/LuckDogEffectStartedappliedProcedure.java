package net.mcreator.er.procedures;

import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import java.util.UUID;

public class LuckDogEffectStartedappliedProcedure {
	public static void execute(Entity entity, double amplifier) {
		if (entity == null)
			return;
		if (amplifier >= 1) {
			if (!(((LivingEntity) entity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR)
					.hasModifier((new AttributeModifier(UUID.fromString("1536F03A-D251-52D1-5505-925F57500FAC"), "lucky_dog", 2, AttributeModifier.Operation.ADDITION)))))
				((LivingEntity) entity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR)
						.addTransientModifier((new AttributeModifier(UUID.fromString("1536F03A-D251-52D1-5505-925F57500FAC"), "lucky_dog", 2, AttributeModifier.Operation.ADDITION)));
		}
	}
}
