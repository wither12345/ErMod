/**
 * The code of this mod element is always locked.
 *
 * You can register new events in this class too.
 *
 * If you want to make a plain independent class, create it using
 * Project Browser -> New... and make sure to make the class
 * outside net.mcreator.er as this package is managed by MCreator.
 *
 * If you change workspace package, modid or prefix, you will need
 * to manually adapt this file to these changes or remake it.
 *
 * This class will be added in the mod root package.
*/
package net.mcreator.er;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.AnvilUpdateEvent;

import net.minecraft.world.item.ItemStack;

import net.mcreator.er.init.ErModItems;

@Mod.EventBusSubscriber
public class AnvilUpdate {
	@SubscribeEvent //(priority = EventPriority.HIGHEST)
	public static void onAnvilUpdate(AnvilUpdateEvent event) {
		if (event.getLeft().getItem() == event.getRight().getItem() && event.getRight().getItem() == ErModItems.MORA_BAG.get()) {
			event.setCanceled(true);
		}
	}
}
