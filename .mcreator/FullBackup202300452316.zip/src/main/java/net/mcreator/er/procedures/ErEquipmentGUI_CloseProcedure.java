package net.mcreator.er.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.er.network.ErModVariables;

import java.util.function.Supplier;
import java.util.Map;

public class ErEquipmentGUI_CloseProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		String type = "";
		String uuid = "";
		double count = 0;
		ItemStack item = ItemStack.EMPTY;
		{
			ItemStack _setval = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(0)).getItem() : ItemStack.EMPTY);
			entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.Vision = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		{
			ItemStack _setval = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(1)).getItem() : ItemStack.EMPTY);
			entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.Stella_Fortuna = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Flower_Of_Life);
		ArtifactAttrRemoveProcedure.execute(entity, (entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Flower_Of_Life);
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Plume_of_Death);
		ArtifactAttrRemoveProcedure.execute(entity, (entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Plume_of_Death);
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Sands_Of_Eon);
		ArtifactAttrRemoveProcedure.execute(entity, (entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Plume_of_Death);
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Goblet_Of_Eonothem);
		ArtifactAttrRemoveProcedure.execute(entity, (entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Plume_of_Death);
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Circlet_Of_Logos);
		ArtifactAttrRemoveProcedure.execute(entity, (entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Plume_of_Death);
		{
			ItemStack _setval = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(2)).getItem() : ItemStack.EMPTY);
			entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.Flower_Of_Life = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Flower_Of_Life);
		ArtifactAttrAddProcedure.execute(entity, item);
		{
			ItemStack _setval = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(3)).getItem() : ItemStack.EMPTY);
			entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.Plume_of_Death = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Plume_of_Death);
		ArtifactAttrAddProcedure.execute(entity, item);
		{
			ItemStack _setval = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(4)).getItem() : ItemStack.EMPTY);
			entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.Sands_Of_Eon = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Sands_Of_Eon);
		ArtifactAttrAddProcedure.execute(entity, item);
		{
			ItemStack _setval = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(5)).getItem() : ItemStack.EMPTY);
			entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.Goblet_Of_Eonothem = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Goblet_Of_Eonothem);
		ArtifactAttrAddProcedure.execute(entity, item);
		{
			ItemStack _setval = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(6)).getItem() : ItemStack.EMPTY);
			entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.Circlet_Of_Logos = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		item = ((entity.getCapability(ErModVariables.PLAYER_VARIABLES_CAPABILITY, null).orElse(new ErModVariables.PlayerVariables())).Circlet_Of_Logos);
		ArtifactAttrAddProcedure.execute(entity, item);
	}
}
