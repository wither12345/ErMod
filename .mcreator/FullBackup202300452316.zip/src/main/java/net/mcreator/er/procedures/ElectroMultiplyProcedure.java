package net.mcreator.er.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModAttributes;

import java.util.List;
import java.util.Comparator;

public class ElectroMultiplyProcedure {
	public static double execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return 0;
		double multiply = 0;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(ErModMobEffects.INTERNAL_COOLDOWN.get())) {
			multiply = 1;
		} else {
			multiply = 1;
			if (entity instanceof LivingEntity _livEnt1 && _livEnt1.hasEffect(ErModMobEffects.QUICKEN.get())) {
				entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("er:reaction"))), sourceentity),
						(float) (5
								* (1 + 16 * ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
										? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
										: 0)
										/ (2000 + (entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
												? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
												: 0))))
								* ((100 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.DENDRORES.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.DENDRORES.get()).getValue() : 10))
										/ 100)));
			}
			if (entity instanceof LivingEntity _livEnt10 && _livEnt10.hasEffect(ErModMobEffects.PYRO.get())) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 1, 0, 0, 0, 0);
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.explode")), SoundSource.NEUTRAL, 1, 1);
					} else {
						_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.explode")), SoundSource.NEUTRAL, 1, 1, false);
					}
				}
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (Entity entityiterator : _entfound) {
						if (entityiterator instanceof LivingEntity && !(entityiterator == sourceentity)) {
							if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
							if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELEMENT_BAN.get(), 10, 0, false, false));
							entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("er:reaction"))), sourceentity),
									(float) (5
											* (1 + 5 * ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
													? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
													: 0)
													/ (1200 + (entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
															? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
															: 0))))
											* multiply
											* (entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.PYRODMGBONUS.get()) != null
													? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.PYRODMGBONUS.get()).getValue()
													: 1)
											* ((100 - (entity instanceof LivingEntity && ((LivingEntity) entityiterator).getAttribute(ErModAttributes.CRYORES.get()) != null
													? ((LivingEntity) entityiterator).getAttribute(ErModAttributes.PYRORES.get()).getValue()
													: 10)) / 100)));
							entityiterator.setDeltaMovement(new Vec3((entityiterator.getDeltaMovement().x() * 3), (entityiterator.getDeltaMovement().y() * 2), (entityiterator.getDeltaMovement().z() * 3)));
						}
					}
				}
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.PYRO.get());
			} else if (entity instanceof LivingEntity _livEnt33 && _livEnt33.hasEffect(ErModMobEffects.DENDRO.get())) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.QUICKEN.get(), 200, 0));
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.DENDRO.get());
			} else if (entity instanceof LivingEntity _livEnt36 && _livEnt36.hasEffect(ErModMobEffects.HYDRO.get())) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELECTRO_CHARGED.get(), 60,
							(int) ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
									? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
									: 100) / 100)));
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.HYDRO.get());
			} else if (entity instanceof LivingEntity _livEnt42 && _livEnt42.hasEffect(ErModMobEffects.CRYO.get())) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (Entity entityiterator : _entfound) {
						if (entityiterator instanceof LivingEntity && !(entityiterator == sourceentity)) {
							if (sourceentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELEMENT_BAN.get(), 10, 0, false, false));
							if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(ErModMobEffects.INTERNAL_COOLDOWN.get(), 10, 0, false, false));
							entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("er:reaction"))), sourceentity),
									(float) (5 * (1 + 5 * ((entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
											? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
											: 0)
											/ (1200 + (entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()) != null
													? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTALMASTERY.get()).getValue()
													: 0))))));
							if (entityiterator instanceof LivingEntity _entity && !_entity.level().isClientSide())
								_entity.addEffect(new MobEffectInstance(ErModMobEffects.SUPERCONDUCT.get(), 100, 0, false, false));
						}
					}
				}
				if (entity instanceof LivingEntity _entity)
					_entity.removeEffect(ErModMobEffects.CRYO.get());
			} else {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELECTRO.get(), 200, 0));
				multiply = 1;
			}
		}
		return multiply * (entity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELECTRODMGBONUS.get()) != null ? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELECTRODMGBONUS.get()).getValue() : 1)
				* ((100 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.ELECTRORES.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.ELECTRORES.get()).getValue() : 10)) / 100);
	}
}
