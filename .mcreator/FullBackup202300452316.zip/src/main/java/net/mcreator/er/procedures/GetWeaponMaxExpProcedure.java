package net.mcreator.er.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.tags.ItemTags;
import net.minecraft.resources.ResourceLocation;

public class GetWeaponMaxExpProcedure {
	public static double execute(ItemStack itemstack) {
		if (itemstack.is(ItemTags.create(new ResourceLocation("er:five_star_weapon")))) {
			if (itemstack.getOrCreateTag().getDouble("level") >= 80) {
				return Math.ceil(Math.pow(itemstack.getOrCreateTag().getDouble("level"), 2) * 100 - (itemstack.getOrCreateTag().getDouble("level") + 1) * 15636 + 620000) * 25;
			} else if (itemstack.getOrCreateTag().getDouble("level") >= 70) {
				return Math.ceil(Math.pow(itemstack.getOrCreateTag().getDouble("level"), 2) + 1 + (itemstack.getOrCreateTag().getDouble("level") + 1) * 6612 + 11) * 25;
			} else {
				return Math.ceil(Math.pow(itemstack.getOrCreateTag().getDouble("level"), 2) + 1 + (itemstack.getOrCreateTag().getDouble("level") + 1) * 20 + 11) * 25;
			}
		}
		return Math.ceil((Math.pow(itemstack.getOrCreateTag().getDouble("level"), 2) + 1) / 5 + (itemstack.getOrCreateTag().getDouble("level") + 1) * 2.6 + 2) * 25;
	}
}
