
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.er.client.model.Modelbloom;
import net.mcreator.er.client.model.ModelMist_Flower;
import net.mcreator.er.client.model.ModelFlaming_Flower;
import net.mcreator.er.client.model.ModelErHumanoid;
import net.mcreator.er.client.model.ModelCrystallize;
import net.mcreator.er.client.model.ModelCrystalfly;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class ErModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelbloom.LAYER_LOCATION, Modelbloom::createBodyLayer);
		event.registerLayerDefinition(ModelFlaming_Flower.LAYER_LOCATION, ModelFlaming_Flower::createBodyLayer);
		event.registerLayerDefinition(ModelMist_Flower.LAYER_LOCATION, ModelMist_Flower::createBodyLayer);
		event.registerLayerDefinition(ModelCrystallize.LAYER_LOCATION, ModelCrystallize::createBodyLayer);
		event.registerLayerDefinition(ModelErHumanoid.LAYER_LOCATION, ModelErHumanoid::createBodyLayer);
		event.registerLayerDefinition(ModelCrystalfly.LAYER_LOCATION, ModelCrystalfly::createBodyLayer);
	}
}
