package net.mcreator.er.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleTypes;

import net.mcreator.er.init.ErModParticleTypes;
import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModAttributes;

public class PyroTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, double amplifier) {
		if (entity == null)
			return;
		double front = 0;
		if (world instanceof ServerLevel _level)
			_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_PYRO.get()), x, (y + entity.getBbHeight() + 0.5), z, 1, 0, 0, 0, 0);
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ErModMobEffects.PYRO.get()) ? _livEnt.getEffect(ErModMobEffects.PYRO.get()).getDuration() : 0) % 5 == 0 && entity instanceof LivingEntity _livEnt3
				&& _livEnt3.hasEffect(ErModMobEffects.DENDRO.get())) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.FLAME, (x - entity.getBbWidth() / 2), y, (z - entity.getBbWidth() / 2), 10, (entity.getBbWidth()), (entity.getBbHeight()), (entity.getBbWidth()), 0);
			((LivingEntity) entity).invulnerableTime = 0;
			entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("er:reaction")))),
					(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) * (1 + 16 * (amplifier / (amplifier + 20))) * 0.025
							* (1 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.PYRORES.get()) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.PYRORES.get()).getValue() : 10) / 100)));
		}
	}
}
