package net.mcreator.er.procedures;

import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import java.util.UUID;

public class LuckDogEffectExpiresProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		((LivingEntity) entity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.ARMOR)
				.removeModifier((new AttributeModifier(UUID.fromString("1536F03A-D251-52D1-5505-925F57500FAC"), "lucky_dog", 2, AttributeModifier.Operation.ADDITION)));
	}
}
