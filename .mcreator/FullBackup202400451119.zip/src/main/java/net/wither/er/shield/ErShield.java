package net.wither.er.shield;

public class ErShield {
	private float health ;
	private int time ;
	
}
