package net.wither.er.client.screens;

import net.neoforged.neoforge.event.entity.player.PlayerHeartTypeEvent;
import net.neoforged.fml.common.asm.enumextension.EnumProxy;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.gui.Gui;

@EventBusSubscriber({Dist.CLIENT})
public class HeartShieldOverlay {
	public static final EnumProxy<Gui.HeartType> HYDRO = new EnumProxy<>(Gui.HeartType.class, ResourceLocation.parse("er:heart/hydro_crystallize/full"), ResourceLocation.parse("er:heart/hydro_crystallize/full_blinking"),
			ResourceLocation.parse("er:heart/hydro_crystallize/half"), ResourceLocation.parse("er:heart/hydro_crystallize/half_blinking"), ResourceLocation.parse("er:heart/hydro_crystallize/hardcore_full"),
			ResourceLocation.parse("er:heart/hydro_crystallize/hardcore_full_blinking"), ResourceLocation.parse("er:heart/hydro_crystallize/hardcore_half"), ResourceLocation.parse("er:heart/hydro_crystallize/hardcore_half_blinking"));

	@SubscribeEvent
	public static void HeartTypeChanging(PlayerHeartTypeEvent event) {
		event.setType(HYDRO.getValue());
	}
}
