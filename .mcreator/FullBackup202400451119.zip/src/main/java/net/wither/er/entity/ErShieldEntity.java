package net.wither.er.entity;

import net.wither.er.shield.ErShield;

import java.util.List;
import java.util.ArrayList;

public interface ErShieldEntity {
	List<ErShield> shields = new ArrayList<>();

	default List<ErShield> getShields() {
		return this.shields;
	}

	default void addShield(ErShield shield) {
		this.shields.add(shield);
	}
}
