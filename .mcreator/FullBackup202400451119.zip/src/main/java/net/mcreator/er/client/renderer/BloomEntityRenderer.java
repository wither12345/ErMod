
package net.mcreator.er.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.er.entity.BloomEntityEntity;
import net.mcreator.er.client.model.Modelbloom;

public class BloomEntityRenderer extends MobRenderer<BloomEntityEntity, Modelbloom<BloomEntityEntity>> {
	public BloomEntityRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelbloom<BloomEntityEntity>(context.bakeLayer(Modelbloom.LAYER_LOCATION)), 0.4f);
	}

	@Override
	public ResourceLocation getTextureLocation(BloomEntityEntity entity) {
		return ResourceLocation.parse("er:textures/entities/bloom_entity.png");
	}
}
