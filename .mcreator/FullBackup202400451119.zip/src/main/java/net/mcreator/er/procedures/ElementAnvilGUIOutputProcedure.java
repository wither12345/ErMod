package net.mcreator.er.procedures;

import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.component.DataComponents;

import java.util.function.Supplier;
import java.util.Map;

public class ElementAnvilGUIOutputProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		ItemStack item_10 = ItemStack.EMPTY;
		item_10 = ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(10)).getItem() : ItemStack.EMPTY).copy()).copy();
		for (int index0 = 0; index0 < 10; index0++) {
			if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
				((Slot) _slots.get((int) index0)).set(ItemStack.EMPTY);
				_player.containerMenu.broadcastChanges();
			}
		}
		for (int index1 = 0; index1 < (int) item_10.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("minor_upgrade_times"); index1++) {
			RollMinorAttributeProcedure.execute(item_10);
		}
		{
			final String _tagName = "minor_upgrade_times";
			final double _tagValue = 0;
			CustomData.update(DataComponents.CUSTOM_DATA, item_10, tag -> tag.putDouble(_tagName, _tagValue));
		}
		if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
			ItemStack _setstack = item_10.copy();
			_setstack.setCount(1);
			((Slot) _slots.get(10)).set(_setstack);
			_player.containerMenu.broadcastChanges();
		}
	}
}
