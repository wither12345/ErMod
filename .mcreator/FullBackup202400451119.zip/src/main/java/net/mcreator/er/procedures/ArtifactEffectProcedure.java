package net.mcreator.er.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.er.network.ErModVariables;
import net.mcreator.er.item.ArtifactItem;

public class ArtifactEffectProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		ItemStack item = ItemStack.EMPTY;
		String[] effects_type = new String[5];
		int[] effects_count = new int[5];
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Flower_Of_Life.copy();
		if (item.getItem() instanceof ArtifactItem) {
			effects_type[0] = ((ArtifactItem) item.getItem()).getEffect();
			effects_count[0]++;
		}
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Plume_of_Death.copy();
		if (item.getItem() instanceof ArtifactItem) {
			for (int index0 = 0; index0 < 5; index0++) {
				if (effects_count[index0] == 0) {
					effects_type[index0] = ((ArtifactItem) item.getItem()).getEffect();
					break;
				} else if (effects_type[index0] == ((ArtifactItem) item.getItem()).getEffect()) {
					effects_count[index0]++;
					break;
				}
			}
		}
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Sands_Of_Eon.copy();
		if (item.getItem() instanceof ArtifactItem) {
			for (int index1 = 0; index1 < 5; index1++) {
				if (effects_count[index1] == 0) {
					effects_type[index1] = ((ArtifactItem) item.getItem()).getEffect();
					break;
				} else if (effects_type[index1] == ((ArtifactItem) item.getItem()).getEffect()) {
					effects_count[index1]++;
					break;
				}
			}
		}
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Goblet_Of_Eonothem.copy();
		if (item.getItem() instanceof ArtifactItem) {
			for (int index2 = 0; index2 < 5; index2++) {
				if (effects_count[index2] == 0) {
					effects_type[index2] = ((ArtifactItem) item.getItem()).getEffect();
					break;
				} else if (effects_type[index2] == ((ArtifactItem) item.getItem()).getEffect()) {
					effects_count[index2]++;
					break;
				}
			}
		}
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Circlet_Of_Logos.copy();
		if (item.getItem() instanceof ArtifactItem) {
			for (int index3 = 0; index3 < 5; index3++) {
				if (effects_count[index3] == 0) {
					effects_type[index3] = ((ArtifactItem) item.getItem()).getEffect();
					break;
				} else if (effects_type[index3] == ((ArtifactItem) item.getItem()).getEffect()) {
					effects_count[index3]++;
					break;
				}
			}
		}
		for (int index4 = 0; index4 < 5; index4++) {
			if (effects_count[index4] != 0) {
				if (BuiltInRegistries.MOB_EFFECT.getHolder(ResourceLocation.parse(effects_type[index4])) != null && entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(BuiltInRegistries.MOB_EFFECT.getHolder(ResourceLocation.parse(effects_type[index4])).get(), 40, effects_count[index4] - 1, false, false));
			}
		}
	}
}
