package net.mcreator.er.procedures;

import net.wither.er.entity.ArcEntity;

import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.monster.Blaze;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

import net.mcreator.er.init.ErModParticleTypes;
import net.mcreator.er.init.ErModEntities;
import net.mcreator.er.init.ErModAttributes;
import net.mcreator.er.EntityHurtEvent;

import javax.annotation.Nullable;

import java.util.List;
import java.util.Comparator;

@EventBusSubscriber
public class EntityTickProcedure {
	@SubscribeEvent
	public static void onEntityTick(EntityTickEvent.Pre event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity());
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Blaze) {
			EntityHurtEvent.PyroMultiply(world, x, y, z, (LivingEntity) entity, entity, 500);
		} else if (entity instanceof LivingEntity && entity.isInWaterRainOrBubble()) {
			EntityHurtEvent.HydroMultiply(world, x, y, z, (LivingEntity) entity, entity, 50);
		}
		if (entity.getPersistentData().getInt("Electro_Charged_Cd") > 0) {
			entity.getPersistentData().putInt("Electro_Charged_Cd", entity.getPersistentData().getInt("Electro_Charged_Cd") - 1);
		}
		if (entity.getPersistentData().getInt("Cryo") > 0) {
			entity.getPersistentData().putInt("Cryo", entity.getPersistentData().getInt("Cryo") - 1);
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_CRYO.get()), x, (entity.getBbHeight() + 0.5 + y), z, 1, 0, 0, 0, 0);
		}
		if (entity.getPersistentData().getInt("Dendro") > 0) {
			entity.getPersistentData().putInt("Dendro", entity.getPersistentData().getInt("Dendro") - 1);
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_DENDRO.get()), x, (entity.getBbHeight() + 0.5 + y), z, 1, 0, 0, 0, 0);
		}
		if (entity.getPersistentData().getInt("Electro") > 0) {
			entity.getPersistentData().putInt("Electro", entity.getPersistentData().getInt("Electro") - 1);
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_ELECTRO.get()), x, (entity.getBbHeight() + 0.5 + y), z, 1, 0, 0, 0, 0);
		}
		if (entity.getPersistentData().getInt("Hydro") > 0) {
			entity.getPersistentData().putInt("Hydro", entity.getPersistentData().getInt("Hydro") - 1);
			if (entity.getPersistentData().getInt("Electro") > 0 && entity.getPersistentData().getInt("Electro_Charged_Cd") <= 0) {
				entity.getPersistentData().putInt("Electro_Charged_Cd", 20);
				LivingEntity attacker = ((LivingEntity) entity).getLastAttacker();
				double elemental_mastery = 0;
				if (attacker != null)
					elemental_mastery = attacker.getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue();
				entity.hurt(new DamageSource(world.holderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), attacker),
						(float) (2 * (1 - (entity instanceof LivingEntity _livingEntity9 && _livingEntity9.getAttributes().hasAttribute(ErModAttributes.ELECTRO_RES) ? _livingEntity9.getAttribute(ErModAttributes.ELECTRO_RES).getValue() : 0) / 100)
								* EntityHurtEvent.getElementalMasteryMultiply(1, elemental_mastery)));
				entity.setDeltaMovement(new Vec3(0, 0, 0));
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (Entity entityiterator : _entfound) {
						if (EntityHurtEvent.shouldHurt(attacker, entityiterator) && entityiterator instanceof LivingEntity && entityiterator.getPersistentData().getInt("Hydro") > 0
								&& entityiterator.getPersistentData().getInt("Electro_Charged_Cd") <= 0) {
							entityiterator.getPersistentData().putInt("Electro_Charged_Cd", 10);
							if (world instanceof ServerLevel _level) {
								ArcEntity entityToSpawn = ErModEntities.ARC.get().spawn(_level, BlockPos.containing(x, y + entity.getBbHeight() * 0.7, z), MobSpawnType.MOB_SUMMONED);
								entityToSpawn.setActiveTarget(entityiterator.getId());
								entityToSpawn.setSource(attacker);
								if (entityToSpawn != null) {
									entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
								}
							}
						}
					}
				}
				entity.getPersistentData().putInt("Hydro", entity.getPersistentData().getInt("Hydro") - 10);
				entity.getPersistentData().putInt("Electro", entity.getPersistentData().getInt("Electro") - 10);
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_HYDRO.get()), x, (entity.getBbHeight() + 0.5 + y), z, 1, 0, 0, 0, 0);
		}
		if (entity.getPersistentData().getInt("Frozen") > 0) {
			entity.getPersistentData().putInt("Frozen", entity.getPersistentData().getInt("Frozen") - entity.getPersistentData().getInt("Frozen_timer"));
			entity.getPersistentData().putInt("Frozen_timer", entity.getPersistentData().getInt("Frozen_timer") + 1);
			entity.makeStuckInBlock(Blocks.AIR.defaultBlockState(), new Vec3(0.25, 0.05, 0.25));
			if (entity.getPersistentData().getInt("Frozen") <= 0) {
				entity.getPersistentData().putInt("Frozen_timer", 0);
				((LivingEntity) entity).getAttribute(Attributes.MOVEMENT_SPEED).removeModifier(new AttributeModifier(ResourceLocation.withDefaultNamespace("er.frozen.speed"), -100, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
				world.levelEvent(2001, BlockPos.containing(x, y, z), Block.getId(Blocks.FROSTED_ICE.defaultBlockState()));
			}
		}
		if (entity.getPersistentData().getInt("Pyro") > 0) {
			if (entity.getPersistentData().getInt("Dendro") > 0) {
				entity.getPersistentData().putInt("Dendro", entity.getPersistentData().getInt("Dendro") - 1);
				if (entity.getPersistentData().getInt("Dendro") % 10 <= 1) {
					if (world instanceof ServerLevel _level)
						_level.sendParticles(ParticleTypes.FLAME, (x - entity.getBbWidth() / 2), y, (z - entity.getBbWidth() / 2), 10, (entity.getBbWidth()), (entity.getBbHeight()), (entity.getBbWidth()), 0);
					entity.hurt(new DamageSource(world.holderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction")))),
							(float) (0.5 * (1 - (entity instanceof LivingEntity && ((LivingEntity) entity).getAttribute(ErModAttributes.PYRO_RES) != null ? ((LivingEntity) entity).getAttribute(ErModAttributes.PYRO_RES).getValue() : 10) / 100)
									* EntityHurtEvent.getElementalMasteryMultiply(1, ((LivingEntity) entity).getLastAttacker().getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue())));
				}
			} else {
				entity.getPersistentData().putInt("Pyro", entity.getPersistentData().getInt("Pyro") - 1);
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_PYRO.get()), x, (entity.getBbHeight() + 0.5 + y), z, 1, 0, 0, 0, 0);
		}
	}
}
