import json
import os
import sys
import pandas as pd
import re

def normalize_name(name):
    """
    将名称转换为键名格式：小写，空格及非字母数字字符替换为下划线，
    并合并连续的下划线，去除首尾下划线。
    """
    if not name:
        return None
    s = re.sub(r'[^a-z0-9]+', '_', name.lower())
    s = s.strip('_')
    return s

def generate_item_model(modid, register_name, model_type):
    """
    根据模型类型生成物品模型 JSON 内容
    - model_type = "generated" 返回标准物品模型（item/generated）
    - model_type = "spawn_egg" 返回刷怪蛋模型（item/template_spawn_egg）
    """
    if model_type == "generated":
        return {
            "parent": "item/generated",
            "textures": {
                "layer0": f"{modid}:item/{register_name}"
            }
        }
    elif model_type == "spawn_egg":
        return {
            "parent": "item/template_spawn_egg"
        }
    else:
        # 未知类型，返回空字典或 None，调用方需处理
        return None

def main():
    config_path = "config.json"
    if not os.path.exists(config_path):
        print(f"错误：找不到配置文件 {config_path}")
        sys.exit(1)

    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)

    modid = config.get("modid")
    input_file = config.get("input")
    ignore_lang = config.get("ignore_lang", False)  # 默认为 False

    if not modid or not input_file:
        print("错误：配置文件中缺少 modid 或 input 字段")
        sys.exit(1)

    config_dir = os.path.dirname(os.path.abspath(config_path))
    excel_path = os.path.join(config_dir, input_file) if not os.path.isabs(input_file) else input_file

    if not os.path.exists(excel_path):
        print(f"错误：Excel 文件不存在 {excel_path}")
        sys.exit(1)

    # 读取所有工作表
    try:
        sheets = pd.read_excel(excel_path, sheet_name=None, dtype=str)
    except Exception as e:
        print(f"无法读取 Excel 文件：{e}")
        sys.exit(1)

    en_dict = {}
    zh_dict = {}

    # 遍历每个工作表
    for sheet_name, df in sheets.items():
        print(f"正在处理工作表: {sheet_name}")
        sheet_part = normalize_name(sheet_name)
        if not sheet_part:
            print(f"警告：工作表名 '{sheet_name}' 规范化后为空，跳过")
            continue

        # 判断是否为 item 工作表（不区分大小写）
        is_item_sheet = (sheet_name.lower() == "item")

        # 遍历 DataFrame 的每一行
        for index, row in df.iterrows():
            # 确保至少有3列：注册名、英文、中文
            if len(row) < 3:
                print(f"  警告：第 {index+2} 行列数不足3，跳过")
                continue

            reg_name = str(row.iloc[0]).strip() if pd.notna(row.iloc[0]) else ""
            en_text = str(row.iloc[1]).strip() if pd.notna(row.iloc[1]) else ""
            zh_text = str(row.iloc[2]).strip() if pd.notna(row.iloc[2]) else ""

            # 如果英文名为空，无法生成键名，跳过此行
            if not en_text:
                print(f"  警告：第 {index+2} 行英文名为空，跳过")
                continue

            # 确定注册名部分
            if reg_name:
                key_part = reg_name
            else:
                key_part = normalize_name(en_text)
                if not key_part:
                    print(f"  警告：无法从英文名 '{en_text}' 生成有效键名，跳过")
                    continue

            # 组合完整键名
            key = f"{modid}.{sheet_part}.{key_part}"

            # 如果未忽略语言文件，则添加翻译条目
            if not ignore_lang:
                if en_text:
                    en_dict[key] = en_text
                if zh_text:
                    zh_dict[key] = zh_text

            # 如果是 item 工作表，检查是否需要生成模型
            if is_item_sheet:
                # 读取第四列（model列），如果存在
                model_value = ""
                if len(row) >= 4:
                    model_value = str(row.iloc[3]).strip() if pd.notna(row.iloc[3]) else ""

                # 支持多种模型类型
                if model_value.lower() in ["generated", "spawn_egg"]:
                    model_type = model_value.lower()
                    # 生成模型文件
                    model_dir = os.path.join("src", "main", "resources", "assets", modid, "models", "item")
                    os.makedirs(model_dir, exist_ok=True)
                    model_path = os.path.join(model_dir, f"{key_part}.json")

                    model_content = generate_item_model(modid, key_part, model_type)
                    if model_content:
                        try:
                            with open(model_path, 'w', encoding='utf-8') as f:
                                json.dump(model_content, f, ensure_ascii=False, indent=4)
                            print(f"  已生成模型: {model_path} (类型: {model_type})")
                        except Exception as e:
                            print(f"  错误：生成模型 {model_path} 失败：{e}")
                    else:
                        print(f"  警告：未知模型类型 '{model_type}'，跳过模型生成")

    # 如果未忽略语言文件，则写入语言文件
    if not ignore_lang:
        lang_dir = os.path.join("src", "main", "resources", "assets", modid, "lang")
        os.makedirs(lang_dir, exist_ok=True)

        en_output = os.path.join(lang_dir, "en_us.json")
        with open(en_output, 'w', encoding='utf-8') as f:
            json.dump(en_dict, f, ensure_ascii=False, indent=4)
        print(f"已生成 {en_output}")

        zh_output = os.path.join(lang_dir, "zh_cn.json")
        with open(zh_output, 'w', encoding='utf-8') as f:
            json.dump(zh_dict, f, ensure_ascii=False, indent=4)
        print(f"已生成 {zh_output}")
    else:
        print("根据配置忽略生成语言文件")

    print("所有文件生成完成")

if __name__ == "__main__":
    main()
