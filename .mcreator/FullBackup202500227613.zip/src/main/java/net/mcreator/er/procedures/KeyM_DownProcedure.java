package net.mcreator.er.procedures;

import net.wither.er.network.ErItemVariables;
import net.wither.er.entity.ErEntityInterface;
import net.wither.er.entity.ArtifactSlot;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.MenuProvider;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.er.world.inventory.ErEquipmentGUIMenu;
import net.mcreator.er.init.ErModMenus;

import io.netty.buffer.Unpooled;

public class KeyM_DownProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof ServerPlayer _ent) {
			BlockPos _bpos = BlockPos.containing(x, y, z);
			_ent.openMenu(new MenuProvider() {
				@Override
				public Component getDisplayName() {
					return Component.literal("ErEquipmentGUI");
				}

				@Override
				public boolean shouldTriggerClientSideContainerClosingOnOpen() {
					return false;
				}

				@Override
				public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
					return new ErEquipmentGUIMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
				}
			}, _bpos);
		}
		ErItemVariables.PlayerVariables _vars = entity.getData(ErItemVariables.PLAYER_VARIABLES);
		if (entity instanceof Player _player && _player.containerMenu instanceof ErModMenus.MenuAccessor _menu) {
			_menu.getSlots().get(0).set(_vars.Vision.copy());
			_menu.getSlots().get(1).set(_vars.Stella_Fortuna.copy());
			if (entity instanceof ErEntityInterface entityInterface) {
				for (ArtifactSlot slot : ArtifactSlot.values())
					_menu.getSlots().get(2 + slot.getId()).set(entityInterface.getArtifact(slot).copy());
			}
			_player.containerMenu.broadcastChanges();
		}
	}
}