package net.mcreator.er.potion;

import net.mcreator.er.ErMod;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.entity.LivingEntity;
import org.jetbrains.annotations.NotNull;

public class AdventureHealingMobEffect extends MobEffect {
	public AdventureHealingMobEffect() {
		super(MobEffectCategory.NEUTRAL, -6684877);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int tick, int amp) {
		return tick % 20 == 0;
	}

	@Override
	public boolean applyEffectTick(@NotNull LivingEntity entity, int amp) {
		entity.heal(entity.getMaxHealth() * 0.06f);
		return super.applyEffectTick(entity,amp);
    }
}