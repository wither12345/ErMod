/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

import net.minecraft.world.inventory.Slot;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.registries.Registries;
import net.minecraft.client.Minecraft;

import net.mcreator.er.world.inventory.LeyLineMapGuiMenu;
import net.mcreator.er.world.inventory.ErEquipmentGUIMenu;
import net.mcreator.er.world.inventory.ArtifactGUIMenu;
import net.mcreator.er.world.inventory.AlchemyCraftGuiMenu;
import net.mcreator.er.network.MenuStateUpdateMessage;
import net.mcreator.er.ErMod;

import java.util.Map;

public class ErModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, ErMod.MODID);
	public static final DeferredHolder<MenuType<?>, MenuType<ErEquipmentGUIMenu>> ER_EQUIPMENT_GUI = REGISTRY.register("er_equipment_gui", () -> IMenuTypeExtension.create(ErEquipmentGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ArtifactGUIMenu>> ARTIFACT_GUI = REGISTRY.register("artifact_gui", () -> IMenuTypeExtension.create(ArtifactGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<AlchemyCraftGuiMenu>> ALCHEMY_CRAFT_GUI = REGISTRY.register("alchemy_craft_gui", () -> IMenuTypeExtension.create(AlchemyCraftGuiMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<LeyLineMapGuiMenu>> LEY_LINE_MAP_GUI = REGISTRY.register("ley_line_map_gui", () -> IMenuTypeExtension.create(LeyLineMapGuiMenu::new));

	public interface MenuAccessor {
		Map<String, Object> getMenuState();

		Map<Integer, Slot> getSlots();

		default void sendMenuStateUpdate(Player player, int elementType, String name, Object elementState, boolean needClientUpdate) {
			getMenuState().put(elementType + ":" + name, elementState);
			if (player instanceof ServerPlayer serverPlayer) {
				PacketDistributor.sendToPlayer(serverPlayer, new MenuStateUpdateMessage(elementType, name, elementState));
			} else if (player.level().isClientSide) {
				if (Minecraft.getInstance().screen instanceof ErModScreens.ScreenAccessor accessor && needClientUpdate)
					accessor.updateMenuState(elementType, name, elementState);
				PacketDistributor.sendToServer(new MenuStateUpdateMessage(elementType, name, elementState));
			}
		}

		default <T> T getMenuState(int elementType, String name, T defaultValue) {
			try {
				return (T) getMenuState().getOrDefault(elementType + ":" + name, defaultValue);
			} catch (ClassCastException e) {
				return defaultValue;
			}
		}
	}
}