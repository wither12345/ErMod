package net.mcreator.er.procedures;

import net.wither.er.network.ErItemVariables;
import net.wither.er.elements.Element;
import net.wither.er.elements.AuraContainerInterface;
import net.wither.er.ErDamageSource;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.er.item.MemoryofRovingGalesItem;
import net.mcreator.er.entity.TravelerTornadoEntity;
import net.mcreator.er.EntityHurtEvent;

import java.util.Comparator;
import java.util.ArrayList;

public class TravelerTornadoTickingProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		Entity owner = null;
		entity.getPersistentData().putDouble("aliveTick", (entity.getPersistentData().getDouble("aliveTick") + 1));
		if (entity.getPersistentData().getDouble("aliveTick") > 5 && entity instanceof TravelerTornadoEntity tornado) {
			for (Entity entityiterator : new ArrayList<>(world.players())) {
				if ((entityiterator.getStringUUID()).equals(tornado.getEntityData().get(TravelerTornadoEntity.DATA_owner))) {
					owner = entityiterator;
				}
			}
			VacuumFieldsDisplacingProcedure.execute(world, x, y + 2.5, z, owner, 10, 0.5);
			entity.setDeltaMovement(new Vec3(((-1) * (Math.sin((entity.getYRot() / 180d) * Math.PI) / 5)), (entity.getDeltaMovement().y()), (Math.cos((entity.getYRot() / 180d) * Math.PI) / 5)));
			if (entity.getPersistentData().getDouble("aliveTick") % 10 == 0) {
				if (owner instanceof Player player && player.getData(ErItemVariables.PLAYER_VARIABLES).Stella_Fortuna.getItem() instanceof MemoryofRovingGalesItem item) {
					{
						final Vec3 _center = new Vec3(x, (y + 2.5), z);
						for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(5 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
							if (EntityHurtEvent.shouldHurt(owner, entityiterator) && entityiterator instanceof LivingEntity && !(entity == entityiterator)) {
								entityiterator.hurt(
										new ErDamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:elemental_skill_damage"))), owner, 1,
												200),
										(float) ((owner instanceof LivingEntity _livingEntity10 && _livingEntity10.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE) ? _livingEntity10.getAttribute(Attributes.ATTACK_DAMAGE).getValue() : 0)
												* item.DamageMulti(30, 0)));
							}
						}
					}
					int absorption = tornado.getEntityData().get(TravelerTornadoEntity.DATA_Absorption);
					if (absorption == 0) {
						{
							final Vec3 _center = new Vec3(x, (y + 1.5), z);
							for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
								if (entityiterator instanceof AuraContainerInterface auraContainerInterface) {
									if (!auraContainerInterface.getAuraContainer().getAura().get(Element.Category.ELECTRO.getId()).isEmpty()) {
										absorption = Math.max(absorption, 1);
									}
									if (!auraContainerInterface.getAuraContainer().getAura().get(Element.Category.HYDRO.getId()).isEmpty()) {
										absorption = Math.max(absorption, 2);
									}
									if (!auraContainerInterface.getAuraContainer().getAura().get(Element.Category.PYRO.getId()).isEmpty()) {
										absorption = Math.max(absorption, 3);
									}
									if (!auraContainerInterface.getAuraContainer().getAura().get(Element.Category.CRYO.getId()).isEmpty()) {
										absorption = 4;
									}
								}
							}
						}
						if (absorption != 0) {
							tornado.getEntityData().set(TravelerTornadoEntity.DATA_Absorption, absorption);
						}
					} else {
						{
							final Vec3 _center = new Vec3(x, (y + 2.5), z);
							for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(5 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
								if (EntityHurtEvent.shouldHurt(owner, entityiterator) && entityiterator instanceof LivingEntity && !(entity == entityiterator)) {
									entityiterator.hurt(
											new ErDamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:elemental_skill_damage"))), owner,
													MemoryofRovingGalesItem.absorbElement(absorption), 200),
											(float) ((owner instanceof LivingEntity _livingEntity15 && _livingEntity15.getAttributes().hasAttribute(Attributes.ATTACK_DAMAGE) ? _livingEntity15.getAttribute(Attributes.ATTACK_DAMAGE).getValue() : 0)
													* item.DamageMulti(30, 1)));
								}
							}
						}
					}
				}
			}
			if (entity.getPersistentData().getDouble("aliveTick") >= 120) {
				if (!entity.level().isClientSide())
					entity.discard();
			}
		}
	}
}