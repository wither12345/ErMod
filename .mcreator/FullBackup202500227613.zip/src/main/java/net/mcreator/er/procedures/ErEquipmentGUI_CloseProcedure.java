package net.mcreator.er.procedures;

import net.wither.er.entity.ArtifactSlot;
import net.wither.er.entity.ErEntityInterface;
import net.wither.er.network.ErItemVariables;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;

import net.mcreator.er.init.ErModMenus;
import net.mcreator.er.StellaFortunas;

public class ErEquipmentGUI_CloseProcedure {
	public static void execute(Entity entity) {
		String type = "";
		String uuid = "";
		double count = 0;
		ItemStack item = ItemStack.EMPTY;
		if (entity instanceof ServerPlayer plrSlotItem && entity instanceof ErEntityInterface erEntityInterface) {
			ErItemVariables.PlayerVariables _vars = entity.getData(ErItemVariables.PLAYER_VARIABLES);
			_vars.Vision = (plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(0).getItem() : ItemStack.EMPTY).copy();
			_vars.Stella_Fortuna = (plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(1).getItem() : ItemStack.EMPTY).copy();
			StellaFortunas.applyAttr((LivingEntity) entity, _vars.Stella_Fortuna);
			item = _vars.Flower_Of_Life.copy();
			ArtifactAttrRemoveProcedure.execute(entity, item);
			item = _vars.Plume_of_Death.copy();
			ArtifactAttrRemoveProcedure.execute(entity, item);
			item = _vars.Sands_Of_Eon.copy();
			ArtifactAttrRemoveProcedure.execute(entity, item);
			item = _vars.Goblet_Of_Eonothem.copy();
			ArtifactAttrRemoveProcedure.execute(entity, item);
			item = _vars.Circlet_Of_Logos.copy();
			ArtifactAttrRemoveProcedure.execute(entity, item);

			if(plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu){
				for(ArtifactSlot slot : ArtifactSlot.values()){
					erEntityInterface.setArtifact(slot, _menu.getSlots().get(slot.getId() + 2).getItem());
				}
				erEntityInterface.updateArtifact();
			}

			//_vars.Flower_Of_Life = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(2).getItem() : ItemStack.EMPTY).copy();
			//erEntityInterface.setArtifact(ArtifactSlot.FLOWER_OF_LIFE, _vars.Flower_Of_Life);
			//ArtifactAttrAddProcedure.execute(entity, _vars.Flower_Of_Life);

			_vars.syncPlayerVariables(entity);
		}
	}
}