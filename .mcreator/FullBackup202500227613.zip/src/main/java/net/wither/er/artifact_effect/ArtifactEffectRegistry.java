package net.wither.er.artifact_effect;

import net.mcreator.er.ErMod;
import net.mcreator.er.init.ErModAttributes;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NewRegistryEvent;
import net.neoforged.neoforge.registries.RegistryBuilder;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class ArtifactEffectRegistry {
    public static final ResourceKey<Registry<ArtifactEffect>> ARTIFACT_EFFECT = ResourceKey.createRegistryKey(ResourceLocation.fromNamespaceAndPath(ErMod.MODID, "artifact_effect"));
    public static final Registry<ArtifactEffect> ARTIFACT_REGISTRY = new RegistryBuilder<>(ARTIFACT_EFFECT).sync(true).defaultKey(ResourceLocation.parse("er:empty")).maxId(256).create();

    @SubscribeEvent
    public static void registerRegistries(NewRegistryEvent event) {
        event.register(ARTIFACT_REGISTRY);
    }


    public static final DeferredRegister<ArtifactEffect> ARTIFACT_EFFECTS = DeferredRegister.create(ARTIFACT_REGISTRY, ErMod.MODID);

    public static final DeferredHolder<ArtifactEffect,ArtifactEffect> EMPTY = ARTIFACT_EFFECTS.register("empty",
            ArtifactEffect::new
    );
    public static final DeferredHolder<ArtifactEffect,ArtifactEffect> ADVENTURER = ARTIFACT_EFFECTS.register("adventurer",
            () -> new TwoSetAttrEffect(Attributes.MAX_HEALTH, new AttributeModifier(ResourceLocation.parse("er:adventure"), 20, AttributeModifier.Operation.ADD_VALUE))
    );
    public static final DeferredHolder<ArtifactEffect,ArtifactEffect> LUCKY_DOG = ARTIFACT_EFFECTS.register("lucky_dog",
            () -> new TwoSetAttrEffect(Attributes.ARMOR, new AttributeModifier(ResourceLocation.parse("er:lucky_dog"), 100, AttributeModifier.Operation.ADD_VALUE))
    );
    public static final DeferredHolder<ArtifactEffect,ArtifactEffect> TRAVELING_DOCTOR = ARTIFACT_EFFECTS.register("traveling_doctor",
            () -> new TwoSetAttrEffect(ErModAttributes.INCOMING_HEALING_BONUS, new AttributeModifier(ResourceLocation.parse("er:traveling_doctor"), 0.2, AttributeModifier.Operation.ADD_MULTIPLIED_BASE))
    );
}
