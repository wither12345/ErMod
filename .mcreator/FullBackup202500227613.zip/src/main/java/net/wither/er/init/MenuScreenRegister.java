package net.wither.er.init;


import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.wither.er.client.gui.AlchemyGuiScreen;
import net.wither.er.client.gui.ArtifactTransmuterGuiScreen;
import net.wither.er.client.gui.WeaponEnhanceGuiScreen;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class MenuScreenRegister{
    @SubscribeEvent
    public static void loadScreen(RegisterMenuScreensEvent event){
        event.register(ErMenus.WEAPON_ENHANCE_GUI.get(), WeaponEnhanceGuiScreen::new);
        event.register(ErMenus.ARTIFACT_TRANSMUTER_GUI.get(), ArtifactTransmuterGuiScreen::new);
        event.register(ErMenus.ALCHEMY_GUI.get(), AlchemyGuiScreen::new);
    }
}
