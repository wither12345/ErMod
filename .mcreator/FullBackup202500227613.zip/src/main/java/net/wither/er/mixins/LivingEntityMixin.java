package net.wither.er.mixins;

import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.mcreator.er.ErMod;
import net.minecraft.core.Holder;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.network.PacketDistributor;
import net.wither.er.artifact_effect.ArtifactEffect;
import net.wither.er.artifact_effect.TwoSetAttrEffect;
import net.wither.er.elements.AuraContainer;
import net.wither.er.elements.AuraContainerInterface;
import net.wither.er.entity.ArtifactSlot;
import net.wither.er.entity.ErEntityInterface;
import net.wither.er.init.DataComponentsRegister;
import net.wither.er.item.data.artifactdata.ArtifactData;
import net.wither.er.network.ErShieldData;
import net.wither.er.shield.ErShield;
import net.wither.er.shield.ShieldRegistry;
import net.wither.er.shield.ShieldStack;
import org.checkerframework.common.aliasing.qual.Unique;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.*;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin extends Entity implements Attackable, ErEntityInterface , AuraContainerInterface {
	@Unique
	private ArrayList<ShieldStack> shields = new ArrayList<>();
	@Unique
	private AuraContainer container = new AuraContainer(this);
	private static final EntityDataAccessor<Integer> ELEMENT = SynchedEntityData.defineId(LivingEntity.class, EntityDataSerializers.INT);
	@Unique
	private final NonNullList<ItemStack> artifactItem = NonNullList.withSize(5, ItemStack.EMPTY);
	@Unique
	private Object2IntMap<Holder<ArtifactEffect>> effectMap = new Object2IntArrayMap<>();


	@Shadow
	public abstract boolean addEffect(MobEffectInstance instance) ;

	@Shadow public abstract AttributeMap getAttributes();

	@Shadow public abstract ItemStack getMainHandItem();

	public LivingEntityMixin(EntityType<?> p_19870_, Level p_19871_) {
		super(p_19870_, p_19871_);
	}

	public List<ShieldStack> getShieldStacks() {
		return this.shields;
	}

	public List<ErShield> getShields() {
		List<ErShield> erShields = new ArrayList<>();
		for (ShieldStack shield : shields)
			erShields.add(shield.getShield());
		return erShields;
	}

	public void addShield(ShieldStack shield) {
		shield.getShield().start(this);
		this.shields.add(shield);
		syncShield();
	}

	@Override
	public AuraContainer getAuraContainer() {
		return container;
	}

	@Inject(method = "addAdditionalSaveData", at = @At("HEAD"))
	public void addAdditionalSaveData(CompoundTag compound, CallbackInfo info) {
		CompoundTag tag = new CompoundTag();
		for (ShieldStack shield : shields) {
			tag.put(ShieldRegistry.SHIELD_REGISTRY.getKey(shield.getShield()).toString(), shield.toTag());
		}
		compound.put("ErShield", tag);

		ListTag listtag = new ListTag();

        for (ItemStack itemstack : this.artifactItem) {
            if (!itemstack.isEmpty()) {
                listtag.add(itemstack.save(this.registryAccess()));
            } else {
                listtag.add(new CompoundTag());
            }
        }

		compound.put("ArtifactItems", listtag);
	}

	@Inject(method = "readAdditionalSaveData", at = @At("HEAD"))
	public void readAdditionalSaveData(CompoundTag compound, CallbackInfo info) {
		setShields(compound.getCompound("ErShield"));

		CompoundTag compoundtag1;
		if (compound.contains("ArtifactItems", 9)) {
			ListTag list_tag = compound.getList("ArtifactItems", 10);

			for(int l = 0; l < this.artifactItem.size(); ++l) {
				compoundtag1 = list_tag.getCompound(l);
				this.artifactItem.set(l, ItemStack.parseOptional(this.registryAccess(), compoundtag1));
			}
			this.updateArtifact();
		}
	}

	@Inject(method = "defineSynchedData" , at = @At("TAIL"))
	protected void defineSynchedData(SynchedEntityData.Builder builder, CallbackInfo info) {
		builder.define(ELEMENT, 0);
	}

	@Inject(method = "dropAllDeathLoot", at = @At("TAIL"))
	public void dropAllDeathLoot(ServerLevel level, DamageSource source, CallbackInfo info) {
		this.dropArtifact();
	}

	public void removeShield(ErShield shield) {
		shield.end(this);
        this.shields.removeIf(shieldstack -> shieldstack.getShield() == shield);
		syncShield();
	}

	public void setShields(CompoundTag tag) {
		Set<String> keys = tag.getAllKeys();
		this.shields.clear();
		for (String key : keys) {
			ErShield shield = ShieldRegistry.SHIELD_REGISTRY.get(ResourceLocation.parse(key));
			this.shields.add(new ShieldStack(shield, tag.getCompound(key)));
		}
	}

	public void cleanShield() {
		shields.clear();
		syncShield();
	}

	public void syncShield() {
		CompoundTag tag = new CompoundTag();
		for (ShieldStack shield : shields) {
			tag.put(ShieldRegistry.SHIELD_REGISTRY.getKey(shield.getShield()).toString(), shield.toTag());
		}
		PacketDistributor.sendToPlayersTrackingEntityAndSelf(this, new ErShieldData(this.getId(), tag));
	}

	public void syncShield(ServerPlayer player) {
		CompoundTag tag = new CompoundTag();
		for (ShieldStack shield : shields) {
			tag.put(ShieldRegistry.SHIELD_REGISTRY.getKey(shield.getShield()).toString(), shield.toTag());
		}
		PacketDistributor.sendToPlayer(player, new ErShieldData(this.getId(), tag));
	}

	@Override
	public int getElements() {
		return this.entityData.get(ELEMENT);
	}

	@Override
	public void updateElements(int elements) {
		this.entityData.set(ELEMENT, elements);
	}

	@Override
	public void setArtifact(ArtifactSlot slot, ItemStack itemStack) {
		ArtifactData data = getArtifact(slot).getComponents().get(DataComponentsRegister.ARTIFACT.get());
		if(data != null)
			data.remove((LivingEntity)(Object) this);
		this.artifactItem.set(slot.getId(), itemStack);
		data = itemStack.getComponents().get(DataComponentsRegister.ARTIFACT.get());
		if(data != null)
			data.apply((LivingEntity)(Object) this);
	}

	@Override
	public ItemStack getArtifact(ArtifactSlot slot) {
		return this.artifactItem.get(slot.getId()) ;
	}

	@Override
	public void dropArtifact() {
		for(ItemStack artifact : artifactItem){
			this.level().addFreshEntity(new ItemEntity(level(),getX(),getY(),getZ(), artifact));
		}
	}

	@Override
	public void updateArtifact(){
		Object2IntMap<Holder<ArtifactEffect>> newEffectMap = new Object2IntArrayMap<>();
		for (ItemStack artifact : artifactItem) {
			ArtifactData artifactData = artifact.getComponents().get(DataComponentsRegister.ARTIFACT.get());
			if (artifactData != null) {
				Holder<ArtifactEffect> effect = artifactData.effect();
				newEffectMap.put(effect, newEffectMap.getOrDefault(effect, 0) + 1);
			}
		}
		if(!newEffectMap.equals(effectMap)){
			removeArtifactAttr();
			this.effectMap = newEffectMap;
			updateArtifactAttr();
		}
	}

	@Override
	public int getArtifactEffectLevel(Holder<ArtifactEffect> effectHolder){
		return effectMap.getOrDefault(effectHolder, 0) ;
	}

	private void removeArtifactAttr(){
		AttributeMap attributeMap = this.getAttributes() ;
		for(Object2IntMap.Entry<Holder<ArtifactEffect>> holderEntry : effectMap.object2IntEntrySet()){
			ArtifactEffect effect = holderEntry.getKey().value() ;
			if(effect instanceof TwoSetAttrEffect attrEffect)
				attrEffect.removeAttributeModifiers(attributeMap);
		}
	}

	private void updateArtifactAttr(){
		AttributeMap attributeMap = this.getAttributes() ;
		for(Object2IntMap.Entry<Holder<ArtifactEffect>> holderEntry : effectMap.object2IntEntrySet()){
			ArtifactEffect effect = holderEntry.getKey().value() ;
			if(effect instanceof TwoSetAttrEffect attrEffect)
				attrEffect.addAttributeModifiers(attributeMap, holderEntry.getIntValue());
		}
	}
}
