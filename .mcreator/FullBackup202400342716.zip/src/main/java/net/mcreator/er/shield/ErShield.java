package net.mcreator.er.shield;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.client.gui.Gui;

public abstract class ErShield {
	public float health;
	public int restTime;

	public void tick(LivingEntity owner) {
		restTime--;
	}

	public abstract void start(LivingEntity owner);

	public abstract void end(LivingEntity owner, boolean broken);

	public abstract Gui.HeartType getHeartType();

	public abstract float onHurt(LivingEntity owner, DamageSource source, int element);
}
