
package net.mcreator.er.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.er.entity.FatuiElectroCicinMageEntity;
import net.mcreator.er.client.model.ModelFatui_Electro_Cicin_Mage;

public class FatuiElectroCicinMageRenderer extends MobRenderer<FatuiElectroCicinMageEntity, ModelFatui_Electro_Cicin_Mage<FatuiElectroCicinMageEntity>> {
	public FatuiElectroCicinMageRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelFatui_Electro_Cicin_Mage(context.bakeLayer(ModelFatui_Electro_Cicin_Mage.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(FatuiElectroCicinMageEntity entity) {
		return ResourceLocation.parse("er:textures/entities/fatui_electro_cicin_mage.png");
	}
}
