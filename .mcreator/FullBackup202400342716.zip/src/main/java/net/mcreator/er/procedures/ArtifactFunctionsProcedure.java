package net.mcreator.er.procedures;

import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.ItemTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.component.DataComponents;

import net.mcreator.er.item.ArtifactItem;
import net.mcreator.er.ERConfig;

import java.util.Random;
import java.util.List;

public class ArtifactFunctionsProcedure {
	public static String getUuid(ItemStack itemstack, int sort) {
		if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:flower_of_life")))) {
			if (sort == 4)
				return "er.flower.main";
			else
				return "er.flower.sort." + new java.text.DecimalFormat("#").format(sort);
		}
		if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:plume_of_death")))) {
			if (sort == 4)
				return "er.plume.main";
			else
				return "er.plume.sort." + new java.text.DecimalFormat("#").format(sort);
		}
		if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:sands_of_eon")))) {
			if (sort == 4)
				return "er.sands.main";
			else
				return "er.sands.sort." + new java.text.DecimalFormat("#").format(sort);
		}
		if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:goblet_of_eonothem")))) {
			if (sort == 4)
				return "er.goblet.main";
			else
				return "er.goblet.sort." + new java.text.DecimalFormat("#").format(sort);
		}
		if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:circlet_of_logos.")))) {
			if (sort == 4)
				return "er.circlet.main";
			else
				return "er.circlet.sort." + new java.text.DecimalFormat("#").format(sort);
		}
		return "er.error.nothing";
	}

	public static double final_attribute(ItemStack itemstack, double sort) {
		String attr_name = "";
		boolean mult = false;
		double original_count = 0;
		double rarity = 0;
		if (itemstack.getItem() instanceof ArtifactItem) {
			if (sort == 0) {
				attr_name = itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getString("main_attribute_name");
				original_count = itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("main_attribute_count");
				rarity = itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("rarity");
				mult = itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBoolean("main_attribute_multiplied");
				original_count *= itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("level") * 0.285 + 1;
			} else {
				attr_name = itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getString(("minor_attribute_name_" + new java.text.DecimalFormat("#").format(sort - 1)));
				original_count = itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble(("minor_attribute_count_" + new java.text.DecimalFormat("#").format(sort - 1)));
				rarity = itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("rarity");
				mult = itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBoolean(("minor_attribute_multiplied_" + new java.text.DecimalFormat("#").format(sort - 1)));
				original_count *= itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble(("minor_count_multiplier_" + new java.text.DecimalFormat("#").format(sort - 1)));
			}
			if (!mult && (attr_name).equals("generic.attack_damage")) {
				if (rarity >= 5) {
					return ERConfig.MYTHIC_DMG_SCALING.get() * original_count;
				} else if (rarity >= 4) {
					return ERConfig.LEGENDARY_DMG_SCALING.get() * original_count;
				} else if (rarity >= 3) {
					return ERConfig.EPIC_DMG_SCALING.get() * original_count;
				} else if (rarity >= 2) {
					return ERConfig.RARE_DMG_SCALING.get() * original_count;
				} else if (rarity >= 1) {
					return ERConfig.UNCOMMON_DMG_SCALING.get() * original_count;
				} else {
					return ERConfig.COMMON_DMG_SCALING.get() * original_count;
				}
			} else if (!mult && (attr_name).equals("generic.max_health")) {
				if (rarity >= 5) {
					return ERConfig.MYTHIC_HP_SCALING.get() * original_count;
				} else if (rarity >= 4) {
					return ERConfig.LEGENDARY_HP_SCALING.get() * original_count;
				} else if (rarity >= 3) {
					return ERConfig.EPIC_HP_SCALING.get() * original_count;
				} else if (rarity >= 2) {
					return ERConfig.RARE_HP_SCALING.get() * original_count;
				} else if (rarity >= 1) {
					return ERConfig.UNCOMMON_HP_SCALING.get() * original_count;
				} else {
					return ERConfig.COMMON_HP_SCALING.get() * original_count;
				}
			} else {
				if (rarity >= 5) {
					return ERConfig.MYTHIC_OTHER_SCALING.get() * original_count;
				} else if (rarity >= 4) {
					return ERConfig.LEGENDARY_OTHER_SCALING.get() * original_count;
				} else if (rarity >= 3) {
					return ERConfig.EPIC_OTHER_SCALING.get() * original_count;
				} else if (rarity >= 2) {
					return ERConfig.RARE_OTHER_SCALING.get() * original_count;
				} else if (rarity >= 1) {
					return ERConfig.UNCOMMON_OTHER_SCALING.get() * original_count;
				} else {
					return ERConfig.COMMON_OTHER_SCALING.get() * original_count;
				}
			}
		}
		return 0;
	}

	public static void main_attribute_rolling(ItemStack itemstack) {
		List<String> config_get = null;
		String[] effects_type = null;
		if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:flower_of_life")))) {
			config_get = ERConfig.FLOWER_OF_LIFE_MAIN_ATTR.get();
		} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:plume_of_death")))) {
			config_get = ERConfig.PLUME_OF_DEATH_ATTR.get();
		} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:sands_of_eon")))) {
			config_get = ERConfig.SANDS_OF_EON_ATTR.get();
		} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:goblet_of_eonothem")))) {
			config_get = ERConfig.GOBLET_OF_EONOTHEM_ATTR.get();
		} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:circlet_of_logos")))) {
			config_get = ERConfig.CIRCLET_OF_LOGOS_ATTR.get();
		}
		effects_type = config_get.toArray(new String[config_get.size()]);
		int index = new Random().nextInt(effects_type.length);
		String type[] = effects_type[index].replaceAll(" ", "").split(",");
		if (type.length < 2)
			return;
		CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putString("main_attribute_name", type[0]));
		CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble("main_attribute_count", Double.valueOf(type[1].toString())));
		if (type[2].equals("0"))
			CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putBoolean("main_attribute_multiplied", false));
		else
			CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putBoolean("main_attribute_multiplied", true));
		/*
		if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:plume_of_death")))) {
			CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putString("main_attribute_name", "minecraft:generic.attack_damage");
			CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble("main_attribute_count", 3.0);
			CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putBoolean("main_attribute_multiplied", false);
		}
		*/
	}

	public static double experience_percentage(ItemStack itemstack) {
		if (itemstack.getItem() instanceof ArtifactItem) {
			return Math.min(1, itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("experience")
					/ ((600 + 175 * itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("level")) * (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("rarity") + 1)));
		}
		return 0;
	}

	public static double max_level(ItemStack itemstack) {
		int rarity = itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getInt("rarity");
		if (rarity <= 1)
			return 4;
		if (rarity <= 2)
			return 12;
		if (rarity <= 3)
			return 16;
		return 20;
	}

	public static boolean minor_attribute_rolling(ItemStack itemstack) {
		String attr_name = "";
		boolean mult = false;
		boolean find = false;
		double attr_count = 0;
		for (int index0 = 0; index0 < 4; index0++) {
			if (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble(("minor_attribute_count_" + new java.text.DecimalFormat("###").format(index0))) <= 0) {
				while (true) {
					mult = false;
					if (Math.random() <= 0.1111111) {
						attr_name = "minecraft:generic.max_health";
						attr_count = 5;
					} else if (Math.random() <= 0.125) {
						attr_name = "minecraft:generic.armor";
						attr_count = 0.0729;
						mult = true;
					} else if (Math.random() <= 0.142857) {
						attr_name = "minecraft:generic.armor";
						attr_count = 3;
					} else if (Math.random() <= 0.16666) {
						attr_name = "er:elemental_mastery";
						attr_count = 23.31;
					} else if (Math.random() <= 0.2) {
						attr_name = "er:energy_recharge";
						attr_count = 0.0648;
						mult = true;
					} else if (Math.random() <= 0.25) {
						attr_name = "er:crit_damage";
						attr_count = 0.0777;
						mult = true;
					} else if (Math.random() <= 0.33333) {
						attr_name = "minecraft:generic.attack_damage";
						attr_count = 0.0583;
						mult = true;
					} else if (Math.random() <= 0.5) {
						attr_name = "minecraft:generic.max_health";
						attr_count = 0.0583;
						mult = true;
					} else {
						attr_name = "minecraft:generic.attack_damage";
						attr_count = 3;
					}
					find = true;
					if ((itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getString("main_attribute_name")).equals(attr_name)
							&& itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBoolean("main_attribute_multiplied") == mult) {
						find = false;
					}
					for (int index2 = 0; index2 < 4; index2++) {
						if ((itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getString(("minor_attribute_name_" + new java.text.DecimalFormat("###").format(index2)))).equals(attr_name)
								&& itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBoolean(("minor_attribute_multiplied_" + new java.text.DecimalFormat("###").format(index2))) == mult) {
							find = false;
						}
					}
					if (find) {
						int index = index0;
						String name = attr_name;
						double count = attr_count;
						boolean multi = mult;
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putString("minor_attribute_name_" + new java.text.DecimalFormat("###").format(index), name));
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(("minor_attribute_count_" + new java.text.DecimalFormat("###").format(index)), count));
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putBoolean(("minor_attribute_multiplied_" + new java.text.DecimalFormat("###").format(index)), multi));
						CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(("minor_count_multiplier_" + new java.text.DecimalFormat("###").format(index)), 1));
						break;
					}
				}
				return true;
			}
		}
		int sort = Mth.nextInt(RandomSource.create(), 0, 3);
		CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(("minor_count_multiplier_" + new java.text.DecimalFormat("###").format(sort)),
				(itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble(("minor_count_multiplier_" + new java.text.DecimalFormat("###").format(sort))) + 1)));
		return false;
	}
}
