
package net.mcreator.er.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class ElementBanMobEffect extends MobEffect {
	public ElementBanMobEffect() {
		super(MobEffectCategory.HARMFUL, -16777216);
	}
}
