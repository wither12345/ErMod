
package net.mcreator.er.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.component.DataComponents;

import net.mcreator.er.procedures.HuntersBowDoProcedure;

public class HuntersBowItem extends BowItem {
	public HuntersBowItem() {
		super(new Item.Properties().durability(384).rarity(Rarity.COMMON));
	}

	@Override
	public UseAnim getUseAnimation(ItemStack itemstack) {
		return UseAnim.BOW;
	}

	@Override
	public int getUseDuration(ItemStack itemstack, LivingEntity livingEntity) {
		return 72000;
	}

	@Override
	public ItemAttributeModifiers getDefaultAttributeModifiers() {
		ItemAttributeModifiers.Builder builder = ItemAttributeModifiers.builder();
		ResourceLocation resourcelocation = ResourceLocation.withDefaultNamespace("attack.");
		builder.add(Attributes.ATTACK_DAMAGE, new AttributeModifier(resourcelocation, 2d, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND);
		return builder.build();
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level world, Player entity, InteractionHand hand) {
		InteractionResultHolder<ItemStack> ar = super.use(world, entity, hand);
		ItemStack itemstack = ar.getObject();
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		entity.startUsingItem(hand);
		return ar;
	}

	public void onUseTick(Level world, LivingEntity entity, ItemStack stack, int time) {
		if (time > 71992)
			CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> tag.putInt("pulling", 1));
		else if (time > 71984)
			CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> tag.putInt("pulling", 2));
		else
			CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> tag.putInt("pulling", 3));
	}

	@Override
	public void releaseUsing(ItemStack itemstack, Level world, LivingEntity entity, int time) {
		HuntersBowDoProcedure.execute(world, entity, itemstack, time);
	}
}
