/*
 * The code of this mod element is always locked.
 *
 * You can register new events in this class too.
 *
 * If you want to make a plain independent class, create it using
 * Project Browser -> New... and make sure to make the class
 * outside net.mcreator.er as this package is managed by MCreator.
 *
 * If you change workspace package, modid or prefix, you will need
 * to manually adapt this file to these changes or remake it.
 *
 * This class will be added in the mod root package.
*/
package net.mcreator.er;

import org.joml.Vector3f;

import net.neoforged.neoforge.client.event.RenderLivingEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.Minecraft;

import java.util.Set;
import java.util.HashSet;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.systems.RenderSystem;

@EventBusSubscriber
public class OnEntityRender {
	private static final Set<LivingEntityRenderer<LivingEntity, EntityModel<LivingEntity>>> renderedEntities = new HashSet<>();

	@SubscribeEvent
	public static void onEntityRender(RenderLivingEvent.Pre event) {
		LivingEntityRenderer<LivingEntity, EntityModel<LivingEntity>> rend = event.getRenderer();
		if (renderedEntities.contains(rend))
			return;
		rend.addLayer(new FrozenLayer(rend));
		renderedEntities.add(rend);
	}

	public static class FrozenLayer extends RenderLayer<LivingEntity, EntityModel<LivingEntity>> {
		final ResourceLocation LAYER_TEXTURE = ResourceLocation.parse("minecraft:textures/block/frosted_ice_0.png");

		public FrozenLayer(LivingEntityRenderer<LivingEntity, EntityModel<LivingEntity>> renderer) {
			super(renderer);
		}

		@Override
		public void render(PoseStack poseStack, MultiBufferSource bufferSource, int light, LivingEntity entity, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch) {
			if (entity.getPersistentData().getInt("Frozen") > 0) {
				VertexConsumer vertexConsumer = bufferSource.getBuffer(RenderType.entityTranslucentEmissive(LAYER_TEXTURE));
				this.getParentModel().renderToBuffer(poseStack, vertexConsumer, light, LivingEntityRenderer.getOverlayCoords(entity, 0));
			}
		}
	}
}
