package net.mcreator.er.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;

import net.mcreator.er.init.ErModParticleTypes;

public class HydroTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double front = 0;
		if (world instanceof ServerLevel _level)
			_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_HYDRO.get()), x, (y + entity.getBbHeight() + 0.5), z, 1, 0, 0, 0, 0);
	}
}
