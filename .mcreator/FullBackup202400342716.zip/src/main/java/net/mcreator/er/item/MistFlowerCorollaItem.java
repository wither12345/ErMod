
package net.mcreator.er.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class MistFlowerCorollaItem extends Item {
	public MistFlowerCorollaItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
