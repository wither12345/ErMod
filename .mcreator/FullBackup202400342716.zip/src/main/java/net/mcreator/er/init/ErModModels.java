
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.er.client.model.Modellarge_hydro_slime;
import net.mcreator.er.client.model.Modellarge_electro_slime;
import net.mcreator.er.client.model.Modelelectro_cicin;
import net.mcreator.er.client.model.Modelbloom;
import net.mcreator.er.client.model.ModelMist_Flower;
import net.mcreator.er.client.model.ModelMask;
import net.mcreator.er.client.model.ModelFlaming_Flower;
import net.mcreator.er.client.model.ModelFatui_Electro_Cicin_Mage;
import net.mcreator.er.client.model.ModelErHumanoid;
import net.mcreator.er.client.model.ModelCrystallize;
import net.mcreator.er.client.model.ModelCrystalfly;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class ErModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelelectro_cicin.LAYER_LOCATION, Modelelectro_cicin::createBodyLayer);
		event.registerLayerDefinition(Modelbloom.LAYER_LOCATION, Modelbloom::createBodyLayer);
		event.registerLayerDefinition(ModelFlaming_Flower.LAYER_LOCATION, ModelFlaming_Flower::createBodyLayer);
		event.registerLayerDefinition(Modellarge_hydro_slime.LAYER_LOCATION, Modellarge_hydro_slime::createBodyLayer);
		event.registerLayerDefinition(ModelMask.LAYER_LOCATION, ModelMask::createBodyLayer);
		event.registerLayerDefinition(ModelMist_Flower.LAYER_LOCATION, ModelMist_Flower::createBodyLayer);
		event.registerLayerDefinition(ModelCrystallize.LAYER_LOCATION, ModelCrystallize::createBodyLayer);
		event.registerLayerDefinition(ModelFatui_Electro_Cicin_Mage.LAYER_LOCATION, ModelFatui_Electro_Cicin_Mage::createBodyLayer);
		event.registerLayerDefinition(ModelErHumanoid.LAYER_LOCATION, ModelErHumanoid::createBodyLayer);
		event.registerLayerDefinition(Modellarge_electro_slime.LAYER_LOCATION, Modellarge_electro_slime::createBodyLayer);
		event.registerLayerDefinition(ModelCrystalfly.LAYER_LOCATION, ModelCrystalfly::createBodyLayer);
	}
}
