package net.mcreator.er.procedures;

import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.projectile.windcharge.AbstractWindCharge;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.particles.SimpleParticleType;

import net.mcreator.er.init.ErModParticleTypes;
import net.mcreator.er.entity.ElementalProjectileEntity;

import javax.annotation.Nullable;

import java.util.List;
import java.util.Comparator;

@EventBusSubscriber
public class ArrowUpdateProcedure {
	@OnlyIn(Dist.CLIENT)
	@SubscribeEvent
	public static void onPlayerTick(PlayerTickEvent.Post event) {
		execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ());
	}

	public static void execute(LevelAccessor world, double x, double y, double z) {
		execute(null, world, x, y, z);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z) {
		{
			final Vec3 _center = new Vec3(x, y, z);
			List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(64 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
			for (Entity entityiterator : _entfound) {
				if ((entityiterator instanceof Arrow arrow && (arrow.getDeltaMovement().x() != 0 || arrow.getDeltaMovement().y() != 0 || arrow.getDeltaMovement().z() != 0)) || entityiterator instanceof ElementalProjectileEntity) {
					if (entityiterator.getPersistentData().getDouble("Element") == 1) {
						world.addParticle((SimpleParticleType) (ErModParticleTypes.SMALL_ANEMO_PARTICLE.get()), (entityiterator.getX()), (entityiterator.getY()), (entityiterator.getZ()), 0, 0, 0);
					} else if (entityiterator.getPersistentData().getDouble("Element") == 2) {
						world.addParticle((SimpleParticleType) (ErModParticleTypes.SMALL_CRYO_PARTICLE.get()), (entityiterator.getX()), (entityiterator.getY()), (entityiterator.getZ()), 0, 0, 0);
					} else if (entityiterator.getPersistentData().getDouble("Element") == 3) {
						world.addParticle((SimpleParticleType) (ErModParticleTypes.SMALL_DENDRO_PARTICLE.get()), (entityiterator.getX()), (entityiterator.getY()), (entityiterator.getZ()), 0, 0, 0);
					} else if (entityiterator.getPersistentData().getDouble("Element") == 4) {
						world.addParticle((SimpleParticleType) (ErModParticleTypes.SMALL_ELECTRO_PARTICLE.get()), (entityiterator.getX()), (entityiterator.getY()), (entityiterator.getZ()), 0, 0, 0);
					} else if (entityiterator.getPersistentData().getDouble("Element") == 5) {
						world.addParticle((SimpleParticleType) (ErModParticleTypes.SMALL_GEO_PARTICLE.get()), (entityiterator.getX()), (entityiterator.getY()), (entityiterator.getZ()), 0, 0, 0);
					} else if (entityiterator.getPersistentData().getDouble("Element") == 6) {
						world.addParticle((SimpleParticleType) (ErModParticleTypes.SMALL_HYDRO_PARTICLE.get()), (entityiterator.getX()), (entityiterator.getY()), (entityiterator.getZ()), 0, 0, 0);
					} else if (entityiterator.getPersistentData().getDouble("Element") == 7) {
						world.addParticle((SimpleParticleType) (ErModParticleTypes.SMALL_PYRO_PARTICLE.get()), (entityiterator.getX()), (entityiterator.getY()), (entityiterator.getZ()), 0, 0, 0);
					}
				}
				if (entityiterator instanceof AbstractWindCharge)
					world.addParticle((SimpleParticleType) (ErModParticleTypes.SMALL_ANEMO_PARTICLE.get()), (entityiterator.getX()), (entityiterator.getY()), (entityiterator.getZ()), 0, 0, 0);
				if (entityiterator instanceof LargeFireball) {
					world.addParticle((SimpleParticleType) (ErModParticleTypes.PYRO_PARTICLE.get()), (entityiterator.getX()), (entityiterator.getY()), (entityiterator.getZ()), 0, 0, 0);
				}
				if (entityiterator instanceof SmallFireball) {
					world.addParticle((SimpleParticleType) (ErModParticleTypes.SMALL_PYRO_PARTICLE.get()), (entityiterator.getX()), (entityiterator.getY()), (entityiterator.getZ()), 0, 0, 0);
				}
			}
		}
	}
}
