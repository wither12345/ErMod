package net.mcreator.er.procedures;

import net.neoforged.neoforge.items.ItemHandlerHelper;
import net.neoforged.neoforge.event.entity.player.AdvancementEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.advancements.Advancement;

import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModItems;

@EventBusSubscriber
public class PlayerAdvancementProcedure {
	@SubscribeEvent
	public static void onAdvancement(AdvancementEvent.AdvancementEarnEvent event) {
		Player player = event.getEntity();
		Advancement adv = event.getAdvancement().value();
		if (player.level().getServer().getAdvancements().get(ResourceLocation.parse("minecraft:adventure/root")).value().equals(adv))
			return;
		if (!(player.hasEffect(ErModMobEffects.VISION_COOL_DOWN)) && Math.random() <= 0.05) {
			if (!player.level().isClientSide())
				player.addEffect(new MobEffectInstance(ErModMobEffects.VISION_COOL_DOWN, 60, 0, false, false));
			player.displayClientMessage(Component.literal((Component.translatable("message.er.get_vision").getString())), false);
			ItemStack _setstack = new ItemStack(ErModItems.UNOWNED_VISION.get());
			_setstack.setCount(1);
			ItemHandlerHelper.giveItemToPlayer(player, _setstack);
		}
	}
}
