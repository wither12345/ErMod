package net.mcreator.er.procedures;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;

public class LuckyDogEndProcedure {
	public static void execute(Entity entity, double amplifier) {
		if (entity == null)
			return;
		ResourceLocation resourcelocation = ResourceLocation.withDefaultNamespace("er.luckydog.armor");
		((LivingEntity) entity).getAttribute(Attributes.ARMOR).removeModifier(new AttributeModifier(resourcelocation, 5, AttributeModifier.Operation.ADD_VALUE));
	}
}
