/*
 * Type :
 * 1 Anemo
 * 2 Cryo
 * 3 Dendro
 * 4 Electro
 * 5 Geo
 * 6 Hydro
 * 7 Pyro
*/
package net.mcreator.er;

import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.BlockPos;

import net.mcreator.er.procedures.IsPyroInfusionProcedure;
import net.mcreator.er.procedures.IsHydroInfusionProcedure;
import net.mcreator.er.procedures.IsGeoInfusionProcedure;
import net.mcreator.er.procedures.IsElectroInfusionProcedure;
import net.mcreator.er.procedures.IsDendroInfusionProcedure;
import net.mcreator.er.procedures.IsCryoInfusionProcedure;
import net.mcreator.er.procedures.IsAnemoInfusionProcedure;
import net.mcreator.er.init.ErModParticleTypes;
import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModItems;
import net.mcreator.er.init.ErModEntities;
import net.mcreator.er.init.ErModBlocks;
import net.mcreator.er.init.ErModAttributes;

import java.util.List;
import java.util.Comparator;

@EventBusSubscriber
public class EntityHurtEvent {
	@SubscribeEvent
	public static void onEntityAttacked(LivingIncomingDamageEvent event) {
		if (event == null)
			return;
		DamageSource damagesource = event.getSource();
		if (damagesource.is(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction")))) {
			return;
		}
		LivingEntity entity = event.getEntity();
		Entity sourceentity = event.getSource().getEntity();
		LevelAccessor world = entity.level();
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		float multiply = 1;
		float additonal_amount = 0;
		int elemental_type = getInfusion_Type(entity.level(), sourceentity, event.getSource().getDirectEntity());
		int elemental_strength = 200;
		if (elemental_type == 1) {
			multiply *= AnemoMultiply(world, x, y, z, entity, sourceentity, elemental_strength);
		} else if (elemental_type == 2) {
			multiply *= CryoMultiply(world, x, y, z, entity, sourceentity, elemental_strength);
		} else if (elemental_type == 3) {
			multiply *= DendroMultiply(world, x, y, z, entity, sourceentity, elemental_strength);
		} else if (elemental_type == 4) {
			multiply *= ElectroMultiply(world, x, y, z, entity, sourceentity, elemental_strength);
		} else if (elemental_type == 5) {
			multiply *= GeoMultiply(world, x, y, z, entity, sourceentity, elemental_strength);
		} else if (elemental_type == 6) {
			multiply *= HydroMultiply(world, x, y, z, entity, sourceentity, elemental_strength);
		} else if (elemental_type == 7) {
			multiply *= PyroMultiply(world, x, y, z, entity, sourceentity, elemental_strength);
		}
		//Final Damage 
		event.setAmount(event.getAmount() * multiply + additonal_amount);
		PacketDistributor.sendToAllPlayers(new ErData(entity.getId(), entity.getPersistentData().getInt("Frozen")));
	}

	public static float AnemoMultiply(LevelAccessor world, double x, double y, double z, LivingEntity entity, Entity sourceentity, int elemental_strength) {
		if (entity == null)
			return 0;
		double elemental_mastery = 0;
		if (sourceentity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY) != null)
			elemental_mastery = ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue();
		if (entity.getPersistentData().getInt("Cryo") > 0) {
			if (elemental_strength * 2 >= entity.getPersistentData().getInt("Cryo")) {
				elemental_strength -= entity.getPersistentData().getInt("Cryo") * 2;
				entity.getPersistentData().putInt("Cryo", 0);
			} else {
				entity.getPersistentData().putInt("Cryo", entity.getPersistentData().getInt("Cryo") - elemental_strength / 2);
				elemental_strength = 0;
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.SMALL_CRYO_PARTICLE.get()), (x - 1.5), (y + entity.getBbHeight() / 2), (z - 1.5), 8, 1.5, 0, 1.5, 0);
			final Vec3 _center = new Vec3(x, y, z);
			List<LivingEntity> _entfound = world.getEntitiesOfClass(LivingEntity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
			for (LivingEntity entityiterator : _entfound) {
				if (shouldHurt(sourceentity, entityiterator))
					entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), sourceentity),
							getElementalMasteryMultiply(1, elemental_mastery) * 3 * CryoMultiply(world, x, y, z, entityiterator, sourceentity, 25));
			}
		}
		if (entity.getPersistentData().getInt("Electro") > 0 && elemental_strength > 0) {
			if (elemental_strength * 2 >= entity.getPersistentData().getInt("Electro")) {
				elemental_strength -= entity.getPersistentData().getInt("Electro") * 2;
				entity.getPersistentData().putInt("Electro", 0);
			} else {
				entity.getPersistentData().putInt("Electro", entity.getPersistentData().getInt("Electro") - elemental_strength / 2);
				elemental_strength = 0;
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.SMALL_ELECTRO_PARTICLE.get()), (x - 1.5), (y + entity.getBbHeight() / 2), (z - 1.5), 8, 1.5, 0, 1.5, 0);
			final Vec3 _center = new Vec3(x, y, z);
			List<LivingEntity> _entfound = world.getEntitiesOfClass(LivingEntity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
			for (LivingEntity entityiterator : _entfound) {
				if (shouldHurt(sourceentity, entityiterator))
					entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), sourceentity),
							getElementalMasteryMultiply(1, elemental_mastery) * 3 * ElectroMultiply(world, x, y, z, entityiterator, sourceentity, 25));
			}
		}
		if (entity.getPersistentData().getInt("Hydro") > 0 && elemental_strength > 0) {
			if (elemental_strength * 2 >= entity.getPersistentData().getInt("Hydro")) {
				elemental_strength -= entity.getPersistentData().getInt("Hydro") * 2;
				entity.getPersistentData().putInt("Hydro", 0);
			} else {
				entity.getPersistentData().putInt("Hydro", entity.getPersistentData().getInt("Hydro") - elemental_strength / 2);
				elemental_strength = 0;
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.SMALL_HYDRO_PARTICLE.get()), (x - 1.5), (y + entity.getBbHeight() / 2), (z - 1.5), 8, 1.5, 0, 1.5, 0);
			final Vec3 _center = new Vec3(x, y, z);
			List<LivingEntity> _entfound = world.getEntitiesOfClass(LivingEntity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
			for (LivingEntity entityiterator : _entfound) {
				if (shouldHurt(sourceentity, entityiterator))
					entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), sourceentity),
							getElementalMasteryMultiply(1, elemental_mastery) * 3 * HydroMultiply(world, x, y, z, entityiterator, sourceentity, 25));
			}
		}
		if (entity.getPersistentData().getInt("Pyro") > 0 && elemental_strength > 0) {
			if (elemental_strength * 2 >= entity.getPersistentData().getInt("Pyro")) {
				elemental_strength -= entity.getPersistentData().getInt("Pyro") * 2;
				entity.getPersistentData().putInt("Pyro", 0);
			} else {
				entity.getPersistentData().putInt("Pyro", entity.getPersistentData().getInt("Pyro") - elemental_strength / 2);
				elemental_strength = 0;
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.SMALL_PYRO_PARTICLE.get()), (x - 1.5), (y + entity.getBbHeight() / 2), (z - 1.5), 8, 1.5, 0, 1.5, 0);
			final Vec3 _center = new Vec3(x, y, z);
			List<LivingEntity> _entfound = world.getEntitiesOfClass(LivingEntity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
			for (LivingEntity entityiterator : _entfound) {
				if (shouldHurt(sourceentity, entityiterator))
					entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), sourceentity),
							getElementalMasteryMultiply(1, elemental_mastery) * 3 * PyroMultiply(world, x, y, z, entityiterator, sourceentity, 25));
			}
			for (int i = -2; i <= 2; i++)
				for (int j = -2; j <= 2; j++)
					for (int k = -1; k <= 1; k++)
						if ((world.getBlockState(BlockPos.containing(x + i, y + k, z + j))).getBlock() == Blocks.GRASS_BLOCK) {
							world.setBlock(BlockPos.containing(x + i, y + k, z + j), ErModBlocks.BURNING_DIRT.get().defaultBlockState(), 3);
							if (!world.isClientSide()) {
								BlockPos _bp = BlockPos.containing(x + i, y + k, z + j);
								BlockEntity _blockEntity = world.getBlockEntity(_bp);
								BlockState _bs = world.getBlockState(_bp);
								if (_blockEntity != null)
									_blockEntity.getPersistentData().putString("UUID", sourceentity.getStringUUID());
								if (world instanceof Level _level)
									_level.sendBlockUpdated(_bp, _bs, _bs, 3);
							}
						}
		}
		return (sourceentity instanceof LivingEntity ? (float) ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ANEMO_DMG_BONUS).getValue() : 1f) * (100f - (float) entity.getAttribute(ErModAttributes.ANEMO_RES).getValue()) / 100f;
	}

	public static float CryoMultiply(LevelAccessor world, double x, double y, double z, LivingEntity entity, Entity sourceentity, int elemental_strength) {
		if (entity == null)
			return 0;
		float multiply = 1;
		double elemental_mastery = 0;
		if (sourceentity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY) != null)
			elemental_mastery = ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue();
		if (entity.getPersistentData().getInt("Pyro") > 0 && elemental_strength > 0) {
			if (elemental_strength * 2 >= entity.getPersistentData().getInt("Pyro")) {
				elemental_strength -= entity.getPersistentData().getInt("Pyro") * 2;
				entity.getPersistentData().putInt("Pyro", 0);
			} else {
				entity.getPersistentData().putInt("Pyro", entity.getPersistentData().getInt("Pyro") - elemental_strength / 2);
				elemental_strength = 0;
			}
			multiply = 1.5f + getElementalMasteryMultiply(0, elemental_mastery);
		}
		if (entity.getPersistentData().getInt("Hydro") > 0 && elemental_strength > 0) {
			int frozen_strength = 0;
			if (elemental_strength >= entity.getPersistentData().getInt("Hydro")) {
				frozen_strength = entity.getPersistentData().getInt("Hydro");
				elemental_strength -= entity.getPersistentData().getInt("Hydro");
				entity.getPersistentData().putInt("Hydro", 0);
			} else {
				frozen_strength = elemental_strength;
				entity.getPersistentData().putInt("Hydro", entity.getPersistentData().getInt("Hydro") - elemental_strength);
				elemental_strength = 0;
			}
			entity.getPersistentData().putInt("Frozen", frozen_strength * 10 + entity.getPersistentData().getInt("Frozen"));
			((LivingEntity) entity).getAttribute(Attributes.MOVEMENT_SPEED).addOrReplacePermanentModifier(new AttributeModifier(ResourceLocation.withDefaultNamespace("er.frozen.speed"), -100, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
			//entity.addEffect(new MobEffectInstance(ErModMobEffects.FROZEN, 100, 0, false, false));
		}
		if (entity.getPersistentData().getInt("Electro") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Electro")) {
				elemental_strength -= entity.getPersistentData().getInt("Electro");
				entity.getPersistentData().putInt("Electro", 0);
			} else {
				entity.getPersistentData().putInt("Electro", entity.getPersistentData().getInt("Electro") - elemental_strength);
				elemental_strength = 0;
			}
			final Vec3 _center = new Vec3(x, y, z);
			List<LivingEntity> _entfound = world.getEntitiesOfClass(LivingEntity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
			for (LivingEntity entityiterator : _entfound) {
				if (entityiterator != sourceentity) {
					entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), sourceentity),
							getElementalMasteryMultiply(1, elemental_mastery) * 5);
					if (!entityiterator.level().isClientSide())
						entityiterator.addEffect(new MobEffectInstance(ErModMobEffects.SUPERCONDUCT, 100, 0, false, false));
				}
			}
		}
		entity.getPersistentData().putInt("Cryo", Math.max(elemental_strength, entity.getPersistentData().getInt("Cryo")));
		return multiply
				* ((sourceentity instanceof LivingEntity ? (float) ((LivingEntity) sourceentity).getAttribute(ErModAttributes.CRYO_DMG_BONUS).getValue() : 1f) * (100f - (float) entity.getAttribute(ErModAttributes.CRYO_RES).getValue()) / 100f);
	}

	public static float DendroMultiply(LevelAccessor world, double x, double y, double z, LivingEntity entity, Entity sourceentity, int elemental_strength) {
		if (entity == null)
			return 0;
		float multiply = 1;
		double elemental_mastery = 0;
		if (sourceentity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY) != null)
			elemental_mastery = ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue();
		if (entity.hasEffect(ErModMobEffects.QUICKEN)) {
			entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), sourceentity),
					(float) (5 * getElementalMasteryMultiply(1, elemental_mastery) * (100 - entity.getAttribute(ErModAttributes.DENDRO_RES).getValue()) / 100));
		}
		if (entity.getPersistentData().getInt("Hydro") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Hydro")) {
				elemental_strength -= entity.getPersistentData().getInt("Hydro");
				entity.getPersistentData().putInt("Hydro", 0);
			} else {
				entity.getPersistentData().putInt("Hydro", entity.getPersistentData().getInt("Hydro") - elemental_strength);
				elemental_strength = 0;
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = ErModEntities.BLOOM_ENTITY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
				entityToSpawn.getPersistentData().putString("UUID", sourceentity.getStringUUID());
				entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
				if (entityToSpawn != null)
					entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
				_level.sendParticles(ParticleTypes.HAPPY_VILLAGER, x, y, z, 5, 1, 1, 1, 0);
			}
		}
		if (entity.getPersistentData().getInt("Electro") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Electro")) {
				elemental_strength -= entity.getPersistentData().getInt("Electro");
				entity.getPersistentData().putInt("Electro", 0);
			} else {
				entity.getPersistentData().putInt("Electro", entity.getPersistentData().getInt("Electro") - elemental_strength);
				elemental_strength = 0;
			}
			entity.addEffect(new MobEffectInstance(ErModMobEffects.QUICKEN, 200, 0));
		}
		entity.getPersistentData().putInt("Dendro", Math.max(elemental_strength, entity.getPersistentData().getInt("Dendro")));
		return multiply
				* ((sourceentity instanceof LivingEntity ? (float) ((LivingEntity) sourceentity).getAttribute(ErModAttributes.DENDRO_DMG_BONUS).getValue() : 1f) * (100f - (float) entity.getAttribute(ErModAttributes.DENDRO_RES).getValue()) / 100f);
	}

	public static float ElectroMultiply(LevelAccessor world, double x, double y, double z, LivingEntity entity, Entity sourceentity, int elemental_strength) {
		if (entity == null)
			return 0;
		float multiply = 1;
		double elemental_mastery = 0;
		if (sourceentity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY) != null)
			elemental_mastery = ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue();
		if (entity.hasEffect(ErModMobEffects.QUICKEN)) {
			entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), sourceentity),
					(float) (5 * getElementalMasteryMultiply(1, elemental_mastery) * ((100 - entity.getAttribute(ErModAttributes.DENDRO_RES).getValue()) / 100)));
		}
		if (entity.getPersistentData().getInt("Pyro") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Pyro")) {
				elemental_strength -= entity.getPersistentData().getInt("Pyro");
				entity.getPersistentData().putInt("Pyro", 0);
			} else {
				entity.getPersistentData().putInt("Pyro", entity.getPersistentData().getInt("Pyro") - elemental_strength);
				elemental_strength = 0;
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 1, 0, 0, 0, 0);
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.generic.explode")), SoundSource.NEUTRAL, 1, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.generic.explode")), SoundSource.NEUTRAL, 1, 1, false);
				}
			}
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<LivingEntity> _entfound = world.getEntitiesOfClass(LivingEntity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
				for (LivingEntity entityiterator : _entfound) {
					if (shouldHurt(sourceentity, entityiterator)) {
						entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), sourceentity), (float) (5
								* getElementalMasteryMultiply(1, elemental_mastery)
								* (sourceentity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.PYRO_DMG_BONUS) != null ? ((LivingEntity) sourceentity).getAttribute(ErModAttributes.PYRO_DMG_BONUS).getValue() : 1)
								* ((100 - (sourceentity instanceof LivingEntity && ((LivingEntity) entityiterator).getAttribute(ErModAttributes.PYRO_RES) != null
										? ((LivingEntity) entityiterator).getAttribute(ErModAttributes.PYRO_RES).getValue()
										: 10)) / 100)));
						entityiterator.setDeltaMovement(new Vec3((entityiterator.getDeltaMovement().x() * 3), (entityiterator.getDeltaMovement().y() * 2), (entityiterator.getDeltaMovement().z() * 3)));
					}
				}
			}
		}
		if (entity.getPersistentData().getInt("Dendro") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Dendro")) {
				elemental_strength -= entity.getPersistentData().getInt("Dendro");
				entity.getPersistentData().putInt("Dendro", 0);
			} else {
				entity.getPersistentData().putInt("Dendro", entity.getPersistentData().getInt("Dendro") - elemental_strength);
				elemental_strength = 0;
			}
			entity.addEffect(new MobEffectInstance(ErModMobEffects.QUICKEN, 200, 0));
		}
		if (entity.getPersistentData().getInt("Cryo") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Cryo")) {
				elemental_strength -= entity.getPersistentData().getInt("Cryo");
				entity.getPersistentData().putInt("Cryo", 0);
			} else {
				entity.getPersistentData().putInt("Cryo", entity.getPersistentData().getInt("Cryo") - elemental_strength);
				elemental_strength = 0;
			}
			final Vec3 _center = new Vec3(x, y, z);
			List<LivingEntity> _entfound = world.getEntitiesOfClass(LivingEntity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
			for (LivingEntity entityiterator : _entfound) {
				if (entityiterator instanceof LivingEntity && !(entityiterator == sourceentity)) {
					entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), sourceentity),
							(float) (5 * (getElementalMasteryMultiply(2, elemental_mastery))));
					if (entityiterator.level().isClientSide())
						entityiterator.addEffect(new MobEffectInstance(ErModMobEffects.SUPERCONDUCT, 100, 0, false, false));
				}
			}
		}
		entity.getPersistentData().putInt("Electro", Math.max(elemental_strength, entity.getPersistentData().getInt("Electro")));
		return multiply
				* ((sourceentity instanceof LivingEntity ? (float) ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELECTRO_DMG_BONUS).getValue() : 1f) * (100f - (float) entity.getAttribute(ErModAttributes.ELECTRO_RES).getValue()) / 100f);
	}

	public static float GeoMultiply(LevelAccessor world, double x, double y, double z, LivingEntity entity, Entity sourceentity, int elemental_strength) {
		float multiply = 1;
		if (entity.getPersistentData().getInt("Pyro") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Pyro")) {
				elemental_strength -= entity.getPersistentData().getInt("Pyro");
				entity.getPersistentData().putInt("Pyro", 0);
			} else {
				entity.getPersistentData().putInt("Pyro", entity.getPersistentData().getInt("Pyro") - elemental_strength);
				elemental_strength = 0;
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = ErModEntities.PYRO_CRYSTALLIZE.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
				entityToSpawn.getPersistentData().putString("UUID", sourceentity.getStringUUID());
				if (entityToSpawn != null) {
					entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
				}
			}
			multiply = 1;
		}
		if (entity.getPersistentData().getInt("Hydro") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Hydro")) {
				elemental_strength -= entity.getPersistentData().getInt("Hydro");
				entity.getPersistentData().putInt("Hydro", 0);
			} else {
				entity.getPersistentData().putInt("Hydro", entity.getPersistentData().getInt("Hydro") - elemental_strength);
				elemental_strength = 0;
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = ErModEntities.HYDRO_CRYSTALLIZE.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
				entityToSpawn.getPersistentData().putString("UUID", sourceentity.getStringUUID());
				if (entityToSpawn != null) {
					entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
				}
			}
			multiply = 1;
		}
		if (entity.getPersistentData().getInt("Electro") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Electro")) {
				elemental_strength -= entity.getPersistentData().getInt("Electro");
				entity.getPersistentData().putInt("Electro", 0);
			} else {
				entity.getPersistentData().putInt("Electro", entity.getPersistentData().getInt("Electro") - elemental_strength);
				elemental_strength = 0;
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = ErModEntities.ELECTRO_CRYSTALLIZE.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
				entityToSpawn.getPersistentData().putString("UUID", sourceentity.getStringUUID());
				if (entityToSpawn != null) {
					entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
				}
			}
			multiply = 1;
		}
		if (entity.getPersistentData().getInt("Cryo") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Cryo")) {
				elemental_strength -= entity.getPersistentData().getInt("Cryo");
				entity.getPersistentData().putInt("Cryo", 0);
			} else {
				entity.getPersistentData().putInt("Cryo", entity.getPersistentData().getInt("Cryo") - elemental_strength);
				elemental_strength = 0;
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = ErModEntities.CRYO_CRYSTALLIZE.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
				entityToSpawn.getPersistentData().putString("UUID", sourceentity.getStringUUID());
				if (entityToSpawn != null) {
					entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
				}
			}
		}
		return multiply * ((sourceentity instanceof LivingEntity ? (float) ((LivingEntity) sourceentity).getAttribute(ErModAttributes.GEO_DMG_BONUS).getValue() : 1f) * (100f - (float) entity.getAttribute(ErModAttributes.GEO_RES).getValue()) / 100f);
	}

	public static float HydroMultiply(LevelAccessor world, double x, double y, double z, LivingEntity entity, Entity sourceentity, int elemental_strength) {
		if (entity == null)
			return 0;
		float multiply = 1;
		double elemental_mastery = 0;
		if (sourceentity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY) != null)
			elemental_mastery = ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue();
		if (entity.getPersistentData().getInt("Pyro") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Pyro") / 2) {
				elemental_strength -= entity.getPersistentData().getInt("Pyro") / 2;
				entity.getPersistentData().putInt("Pyro", 0);
			} else {
				elemental_strength = 0;
				entity.getPersistentData().putInt("Pyro", entity.getPersistentData().getInt("Pyro") - elemental_strength * 2);
			}
			multiply = 2 + getElementalMasteryMultiply(0, elemental_mastery);
		}
		if (entity.getPersistentData().getInt("Cryo") > 0 && elemental_strength > 0) {
			int frozen_strength = 0;
			if (elemental_strength >= entity.getPersistentData().getInt("Cryo")) {
				frozen_strength = entity.getPersistentData().getInt("Cryo");
				elemental_strength -= entity.getPersistentData().getInt("Cryo");
				entity.getPersistentData().putInt("Cryo", 0);
			} else {
				frozen_strength = elemental_strength;
				entity.getPersistentData().putInt("Cryo", entity.getPersistentData().getInt("Cryo") - elemental_strength);
				elemental_strength = 0;
			}
			entity.getPersistentData().putInt("Frozen", frozen_strength * 10 + entity.getPersistentData().getInt("Frozen"));
			((LivingEntity) entity).getAttribute(Attributes.MOVEMENT_SPEED).addOrReplacePermanentModifier(new AttributeModifier(ResourceLocation.withDefaultNamespace("er.frozen.speed"), -100, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
			//entity.addEffect(new MobEffectInstance(ErModMobEffects.FROZEN, 100, 0, false, false));
		}
		if (entity.getPersistentData().getInt("Dendro") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Dendro")) {
				elemental_strength -= entity.getPersistentData().getInt("Dendro");
				entity.getPersistentData().putInt("Dendro", 0);
			} else {
				entity.getPersistentData().putInt("Dendro", entity.getPersistentData().getInt("Dendro") - elemental_strength);
				elemental_strength = 0;
			}
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = ErModEntities.BLOOM_ENTITY.get().spawn(_level, BlockPos.containing(x, y, z), MobSpawnType.MOB_SUMMONED);
				entityToSpawn.getPersistentData().putString("UUID", sourceentity.getStringUUID());
				entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
				if (entityToSpawn != null)
					entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
				_level.sendParticles(ParticleTypes.HAPPY_VILLAGER, x, y, z, 5, 1, 1, 1, 0);
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.HAPPY_VILLAGER, x, y, z, 5, 1, 1, 1, 0);
		}
		entity.getPersistentData().putInt("Hydro", Math.max(elemental_strength, entity.getPersistentData().getInt("Hydro")));
		return multiply
				* ((sourceentity instanceof LivingEntity ? (float) ((LivingEntity) sourceentity).getAttribute(ErModAttributes.HYDRO_DMG_BONUS).getValue() : 1f) * (100f - (float) entity.getAttribute(ErModAttributes.HYDRO_RES).getValue()) / 100f);
	}

	public static float PyroMultiply(LevelAccessor world, double x, double y, double z, LivingEntity entity, Entity sourceentity, int elemental_strength) {
		if (entity == null)
			return 0;
		float multiply = 1;
		double elemental_mastery = 0;
		if (sourceentity instanceof LivingEntity && ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY) != null)
			elemental_mastery = ((LivingEntity) sourceentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue();
		if (entity.getPersistentData().getInt("Hydro") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Hydro") * 2) {
				elemental_strength -= entity.getPersistentData().getInt("Hydro") * 2;
				entity.getPersistentData().putInt("Hydro", 0);
			} else {
				entity.getPersistentData().putInt("Hydro", entity.getPersistentData().getInt("Hydro") - elemental_strength / 2);
				elemental_strength = 0;
			}
			multiply = 1.5f + getElementalMasteryMultiply(0, elemental_mastery);
		}
		if (entity.getPersistentData().getInt("Cryo") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Cryo") / 2) {
				elemental_strength -= entity.getPersistentData().getInt("Cryo") / 2;
				entity.getPersistentData().putInt("Cryo", 0);
			} else {
				entity.getPersistentData().putInt("Cryo", entity.getPersistentData().getInt("Cryo") - elemental_strength / 2);
				elemental_strength = 0;
			}
			multiply = 2 + getElementalMasteryMultiply(0, elemental_mastery);
		}
		if (entity.getPersistentData().getInt("Electro") > 0 && elemental_strength > 0) {
			if (elemental_strength >= entity.getPersistentData().getInt("Electro")) {
				elemental_strength -= entity.getPersistentData().getInt("Electro");
				entity.getPersistentData().putInt("Electro", 0);
			} else {
				entity.getPersistentData().putInt("Electro", entity.getPersistentData().getInt("Electro") - elemental_strength);
				elemental_strength = 0;
			}
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.EXPLOSION, x, y, z, 1, 0, 0, 0, 0);
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.generic.explode")), SoundSource.NEUTRAL, 1, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("entity.generic.explode")), SoundSource.NEUTRAL, 1, 1, false);
				}
			}
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<LivingEntity> _entfound = world.getEntitiesOfClass(LivingEntity.class, new AABB(_center, _center).inflate(6 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
				for (LivingEntity entityiterator : _entfound) {
					if (shouldHurt(sourceentity, entityiterator)) {
						entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), sourceentity),
								(float) (7 * getElementalMasteryMultiply(2, elemental_mastery)));
						entityiterator.setDeltaMovement(new Vec3((entityiterator.getDeltaMovement().x() * 3), (entityiterator.getDeltaMovement().y() * 2), (entityiterator.getDeltaMovement().z() * 3)));
					}
				}
			}
		}
		if (entity.getMainHandItem().getItem() == ErModItems.WOODEN_CLUB.get()) {
			CustomData.update(DataComponents.CUSTOM_DATA, entity.getMainHandItem(), tag -> tag.putInt("Pyro", 5));
		}
		entity.getPersistentData().putInt("Pyro", Math.max(elemental_strength, entity.getPersistentData().getInt("Pyro")));
		return multiply
				* ((sourceentity instanceof LivingEntity ? (float) ((LivingEntity) sourceentity).getAttribute(ErModAttributes.PYRO_DMG_BONUS).getValue() : 1f) * (100f - (float) entity.getAttribute(ErModAttributes.PYRO_RES).getValue()) / 100f);
	}

	public static int getInfusion_Type(LevelAccessor world, Entity entity, Entity immediatesourceentity) {
		if (entity == null)
			return 0;
		if (immediatesourceentity == entity) {
			if (entity instanceof LivingEntity && ((LivingEntity) entity).getMainHandItem().getItem() instanceof MultipleInfusion) {
				Item item = ((LivingEntity) entity).getMainHandItem().getItem();
				return ((MultipleInfusion) item).getInfusion(((LivingEntity) entity).getMainHandItem(), entity);
			}
			if (IsAnemoInfusionProcedure.execute(world, entity)) {
				return 1;
			} else if (IsCryoInfusionProcedure.execute(world, entity)) {
				return 2;
			} else if (IsDendroInfusionProcedure.execute(world, entity)) {
				return 3;
			} else if (IsElectroInfusionProcedure.execute(world, entity)) {
				return 4;
			} else if (IsGeoInfusionProcedure.execute(world, entity)) {
				return 5;
			} else if (IsHydroInfusionProcedure.execute(world, entity)) {
				return 6;
			} else if (IsPyroInfusionProcedure.execute(world, entity)) {
				return 7;
			}
		} else {
			if (immediatesourceentity instanceof LargeFireball || immediatesourceentity instanceof SmallFireball) {
				return 7;
			} else {
				return immediatesourceentity.getPersistentData().getInt("Element");
			}
		}
		return 0;
	}

	public static float getElementalMasteryMultiply(int type, double elemental_mastery) {
		if (type == 0) //Melt Vaporize
			return 2.78f * (float) (elemental_mastery / (elemental_mastery + 1400));
		if (type == 1) //Overloaded, Superconduct, Electro-Charged, Burning, Shattered, Swirl, Bloom, Hyperbloom,Burgeon
			return 16f * (float) (elemental_mastery / (elemental_mastery + 2000)) + 1f;
		if (type == 2) //Spread Aggravate
			return 5f * (float) (elemental_mastery / (elemental_mastery + 1200)) + 1f;
		return 1f;
	}

	public static boolean shouldHurt(Entity entity1, Entity entity2) {
		if (entity1 == null || entity2 == null)
			return true;
		PlayerTeam team1 = entity1.level().getScoreboard().getPlayersTeam(entity1 instanceof Player _pl ? _pl.getGameProfile().getName() : entity1.getStringUUID());
		PlayerTeam team2 = entity2.level().getScoreboard().getPlayersTeam(entity2 instanceof Player _pl ? _pl.getGameProfile().getName() : entity2.getStringUUID());
		return entity1 != entity2 && (team1 != team2 || team1 == null) && (entity1 instanceof OwnableEntity owned ? owned.getOwner() : entity1) != (entity2 instanceof OwnableEntity owned ? owned.getOwner() : entity2);
	}
}
