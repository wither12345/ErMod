
package net.mcreator.er.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class ElectroMistGrassLanternItem extends Item {
	public ElectroMistGrassLanternItem() {
		super(new Item.Properties().durability(64).rarity(Rarity.COMMON));
	}
}
