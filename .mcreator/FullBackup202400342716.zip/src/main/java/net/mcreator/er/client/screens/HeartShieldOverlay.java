package net.mcreator.er.client.screens;

import net.neoforged.neoforge.event.entity.player.PlayerHeartTypeEvent;
import net.neoforged.fml.common.asm.enumextension.EnumProxy;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.gui.Gui;

@EventBusSubscriber({Dist.CLIENT})
public class HeartShieldOverlay {
	public static final EnumProxy<Gui.HeartType> HYDRO = new EnumProxy<Gui.HeartType>(Gui.HeartType.class, ResourceLocation.parse("er:heart/hydro_crystallize/full"), ResourceLocation.parse("er:heart/hydro_crystallize/full_blinking"),
			ResourceLocation.parse("er:heart/hydro_crystallize/half"), ResourceLocation.parse("er:heart/hydro_crystallize/half_blinking"), ResourceLocation.parse("er:heart/hydro_crystallize/hardcore_full.png"),
			ResourceLocation.parse("er:heart/hydro_crystallize/hardcore_full_blinking"), ResourceLocation.parse("er:heart/hydro_crystallize/hardcore_half"), ResourceLocation.parse("er:heart/hydro_crystallize/hardcore_half_blinking"));

	@SubscribeEvent(priority = EventPriority.NORMAL)
	public static void changing(PlayerHeartTypeEvent event) {
		Player player = event.getEntity();
		Gui.HeartType type = event.getOriginalType();
		type = HYDRO.getValue();
		event.setType(type);
	}
}
