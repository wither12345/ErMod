
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.er.block.WhiteIronOreBlock;
import net.mcreator.er.block.SumeruRoseBlock;
import net.mcreator.er.block.LotusHeadBlock;
import net.mcreator.er.block.ElementAnvilBlock;
import net.mcreator.er.block.ElectroCrystalOreBlock;
import net.mcreator.er.block.DeepslateWhiteIronOreBlock;
import net.mcreator.er.block.CuihuaStairsBlock;
import net.mcreator.er.block.CuihuaSlabBlock;
import net.mcreator.er.block.CuihuaSaplingBlock;
import net.mcreator.er.block.CuihuaPlanksBlock;
import net.mcreator.er.block.CuihuaLogBlock;
import net.mcreator.er.block.CuihuaLeavesBlock;
import net.mcreator.er.block.CuihuaFenceGateBlock;
import net.mcreator.er.block.CuihuaFenceBlock;
import net.mcreator.er.block.CrateBlock;
import net.mcreator.er.block.CorLapisOreBlock;
import net.mcreator.er.block.BurningDirtBlock;
import net.mcreator.er.ErMod;

public class ErModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(ErMod.MODID);
	public static final DeferredBlock<Block> ELECTRO_CRYSTAL_ORE = REGISTRY.register("electro_crystal_ore", ElectroCrystalOreBlock::new);
	public static final DeferredBlock<Block> SUMERU_ROSE = REGISTRY.register("sumeru_rose", SumeruRoseBlock::new);
	public static final DeferredBlock<Block> COR_LAPIS_ORE = REGISTRY.register("cor_lapis_ore", CorLapisOreBlock::new);
	public static final DeferredBlock<Block> LOTUS_HEAD = REGISTRY.register("lotus_head", LotusHeadBlock::new);
	public static final DeferredBlock<Block> ELEMENT_ANVIL = REGISTRY.register("element_anvil", ElementAnvilBlock::new);
	public static final DeferredBlock<Block> WHITE_IRON_ORE = REGISTRY.register("white_iron_ore", WhiteIronOreBlock::new);
	public static final DeferredBlock<Block> DEEPSLATE_WHITE_IRON_ORE = REGISTRY.register("deepslate_white_iron_ore", DeepslateWhiteIronOreBlock::new);
	public static final DeferredBlock<Block> BURNING_DIRT = REGISTRY.register("burning_dirt", BurningDirtBlock::new);
	public static final DeferredBlock<Block> CRATE = REGISTRY.register("crate", CrateBlock::new);
	public static final DeferredBlock<Block> CUIHUA_LOG = REGISTRY.register("cuihua_log", CuihuaLogBlock::new);
	public static final DeferredBlock<Block> CUIHUA_LEAVES = REGISTRY.register("cuihua_leaves", CuihuaLeavesBlock::new);
	public static final DeferredBlock<Block> CUIHUA_SAPLING = REGISTRY.register("cuihua_sapling", CuihuaSaplingBlock::new);
	public static final DeferredBlock<Block> CUIHUA_PLANKS = REGISTRY.register("cuihua_planks", CuihuaPlanksBlock::new);
	public static final DeferredBlock<Block> CUIHUA_STAIRS = REGISTRY.register("cuihua_stairs", CuihuaStairsBlock::new);
	public static final DeferredBlock<Block> CUIHUA_SLAB = REGISTRY.register("cuihua_slab", CuihuaSlabBlock::new);
	public static final DeferredBlock<Block> CUIHUA_FENCE = REGISTRY.register("cuihua_fence", CuihuaFenceBlock::new);
	public static final DeferredBlock<Block> CUIHUA_FENCE_GATE = REGISTRY.register("cuihua_fence_gate", CuihuaFenceGateBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			CuihuaLeavesBlock.blockColorLoad(event);
		}
	}
}
