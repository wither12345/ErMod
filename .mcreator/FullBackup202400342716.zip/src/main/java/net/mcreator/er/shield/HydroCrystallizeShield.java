package net.mcreator.er.shield;

public abstract class HydroCrystallizeShield extends ErShield {
}
