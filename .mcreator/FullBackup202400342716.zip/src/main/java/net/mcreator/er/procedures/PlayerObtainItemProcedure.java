package net.mcreator.er.procedures;

import net.neoforged.neoforge.event.entity.player.ItemEntityPickupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.component.DataComponents;

import net.mcreator.er.item.ArtifactItem;
import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModItems;

import javax.annotation.Nullable;

@EventBusSubscriber
public class PlayerObtainItemProcedure {
	@SubscribeEvent
	public static void onPickup(ItemEntityPickupEvent.Pre event) {
		execute(event, event.getPlayer(), event.getItemEntity().getItem());
	}

	public static void execute(Entity entity, ItemStack itemstack) {
		execute(null, entity, itemstack);
	}

	private static void execute(@Nullable Event event, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (itemstack.getItem() instanceof ArtifactItem) {
			if (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("main_attribute_count") == 0) {
				ArtifactFunctionsProcedure.main_attribute_rolling(itemstack);
			}
			for (int index0 = 0; index0 < (int) itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("minor_upgrade_times"); index0++) {
				RollMinorAttributeProcedure.execute(itemstack);
			}
			{
				final String _tagName = "minor_upgrade_times";
				final double _tagValue = 0;
				CustomData.update(DataComponents.CUSTOM_DATA, itemstack, tag -> tag.putDouble(_tagName, _tagValue));
			}
		}
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(ErModMobEffects.LUCKY_DOG) ? _livEnt.getEffect(ErModMobEffects.LUCKY_DOG).getAmplifier() : 0) >= 3 && itemstack.getItem() == ErModItems.MORA.get()) {
			((LivingEntity) entity).heal(3);
		}
	}
}
