
package net.mcreator.er.item;

import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionHand;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.component.DataComponents;

import net.mcreator.er.procedures.ArtifactItem_Right_ClickProcedure;
import net.mcreator.er.procedures.ArtifactFunctionsProcedure;

import java.util.List;

public class ArtifactItem extends Item {
	public ArtifactItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));
	}

	public String getEffect() {
		return "minecraft:speed";
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public void appendHoverText(ItemStack itemstack, Item.TooltipContext context, List<Component> list, TooltipFlag flag) {
		if (!list.isEmpty()) {
			list.remove(0);
		}
		list.add(0, Component.literal(
				Component.translatable(("er.rarity." + new java.text.DecimalFormat("#").format(itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("rarity")))).getString() + itemstack.getHoverName().getString()));
		list.add(Component.literal("+" + new java.text.DecimalFormat("##.#").format(itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getInt("level"))));
		list.add(Component.literal("exp:" + new java.text.DecimalFormat("##.#%").format(ArtifactFunctionsProcedure.experience_percentage(itemstack))));
		if (ArtifactFunctionsProcedure.final_attribute(itemstack, 0) == 0) {
			list.add(Component.literal("§kthe mod is made by wither_123"));
			return;
		}
		super.appendHoverText(itemstack, context, list, flag);
		String attr_name = "";
		String NBT_name = itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getString("main_attribute_name");
		if (BuiltInRegistries.ATTRIBUTE.get(ResourceLocation.parse(NBT_name)) != null) {
			attr_name = BuiltInRegistries.ATTRIBUTE.get(ResourceLocation.parse(NBT_name)).getDescriptionId();
		}
		if (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBoolean("main_attribute_multiplied"))
			list.add(Component.literal(Component.translatable(attr_name).getString() + ":" + new java.text.DecimalFormat("##.#%").format(ArtifactFunctionsProcedure.final_attribute(itemstack, 0))));
		else
			list.add(Component.literal(Component.translatable(attr_name).getString() + ":" + new java.text.DecimalFormat("##.#").format(ArtifactFunctionsProcedure.final_attribute(itemstack, 0))));
		if (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getInt("minor_upgrade_times") > 0) {
			int times = itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getInt("minor_upgrade_times");
			list.add(Component.literal(new java.text.DecimalFormat(Component.translatable("text.er.minor_affix_upgrade").getString()).format(times)));
		}
		for (int index = 0; index < 4; index++) {
			NBT_name = itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getString("minor_attribute_name_" + new java.text.DecimalFormat("##").format(index));
			String NBT_count = ("minor_attribute_count_" + new java.text.DecimalFormat("##").format(index));
			String NBT_multiplied = ("minor_attribute_multiplied_" + new java.text.DecimalFormat("##").format(index));
			attr_name = "";
			if (BuiltInRegistries.ATTRIBUTE.get(ResourceLocation.parse(NBT_name)) != null) {
				attr_name = BuiltInRegistries.ATTRIBUTE.get(ResourceLocation.parse(NBT_name)).getDescriptionId();
			}
			if (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble(NBT_count) != 0) {
				if (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBoolean(NBT_multiplied))
					list.add(Component.literal("§7 " + Component.translatable(attr_name).getString() + ":" + new java.text.DecimalFormat("##.#%").format(ArtifactFunctionsProcedure.final_attribute(itemstack, index + 1))));
				else
					list.add(Component.literal("§7 " + Component.translatable(attr_name).getString() + ":" + new java.text.DecimalFormat("##.#").format(ArtifactFunctionsProcedure.final_attribute(itemstack, index + 1))));
			}
		}
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level world, Player entity, InteractionHand hand) {
		InteractionResultHolder<ItemStack> ar = super.use(world, entity, hand);
		ArtifactItem_Right_ClickProcedure.execute(world, entity, ar.getObject());
		return ar;
	}
}
