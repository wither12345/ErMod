package net.mcreator.er.entity.goals;

public class ErOwnerHurtByTargetGoal {
}
