/**
 * The code of this mod element is always locked.
 *
 * You can register new events in this class too.
 *
 * If you want to make a plain independent class, create it using
 * Project Browser -> New... and make sure to make the class
 * outside net.mcreator.er as this package is managed by MCreator.
 *
 * If you change workspace package, modid or prefix, you will need
 * to manually adapt this file to these changes or remake it.
 *
 * This class will be added in the mod root package.
*/
package net.mcreator.er;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.Entity;

import java.util.Properties;

public class StellaFortunas extends Item {
	public StellaFortunas(Properties properties) {
		super(properties.stacksTo(1));
	}

	public void AbilityE(LevelAccessor world, Entity entity, double x, double y, double z) {
	}

	public void AbilityQ(LevelAccessor world, Entity entity, double x, double y, double z) {
	}

	public void OnTick(LevelAccessor world, Entity entity, double x, double y, double z) {
	}

	public boolean vision(ItemStack item) {
		return true;
	}
}
