package net.mcreator.er.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;

import net.mcreator.er.init.ErModParticleTypes;
import net.mcreator.er.init.ErModMobEffects;
import net.mcreator.er.init.ErModAttributes;

import java.util.List;
import java.util.Comparator;

public class BloomEntityUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		Entity DMGentity = null;
		boolean find = false;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) > 0.05) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 114, false, false));
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) - 0.05));
			if (entity instanceof LivingEntity _livEnt4 && _livEnt4.hasEffect(ErModMobEffects.PYRO)) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_DENDRO_EXPLOSION.get()), x, (y + 0.2), z, 1, 0, 0, 0, 0);
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(16 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (Entity entityiterator : _entfound) {
						if ((entityiterator.getStringUUID()).equals(entity.getPersistentData().getString("UUID"))) {
							find = true;
							DMGentity = entityiterator;
						}
					}
				}
				if (find) {
					if (DMGentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELEMENT_BAN, 10, 0, false, false));
					{
						final Vec3 _center = new Vec3(x, y, z);
						List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
						for (Entity entityiterator : _entfound) {
							if (entityiterator instanceof LivingEntity) {
								entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), DMGentity),
										(float) (7
												* (1 + 5 * ((entity instanceof LivingEntity && ((LivingEntity) DMGentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY) != null
														? ((LivingEntity) DMGentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue()
														: 0)
														/ (2000 + (entity instanceof LivingEntity && ((LivingEntity) DMGentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY) != null
																? ((LivingEntity) DMGentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue()
																: 0))))
												* ((100 - (entity instanceof LivingEntity && ((LivingEntity) entityiterator).getAttribute(ErModAttributes.DENDRO_RES) != null
														? ((LivingEntity) entityiterator).getAttribute(ErModAttributes.DENDRO_RES).getValue()
														: 10)) / 100)));
							}
						}
					}
				} else {
					{
						final Vec3 _center = new Vec3(x, y, z);
						List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
						for (Entity entityiterator : _entfound) {
							if (entityiterator instanceof LivingEntity) {
								entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction")))),
										(float) (7 * ((100 - (entity instanceof LivingEntity && ((LivingEntity) entityiterator).getAttribute(ErModAttributes.DENDRO_RES) != null
												? ((LivingEntity) entityiterator).getAttribute(ErModAttributes.DENDRO_RES).getValue()
												: 10)) / 100)));
							}
						}
					}
				}
			} else if (entity instanceof LivingEntity _livEnt25 && _livEnt25.hasEffect(ErModMobEffects.ELECTRO)) {
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(16 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (Entity entityiterator : _entfound) {
						if ((entityiterator.getStringUUID()).equals(entity.getPersistentData().getString("UUID"))) {
							find = true;
							DMGentity = entityiterator;
						}
					}
				}
				if (find) {
					if (DMGentity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(ErModMobEffects.ELEMENT_BAN, 10, 0, false, false));
					{
						final Vec3 _center = new Vec3(x, y, z);
						List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
						for (Entity entityiterator : _entfound) {
							if (entityiterator instanceof LivingEntity) {
								entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), DMGentity),
										(float) (6
												* (1 + 5 * ((entity instanceof LivingEntity && ((LivingEntity) DMGentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY) != null
														? ((LivingEntity) DMGentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue()
														: 0)
														/ (2000 + (entity instanceof LivingEntity && ((LivingEntity) DMGentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY) != null
																? ((LivingEntity) DMGentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue()
																: 0))))
												* ((100 - (entity instanceof LivingEntity && ((LivingEntity) entityiterator).getAttribute(ErModAttributes.DENDRO_RES) != null
														? ((LivingEntity) entityiterator).getAttribute(ErModAttributes.DENDRO_RES).getValue()
														: 10)) / 100)));
								break;
							}
						}
					}
				} else {
					{
						final Vec3 _center = new Vec3(x, y, z);
						List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
						for (Entity entityiterator : _entfound) {
							if (entityiterator instanceof LivingEntity) {
								entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction")))),
										(float) (6 * ((100 - (entity instanceof LivingEntity && ((LivingEntity) entityiterator).getAttribute(ErModAttributes.DENDRO_RES) != null
												? ((LivingEntity) entityiterator).getAttribute(ErModAttributes.DENDRO_RES).getValue()
												: 10)) / 100)));
							}
						}
					}
				}
			}
		} else {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_DENDRO_EXPLOSION.get()), x, (y + 0.2), z, 1, 0, 0, 0, 0);
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(16 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
				for (Entity entityiterator : _entfound) {
					if ((entityiterator.getStringUUID()).equals(entity.getPersistentData().getString("UUID"))) {
						find = true;
						DMGentity = entityiterator;
					}
				}
			}
			if (find) {
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (Entity entityiterator : _entfound) {
						if (entityiterator instanceof LivingEntity) {
							entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), DMGentity),
									(float) (5
											* (1 + 5 * ((entity instanceof LivingEntity && ((LivingEntity) DMGentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY) != null
													? ((LivingEntity) DMGentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue()
													: 0)
													/ (2000 + (entity instanceof LivingEntity && ((LivingEntity) DMGentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY) != null
															? ((LivingEntity) DMGentity).getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue()
															: 0))))
											* ((100 - (entity instanceof LivingEntity && ((LivingEntity) entityiterator).getAttribute(ErModAttributes.DENDRO_RES) != null
													? ((LivingEntity) entityiterator).getAttribute(ErModAttributes.DENDRO_RES).getValue()
													: 10)) / 100)));
						}
					}
				}
			} else {
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (Entity entityiterator : _entfound) {
						if (entityiterator instanceof LivingEntity) {
							entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction")))), (float) (5 * ((100
									- (entity instanceof LivingEntity && ((LivingEntity) entityiterator).getAttribute(ErModAttributes.DENDRO_RES) != null ? ((LivingEntity) entityiterator).getAttribute(ErModAttributes.DENDRO_RES).getValue() : 10))
									/ 100)));
						}
					}
				}
			}
			if (!entity.level().isClientSide())
				entity.discard();
		}
	}
}
