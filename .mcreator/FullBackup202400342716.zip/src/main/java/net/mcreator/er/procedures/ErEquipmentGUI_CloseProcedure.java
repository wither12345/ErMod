package net.mcreator.er.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.er.network.ErModVariables;

import java.util.function.Supplier;
import java.util.Map;

public class ErEquipmentGUI_CloseProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		String type = "";
		String uuid = "";
		double count = 0;
		ItemStack item = ItemStack.EMPTY;
		{
			ErModVariables.PlayerVariables _vars = entity.getData(ErModVariables.PLAYER_VARIABLES);
			_vars.Vision = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(0)).getItem() : ItemStack.EMPTY);
			_vars.syncPlayerVariables(entity);
		}
		{
			ErModVariables.PlayerVariables _vars = entity.getData(ErModVariables.PLAYER_VARIABLES);
			_vars.Stella_Fortuna = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(1)).getItem() : ItemStack.EMPTY);
			_vars.syncPlayerVariables(entity);
		}
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Flower_Of_Life;
		ArtifactAttrRemoveProcedure.execute(entity, item);
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Plume_of_Death;
		ArtifactAttrRemoveProcedure.execute(entity, item);
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Sands_Of_Eon;
		ArtifactAttrRemoveProcedure.execute(entity, item);
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Goblet_Of_Eonothem;
		ArtifactAttrRemoveProcedure.execute(entity, item);
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Circlet_Of_Logos;
		ArtifactAttrRemoveProcedure.execute(entity, item);
		{
			ErModVariables.PlayerVariables _vars = entity.getData(ErModVariables.PLAYER_VARIABLES);
			_vars.Flower_Of_Life = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(2)).getItem() : ItemStack.EMPTY);
			_vars.syncPlayerVariables(entity);
		}
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Flower_Of_Life;
		ArtifactAttrAddProcedure.execute(entity, item);
		{
			ErModVariables.PlayerVariables _vars = entity.getData(ErModVariables.PLAYER_VARIABLES);
			_vars.Plume_of_Death = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(3)).getItem() : ItemStack.EMPTY);
			_vars.syncPlayerVariables(entity);
		}
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Plume_of_Death;
		ArtifactAttrAddProcedure.execute(entity, item);
		{
			ErModVariables.PlayerVariables _vars = entity.getData(ErModVariables.PLAYER_VARIABLES);
			_vars.Sands_Of_Eon = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(4)).getItem() : ItemStack.EMPTY);
			_vars.syncPlayerVariables(entity);
		}
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Sands_Of_Eon;
		ArtifactAttrAddProcedure.execute(entity, item);
		{
			ErModVariables.PlayerVariables _vars = entity.getData(ErModVariables.PLAYER_VARIABLES);
			_vars.Goblet_Of_Eonothem = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(5)).getItem() : ItemStack.EMPTY);
			_vars.syncPlayerVariables(entity);
		}
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Goblet_Of_Eonothem;
		ArtifactAttrAddProcedure.execute(entity, item);
		{
			ErModVariables.PlayerVariables _vars = entity.getData(ErModVariables.PLAYER_VARIABLES);
			_vars.Circlet_Of_Logos = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(6)).getItem() : ItemStack.EMPTY);
			_vars.syncPlayerVariables(entity);
		}
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Circlet_Of_Logos;
		ArtifactAttrAddProcedure.execute(entity, item);
	}
}
