
package net.mcreator.er.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class StainedMaskItem extends Item {
	public StainedMaskItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
