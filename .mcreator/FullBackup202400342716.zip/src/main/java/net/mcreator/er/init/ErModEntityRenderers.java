
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.er.client.renderer.TartagliaRenderer;
import net.mcreator.er.client.renderer.PyroCrystallizeRenderer;
import net.mcreator.er.client.renderer.MistFlowerRenderer;
import net.mcreator.er.client.renderer.HydroCrystallizeRenderer;
import net.mcreator.er.client.renderer.HilichurlRenderer;
import net.mcreator.er.client.renderer.FlamingFlowerRenderer;
import net.mcreator.er.client.renderer.FatuiElectroCicinMageRenderer;
import net.mcreator.er.client.renderer.ElectroCrystallizeRenderer;
import net.mcreator.er.client.renderer.ElectroCicinRenderer;
import net.mcreator.er.client.renderer.CryoCrystallizeRenderer;
import net.mcreator.er.client.renderer.BloomEntityRenderer;
import net.mcreator.er.client.renderer.AnemoCrystalflyRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ErModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(ErModEntities.BLOOM_ENTITY.get(), BloomEntityRenderer::new);
		event.registerEntityRenderer(ErModEntities.PYRO_CRYSTALLIZE.get(), PyroCrystallizeRenderer::new);
		event.registerEntityRenderer(ErModEntities.CRYO_CRYSTALLIZE.get(), CryoCrystallizeRenderer::new);
		event.registerEntityRenderer(ErModEntities.ELECTRO_CRYSTALLIZE.get(), ElectroCrystallizeRenderer::new);
		event.registerEntityRenderer(ErModEntities.HYDRO_CRYSTALLIZE.get(), HydroCrystallizeRenderer::new);
		event.registerEntityRenderer(ErModEntities.MIST_FLOWER.get(), MistFlowerRenderer::new);
		event.registerEntityRenderer(ErModEntities.FLAMING_FLOWER.get(), FlamingFlowerRenderer::new);
		event.registerEntityRenderer(ErModEntities.ANEMO_CRYSTALFLY.get(), AnemoCrystalflyRenderer::new);
		event.registerEntityRenderer(ErModEntities.TARTAGLIA.get(), TartagliaRenderer::new);
		event.registerEntityRenderer(ErModEntities.HILICHURL.get(), HilichurlRenderer::new);
		event.registerEntityRenderer(ErModEntities.ELECTRO_CICIN.get(), ElectroCicinRenderer::new);
		event.registerEntityRenderer(ErModEntities.ELEMENTAL_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(ErModEntities.FATUI_ELECTRO_CICIN_MAGE.get(), FatuiElectroCicinMageRenderer::new);
	}
}
