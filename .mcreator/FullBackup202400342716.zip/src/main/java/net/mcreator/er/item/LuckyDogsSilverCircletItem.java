
package net.mcreator.er.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;

import java.util.List;

public class LuckyDogsSilverCircletItem extends ArtifactItem {
	public LuckyDogsSilverCircletItem() {
		super();
	}

	@Override
	public String getEffect() {
		return "er:lucky_dog";
	}
}
