package net.mcreator.er.procedures;

import net.neoforged.neoforge.event.entity.living.LivingDeathEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.Event;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.tags.ItemTags;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.component.DataComponents;

import net.mcreator.er.init.ErModItems;

import javax.annotation.Nullable;

@EventBusSubscriber
public class EntityDeathProcedure {
	@SubscribeEvent
	public static void onEntityDeath(LivingDeathEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity(), event.getSource().getEntity());
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		execute(null, world, x, y, z, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null)
			return;
		ItemStack artifact_drop = ItemStack.EMPTY;
		ItemStack item_drop = ItemStack.EMPTY;
		item_drop = new ItemStack(ErModItems.MORA.get());
		item_drop.setCount((int) Math.min((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) / 10, 20));
		if (world instanceof ServerLevel _level) {
			ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, item_drop);
			entityToSpawn.setPickUpDelay(10);
			_level.addFreshEntity(entityToSpawn);
		}
		if (Math.random() < 0.01 * (1 + (sourceentity instanceof Player ? ((LivingEntity) sourceentity).getAttribute(net.minecraft.world.entity.ai.attributes.Attributes.LUCK).getValue() : 0))) {
			if (Math.random() < 0.8) {
				item_drop = new ItemStack(
						(BuiltInRegistries.ITEM.getOrCreateTag(ItemTags.create(ResourceLocation.parse("er:one_star_artifact"))).getRandomElement(RandomSource.create()).orElseGet(() -> BuiltInRegistries.ITEM.wrapAsHolder(Items.AIR)).value()));
				ArtifactFunctionsProcedure.main_attribute_rolling(item_drop);
				for (int index0 = 0; index0 < Mth.nextInt(RandomSource.create(), 0, 1); index0++) {
					ArtifactFunctionsProcedure.minor_attribute_rolling(item_drop);
				}
				CustomData.update(DataComponents.CUSTOM_DATA, item_drop, tag -> tag.putDouble("rarity", 0));
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, item_drop);
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			} else if (Math.random() < 0.5) {
				item_drop = new ItemStack(
						(BuiltInRegistries.ITEM.getOrCreateTag(ItemTags.create(ResourceLocation.parse("er:two_star_artifact"))).getRandomElement(RandomSource.create()).orElseGet(() -> BuiltInRegistries.ITEM.wrapAsHolder(Items.AIR)).value()));
				ArtifactFunctionsProcedure.main_attribute_rolling(item_drop);
				for (int index1 = 0; index1 < Mth.nextInt(RandomSource.create(), 1, 2); index1++) {
					ArtifactFunctionsProcedure.minor_attribute_rolling(item_drop);
				}
				CustomData.update(DataComponents.CUSTOM_DATA, item_drop, tag -> tag.putDouble("rarity", 1));
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, item_drop);
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			} else {
				item_drop = new ItemStack(
						(BuiltInRegistries.ITEM.getOrCreateTag(ItemTags.create(ResourceLocation.parse("er:three_star_artifact"))).getRandomElement(RandomSource.create()).orElseGet(() -> BuiltInRegistries.ITEM.wrapAsHolder(Items.AIR)).value()));
				ArtifactFunctionsProcedure.main_attribute_rolling(item_drop);
				for (int index2 = 0; index2 < Mth.nextInt(RandomSource.create(), 2, 3); index2++) {
					ArtifactFunctionsProcedure.minor_attribute_rolling(item_drop);
				}
				CustomData.update(DataComponents.CUSTOM_DATA, item_drop, tag -> tag.putDouble("rarity", 2));
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, item_drop);
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
			if (sourceentity == null)
				return;
			ItemStack hand_item = sourceentity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY;
			int GreedLevel = hand_item.getEnchantmentLevel(world.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(ResourceKey.create(Registries.ENCHANTMENT, ResourceLocation.parse("er:greed"))));
			if (GreedLevel != 0 && Math.random() < GreedLevel * 0.18) {
				item_drop = new ItemStack(ErModItems.MORA.get());
				item_drop.setCount(GreedLevel);
				if (world instanceof ServerLevel _level) {
					ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, item_drop);
					entityToSpawn.setPickUpDelay(10);
					_level.addFreshEntity(entityToSpawn);
				}
			}
		}
	}
}
