package net.mcreator.er.procedures;

import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.tags.ItemTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.component.DataComponents;

import net.mcreator.er.item.ArtifactItem;
import net.mcreator.er.init.ErModItems;

import java.util.function.Supplier;
import java.util.Map;

public class ElementAnvilGUIChangeProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		ItemStack item_0 = ItemStack.EMPTY;
		item_0 = ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get(0)).getItem() : ItemStack.EMPTY).copy());
		if (item_0.getItem() instanceof ArtifactItem) {
			for (int index0 = 0; index0 < 9; index0++) {
				if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
						.getItem() instanceof ArtifactItem) {
					{
						final String _tagName = "experience";
						final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("experience")
								+ 420 * ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
										.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("rarity") >= 3
												? (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
														.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("rarity") * 2
												: (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
														.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("rarity") + 1)
								+ 0.8 * (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
										.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("total_experience"));
						CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
					}
					{
						final String _tagName = "total_experience";
						final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("total_experience")
								+ 420 * ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
										.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("rarity") >= 3
												? (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
														.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("rarity") * 2
												: (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
														.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("rarity") + 1)
								+ 0.8 * (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index0 + 1))).getItem() : ItemStack.EMPTY)
										.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("total_experience"));
						CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
					}
				}
			}
			while (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("experience") >= (600 + 175 * item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("level"))
					* (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("rarity") + 1)
					&& item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("level") < ArtifactFunctionsProcedure.max_level(item_0)) {
				{
					final String _tagName = "experience";
					final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("experience")
							- (600 + 175 * item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("level")) * (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("rarity") + 1));
					CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
				}
				{
					final String _tagName = "level";
					final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("level") + 1);
					CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("level") % 4 == 0) {
					{
						final String _tagName = "minor_upgrade_times";
						final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("minor_upgrade_times") + 1);
						CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
					}
				}
			}
		} else if (item_0.getItem() instanceof SwordItem || item_0.getItem() instanceof BowItem) {
			for (int index2 = 0; index2 < 9; index2++) {
				if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
						.getItem() == ErModItems.ENHANCEMENT_ORE.get()) {
					{
						final String _tagName = "experience";
						final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("experience") + 400
								* (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY).getCount());
						CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
					}
					{
						final String _tagName = "total_experience";
						final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("total_experience") + 400
								* (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY).getCount());
						CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
					}
				} else if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
						.getItem() == ErModItems.FINE_ENHANCEMENT_ORE.get()) {
					{
						final String _tagName = "experience";
						final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("experience") + 2000
								* (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY).getCount());
						CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
					}
					{
						final String _tagName = "total_experience";
						final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("total_experience") + 2000
								* (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY).getCount());
						CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
					}
				} else if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
						.getItem() == ErModItems.MYSTIC_ENHANCEMENT_ORE.get()) {
					{
						final String _tagName = "experience";
						final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("experience") + 10000
								* (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY).getCount());
						CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
					}
					{
						final String _tagName = "total_experience";
						final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("total_experience") + 10000
								* (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY).getCount());
						CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
					}
				} else if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
						.is(ItemTags.create(ResourceLocation.parse("er:one_star_weapon")))) {
					{
						final String _tagName = "experience";
						final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("experience") + 600
								+ 0.8 * (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
										.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("total_experience"));
						CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
					}
					{
						final String _tagName = "total_experience";
						final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("total_experience") + 600
								+ 0.8 * (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
										.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("total_experience"));
						CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
					}
				} else if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
						.is(ItemTags.create(ResourceLocation.parse("er:five_star_weapon")))) {
					{
						final String _tagName = "experience";
						final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("experience") + 300000
								+ 0.8 * (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
										.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("total_experience"));
						CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
					}
					{
						final String _tagName = "total_experience";
						final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("total_experience") + 300000
								+ 0.8 * (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof Supplier _splr && _splr.get() instanceof Map _slt ? ((Slot) _slt.get((int) (index2 + 1))).getItem() : ItemStack.EMPTY)
										.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("total_experience"));
						CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
					}
				}
			}
			while (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("experience") >= GetWeaponMaxExpProcedure.execute(item_0)
					&& item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("level") < (item_0.is(ItemTags.create(ResourceLocation.parse("er:one_star_weapon"))) ? 69 : 89)) {
				{
					final String _tagName = "experience";
					final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("experience") - GetWeaponMaxExpProcedure.execute(item_0));
					CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
				}
				{
					final String _tagName = "level";
					final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("level") + 1);
					CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
				}
				if (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("level") % 4 == 0) {
					{
						final String _tagName = "minor_upgrade_times";
						final double _tagValue = (item_0.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("minor_upgrade_times") + 1);
						CustomData.update(DataComponents.CUSTOM_DATA, item_0, tag -> tag.putDouble(_tagName, _tagValue));
					}
				}
			}
		}
		if (entity instanceof Player _player && _player.containerMenu instanceof Supplier _current && _current.get() instanceof Map _slots) {
			ItemStack _setstack = item_0.copy();
			_setstack.setCount(1);
			((Slot) _slots.get(10)).set(_setstack);
			_player.containerMenu.broadcastChanges();
		}
	}
}
