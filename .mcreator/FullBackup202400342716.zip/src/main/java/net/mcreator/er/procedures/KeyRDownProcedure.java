package net.mcreator.er.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.Entity;

import net.mcreator.er.network.ErModVariables;
import net.mcreator.er.StellaFortunas;

public class KeyRDownProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		ItemStack vision = ItemStack.EMPTY;
		ItemStack item = ItemStack.EMPTY;
		vision = entity.getData(ErModVariables.PLAYER_VARIABLES).Vision;
		item = entity.getData(ErModVariables.PLAYER_VARIABLES).Stella_Fortuna;
		if (item.getItem() instanceof StellaFortunas && ((StellaFortunas) item.getItem()).vision(vision)) {
			((StellaFortunas) item.getItem()).AbilityE(entity.level(), entity, entity.getX(), entity.getY(), entity.getZ());
		}
	}
}
