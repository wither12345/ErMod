package net.mcreator.er.entity.goals;

import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;

import net.mcreator.er.ErMod;

import java.util.EnumSet;

public class ErOwnerHurtTargetGoal extends TargetGoal {
	//private final Mob mob;
	private LivingEntity ownerLastHurt;
	private int timestamp;

	public ErOwnerHurtTargetGoal(Mob mob) {
		super(mob, false);
		this.setFlags(EnumSet.of(Goal.Flag.TARGET));
	}

	@Override
	public boolean canUse() {
		OwnableEntity owned = null;
		if (mob instanceof OwnableEntity) {
			owned = (OwnableEntity) mob;
		}
		if (owned != null && owned.getOwner() != null) {
			LivingEntity livingentity = owned.getOwner();
			if (livingentity == null) {
				return false;
			} else {
				this.ownerLastHurt = livingentity.getLastHurtMob();
				int i = livingentity.getLastHurtMobTimestamp();
				return i != this.timestamp && this.canAttack(this.ownerLastHurt, TargetingConditions.DEFAULT);
			}
		} else {
			return false;
		}
	}

	@Override
	public void start() {
		OwnableEntity owned = null;
		if (mob instanceof OwnableEntity)
			owned = (OwnableEntity) mob;
		this.mob.setTarget(this.ownerLastHurt);
		LivingEntity livingentity = owned.getOwner();
		if (livingentity != null) {
			this.timestamp = livingentity.getLastHurtMobTimestamp();
		}
		super.start();
	}
}
