
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.er.client.gui.ErEquipmentGUIScreen;
import net.mcreator.er.client.gui.ElementAnvilGUIScreen;
import net.mcreator.er.client.gui.ArtifactGUIScreen;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ErModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(ErModMenus.ER_EQUIPMENT_GUI.get(), ErEquipmentGUIScreen::new);
		event.register(ErModMenus.ARTIFACT_GUI.get(), ArtifactGUIScreen::new);
		event.register(ErModMenus.ELEMENT_ANVIL_GUI.get(), ElementAnvilGUIScreen::new);
	}
}
