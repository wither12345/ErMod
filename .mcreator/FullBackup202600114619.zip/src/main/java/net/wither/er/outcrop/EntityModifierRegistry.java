package net.wither.er.outcrop;

import net.mcreator.er.ErMod;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.NewRegistryEvent;
import net.neoforged.neoforge.registries.RegistryBuilder;

import java.util.function.Supplier;

@EventBusSubscriber()
public class EntityModifierRegistry {
	public static final ResourceKey<Registry<EntityModifier>> ENTITY_MODIFIER = ResourceKey.createRegistryKey(ResourceLocation.fromNamespaceAndPath("er", "entity_modifier"));
	public static final Registry<EntityModifier> ENTITY_MODIFIERS = new RegistryBuilder<>(ENTITY_MODIFIER).sync(false).maxId(256).create();

	@SubscribeEvent
	public static void registerRegistries(NewRegistryEvent event) {
		event.register(ENTITY_MODIFIERS);
	}

	public static final DeferredRegister<EntityModifier> MODIFIERS = DeferredRegister.create(ENTITY_MODIFIERS, ErMod.MODID);
	public static final Supplier<EntityModifier> HELMET = MODIFIERS.register("helmet", () -> new ItemGiver(EquipmentSlot.HEAD));
	public static final Supplier<EntityModifier> CHESTPLATE = MODIFIERS.register("chestplate", () -> new ItemGiver(EquipmentSlot.CHEST));
	public static final Supplier<EntityModifier> LEGGINGS = MODIFIERS.register("leggings", () -> new ItemGiver(EquipmentSlot.LEGS));
	public static final Supplier<EntityModifier> BOOTS = MODIFIERS.register("boots", () -> new ItemGiver(EquipmentSlot.FEET));
	public static final Supplier<EntityModifier> MAIN_HAND = MODIFIERS.register("main_hand", () -> new ItemGiver(EquipmentSlot.MAINHAND));

}
