package net.mcreator.er.procedures;

import net.wither.er.network.ErItemVariables;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.InteractionHand;
import net.minecraft.tags.ItemTags;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.BlockPos;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.Minecraft;

import net.mcreator.er.world.inventory.ArtifactGUIMenu;
import net.mcreator.er.init.ErModMenus;
import net.mcreator.er.init.ErModItems;

import io.netty.buffer.Unpooled;

public class ArtifactItem_Right_ClickProcedure {
	public static void execute(LevelAccessor world, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		ItemStack item = ItemStack.EMPTY;
		if (getEntityGameType(entity) == GameType.CREATIVE) {
			if (entity instanceof ServerPlayer _ent) {
				BlockPos _bpos = new BlockPos(0, -64, 0);
				_ent.openMenu(new MenuProvider() {
					@Override
					public Component getDisplayName() {
						return Component.literal("ArtifactGUI");
					}

					@Override
					public boolean shouldTriggerClientSideContainerClosingOnOpen() {
						return false;
					}

					@Override
					public AbstractContainerMenu createMenu(int id, Inventory inventory, Player player) {
						return new ArtifactGUIMenu(id, inventory, new FriendlyByteBuf(Unpooled.buffer()).writeBlockPos(_bpos));
					}
				}, _bpos);
			}
			if (entity instanceof Player _player && _player.containerMenu instanceof ErModMenus.MenuAccessor _menu) {
				ItemStack _setstack3 = itemstack.copy();
				_setstack3.setCount(1);
				_menu.getSlots().get(0).set(_setstack3);
				_player.containerMenu.broadcastChanges();
			}
			item = new ItemStack(ErModItems.RARITY_GEMSTONE.get()).copy();
			item.setCount((int) (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("rarity") + 1));
			if (entity instanceof Player _player && _player.containerMenu instanceof ErModMenus.MenuAccessor _menu) {
				ItemStack _setstack9 = item.copy();
				_setstack9.setCount((int) (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("rarity") + 1));
				_menu.getSlots().get(6).set(_setstack9);
				_player.containerMenu.broadcastChanges();
			}
			item = new ItemStack(ErModItems.MINOR_UPGRADES.get()).copy();
			item.setCount((int) itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("minor_upgrade_times"));
			if (entity instanceof Player _player && _player.containerMenu instanceof ErModMenus.MenuAccessor _menu) {
				ItemStack _setstack15 = item.copy();
				_setstack15.setCount((int) itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("minor_upgrade_times"));
				_menu.getSlots().get(7).set(_setstack15);
				_player.containerMenu.broadcastChanges();
			}
			item = new ItemStack(ErModItems.MAIN_AFFIX_SHARD.get()).copy();
			{
				final String _tagName = "attribute_name";
				final String _tagValue = (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getString("main_attribute_name"));
				CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putString(_tagName, _tagValue));
			}
			{
				final String _tagName = "attribute_count";
				final double _tagValue = (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("main_attribute_count"));
				CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putDouble(_tagName, _tagValue));
			}
			{
				final String _tagName = "multiplied";
				final boolean _tagValue = (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBoolean("main_attribute_multiplied"));
				CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putBoolean(_tagName, _tagValue));
			}
			if (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("main_attribute_count") != 0) {
				if (entity instanceof Player _player && _player.containerMenu instanceof ErModMenus.MenuAccessor _menu) {
					ItemStack _setstack27 = item.copy();
					_setstack27.setCount(1);
					_menu.getSlots().get(1).set(_setstack27);
					_player.containerMenu.broadcastChanges();
				}
			}
			for (int index = 0; index < 4; index++) {
				item = new ItemStack(ErModItems.MINOR_AFFIX_SHARD.get()).copy();
				{
					final String _tagName = "attribute_name";
					final String _tagValue = (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getString(("minor_attribute_name_" + new java.text.DecimalFormat("##").format(index))));
					CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putString(_tagName, _tagValue));
				}
				{
					final String _tagName = "attribute_count";
					final double _tagValue = (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble(("minor_attribute_count_" + new java.text.DecimalFormat("##").format(index))));
					CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putDouble(_tagName, _tagValue));
				}
				{
					final String _tagName = "count_multiplier";
					final double _tagValue = (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble(("minor_count_multiplier_" + new java.text.DecimalFormat("##").format(index))));
					CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putDouble(_tagName, _tagValue));
				}
				{
					final String _tagName = "multiplied";
					final boolean _tagValue = (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBoolean(("minor_attribute_multiplied_" + new java.text.DecimalFormat("##").format(index))));
					CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putBoolean(_tagName, _tagValue));
				}
				if (itemstack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble(("minor_attribute_count_" + new java.text.DecimalFormat("##").format(index))) != 0) {
					if (entity instanceof Player _player && _player.containerMenu instanceof ErModMenus.MenuAccessor _menu) {
						ItemStack _setstack42 = item.copy();
						_setstack42.setCount(1);
						_menu.getSlots().get((int) index + 2).set(_setstack42);
						_player.containerMenu.broadcastChanges();
					}
				}
			}
		} else if (entity instanceof LivingEntity livEnt) {
			ErItemVariables.PlayerVariables _vars = entity.getData(ErItemVariables.PLAYER_VARIABLES);
			if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:flower_of_life")))) {
				if (itemstack.getItem() == (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()) {
					item = _vars.Flower_Of_Life.copy();
					_vars.Flower_Of_Life = itemstack.copy();
					livEnt.setItemInHand(InteractionHand.MAIN_HAND, item.copy());
					if (livEnt instanceof Player _player)
						_player.getInventory().setChanged();
				} else if (itemstack.getItem() == (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem()) {
					item = _vars.Flower_Of_Life.copy();
					_vars.Flower_Of_Life = itemstack.copy();
					livEnt.setItemInHand(InteractionHand.OFF_HAND, item.copy());
					if (livEnt instanceof Player _player)
						_player.getInventory().setChanged();
				}
			} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:plume_of_death")))) {
				if (itemstack.getItem() == (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()) {
					item = _vars.Plume_of_Death.copy();
					_vars.Plume_of_Death = itemstack.copy();
					livEnt.setItemInHand(InteractionHand.MAIN_HAND, item.copy());
					if (livEnt instanceof Player _player)
						_player.getInventory().setChanged();
				} else if (itemstack.getItem() == (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem()) {
					item = _vars.Plume_of_Death.copy();
					_vars.Plume_of_Death = itemstack.copy();
					livEnt.setItemInHand(InteractionHand.OFF_HAND, item.copy());
					if (livEnt instanceof Player _player)
						_player.getInventory().setChanged();
				}
			} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:sands_of_eon")))) {
				if (itemstack.getItem() == (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()) {
					item = _vars.Sands_Of_Eon.copy();
					_vars.Sands_Of_Eon = itemstack.copy();
					livEnt.setItemInHand(InteractionHand.MAIN_HAND, item.copy());
					if (livEnt instanceof Player _player)
						_player.getInventory().setChanged();
				} else if (itemstack.getItem() == (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem()) {
					item = _vars.Sands_Of_Eon.copy();
					_vars.Sands_Of_Eon = itemstack.copy();
					livEnt.setItemInHand(InteractionHand.OFF_HAND, item.copy());
					if (livEnt instanceof Player _player)
						_player.getInventory().setChanged();
				}
			} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:goblet_of_eonothem")))) {
				if (itemstack.getItem() == (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()) {
					item = _vars.Goblet_Of_Eonothem.copy();
					_vars.Goblet_Of_Eonothem = itemstack.copy();
					livEnt.setItemInHand(InteractionHand.MAIN_HAND, item.copy());
					if (livEnt instanceof Player _player)
						_player.getInventory().setChanged();
				} else if (itemstack.getItem() == (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem()) {
					item = _vars.Goblet_Of_Eonothem.copy();
					_vars.Goblet_Of_Eonothem = itemstack.copy();
					livEnt.setItemInHand(InteractionHand.OFF_HAND, item.copy());
					if (livEnt instanceof Player _player)
						_player.getInventory().setChanged();
				}
			} else if (itemstack.is(ItemTags.create(ResourceLocation.parse("er:circlet_of_logos")))) {
				if (itemstack.getItem() == (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem()) {
					item = _vars.Circlet_Of_Logos.copy();
					_vars.Circlet_Of_Logos = itemstack.copy();
					livEnt.setItemInHand(InteractionHand.MAIN_HAND, item.copy());
					if (livEnt instanceof Player _player)
						_player.getInventory().setChanged();
				} else if (itemstack.getItem() == (entity instanceof LivingEntity _livEnt ? _livEnt.getOffhandItem() : ItemStack.EMPTY).getItem()) {
					item = _vars.Circlet_Of_Logos.copy();
					_vars.Circlet_Of_Logos = itemstack.copy();
					livEnt.setItemInHand(InteractionHand.OFF_HAND, item.copy());
					if (livEnt instanceof Player _player)
						_player.getInventory().setChanged();
				}
			}
			_vars.syncPlayerVariables(entity);
		}
	}

	private static GameType getEntityGameType(Entity entity) {
		if (entity instanceof ServerPlayer serverPlayer) {
			return serverPlayer.gameMode.getGameModeForPlayer();
		} else if (entity instanceof Player player && player.level().isClientSide()) {
			PlayerInfo playerInfo = Minecraft.getInstance().getConnection().getPlayerInfo(player.getGameProfile().getId());
			if (playerInfo != null)
				return playerInfo.getGameMode();
		}
		return null;
	}
}