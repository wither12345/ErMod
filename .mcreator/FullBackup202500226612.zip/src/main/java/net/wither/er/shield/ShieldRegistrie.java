package net.wither.er.shield;

import net.neoforged.neoforge.registries.RegistryBuilder;
import net.neoforged.neoforge.registries.NewRegistryEvent;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.Registry;

import net.mcreator.er.ErMod;

import java.util.function.Supplier;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class ShieldRegistrie {
	public static final ResourceKey<Registry<ErShield>> SHIELD = ResourceKey.createRegistryKey(ResourceLocation.fromNamespaceAndPath("er", "shields"));
	public static final Registry<ErShield> SHIELD_REGISTRY = new RegistryBuilder<>(SHIELD).sync(true).maxId(256).create();

	@SubscribeEvent
	public static void registerRegistries(NewRegistryEvent event) {
		event.register(SHIELD_REGISTRY);
	}

	public static final DeferredRegister<ErShield> SHIELDS = DeferredRegister.create(SHIELD_REGISTRY, ErMod.MODID);
	public static final Supplier<ErShield> HYDRO_CTYSTALLIZE = SHIELDS.register("hydro_crystallize", () -> new HydroCrystallizeShield());
	public static final Supplier<ErShield> PYRO_CTYSTALLIZE = SHIELDS.register("pyro_crystallize", () -> new PyroCrystallizeShield());
	public static final Supplier<ErShield> ELECTRO_CTYSTALLIZE = SHIELDS.register("electro_crystallize", () -> new ElectroCrystallizeShield());
	public static final Supplier<ErShield> CRYO_CTYSTALLIZE = SHIELDS.register("cryo_crystallize", () -> new CryoCrystallizeShield());
	public static final Supplier<ErShield> THUNDER_SHIELD = SHIELDS.register("thunder_shield", () -> new ThunderShield());
}
