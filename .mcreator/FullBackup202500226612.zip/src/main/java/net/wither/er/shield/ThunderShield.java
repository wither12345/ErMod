package net.wither.er.shield;

import net.mcreator.er.init.ErModAttributes;
import net.minecraft.world.entity.Entity;
import net.wither.er.entity.ArcEntity;
import net.wither.er.ErDamageSource;

import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.Targeting;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.er.init.ErModEntities;

import ca.weblite.objc.Client;

public class ThunderShield extends ErShield implements RenderShield {
	private static final ResourceLocation resourcelocation = ResourceLocation.parse("er:thunder_shield.kb_res");

	//health = 240
	@OnlyIn(Dist.CLIENT)
	public class Client {
		private static final ResourceLocation TEXTURE_LOCATION = ResourceLocation.parse("er:textures/entities/electro_crystallize_shield.png");
		private static final RenderType RENDER_TYPE = RenderType.entityCutoutNoCull(TEXTURE_LOCATION);
	}


	public void start(Entity owner) {
		if(owner instanceof  LivingEntity living)
			living.getAttribute(Attributes.KNOCKBACK_RESISTANCE).addOrReplacePermanentModifier(new AttributeModifier(resourcelocation, 100, AttributeModifier.Operation.ADD_VALUE));
	}

	public void end(Entity owner) {
		if(owner instanceof  LivingEntity living)
			living.getAttribute(Attributes.KNOCKBACK_RESISTANCE).removeModifier(new AttributeModifier(resourcelocation, 100, AttributeModifier.Operation.ADD_VALUE));
	}


	public float onHurt(ShieldStack stack, Entity owner, DamageSource source, float damage, int elemental_type) {
		if (elemental_type == 1 || elemental_type == 5)
			stack.time -= 15;
		if (elemental_type == 2 || elemental_type == 3 || elemental_type == 7)
			stack.time -= 30;
		if (elemental_type == 6)
			stack.time -= 12;
		return damage;
	}

	@Override
	public boolean tick(ShieldStack stack, Entity owner) {
		stack.health += 1f;
		if (stack.health > 10) {
			stack.health = 0f;
			if (owner instanceof Targeting own && owner instanceof LivingEntity living) {
				LivingEntity target = own.getTarget();
				if (target != null && target.distanceToSqr(owner) <= 32) {
					target.hurt(new ErDamageSource(owner.level().holderOrThrow(DamageTypes.MOB_ATTACK), owner, 4, 80), 0.25f * (float) living.getAttribute(Attributes.ATTACK_DAMAGE).getValue());
					if (owner.level() instanceof ServerLevel _level) {
						ArcEntity entityToSpawn = ErModEntities.ARC.get().spawn(_level, BlockPos.containing(owner.getX(), owner.getY() + 2, owner.getZ()), MobSpawnType.MOB_SUMMONED);
						entityToSpawn.setActiveTarget(target.getId());
						entityToSpawn.setOnlyEffect(true);
					}
				}
			}
		}
		return super.tick(stack, owner);
	}

	@OnlyIn(Dist.CLIENT)
	public RenderType getRender() {
		return Client.RENDER_TYPE;
	}
}
