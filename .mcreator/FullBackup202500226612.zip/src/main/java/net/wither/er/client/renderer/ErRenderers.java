package net.wither.er.client.renderer;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.math.Axis;
import net.mcreator.er.ErMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.renderer.OutlineBufferSource;
import net.minecraft.util.FastColor;
import net.minecraft.world.entity.player.Player;
import net.wither.er.entity.ErEntityInterface;
import net.wither.er.shield.RenderShield;
import net.wither.er.shield.ErShield;
import net.wither.er.entity.ErShieldEntity;

import net.neoforged.neoforge.client.event.RenderLivingEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.model.EntityModel;

import java.util.List;

import java.lang.reflect.Field;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;
import org.lwjgl.opengl.GL11;

import static net.minecraft.client.renderer.entity.LivingEntityRenderer.getOverlayCoords;

@OnlyIn(Dist.CLIENT)
@EventBusSubscriber(value = {Dist.CLIENT})
public class ErRenderers {

	@SubscribeEvent
	public static void onEntityRender(RenderLivingEvent.Pre event) {
		LivingEntity entity = event.getEntity();
		PoseStack poseStack = event.getPoseStack();
		MultiBufferSource bufferSource = event.getMultiBufferSource();
		LivingEntityRenderer<LivingEntity, EntityModel<LivingEntity>> renderer = event.getRenderer();
		int light = event.getPackedLight();
		renderShield(entity, poseStack,bufferSource,renderer,light);
	}
	private static void renderShield(LivingEntity entity , PoseStack poseStack, MultiBufferSource bufferSource, LivingEntityRenderer<LivingEntity, EntityModel<LivingEntity>> renderer ,int light){
		if(entity instanceof ErEntityInterface enti) {
			List<ErShield> shields = enti.getShields();
			for (ErShield shield : shields) {
				if (shield instanceof RenderShield rend) {
					poseStack.pushPose();
					poseStack.translate(0f, entity.getBbHeight() * 0, 0f);
					float scale = (float) Math.sqrt(Math.pow(entity.getBbHeight(), 2) * 2 + Math.pow(entity.getBbWidth(), 2));
					poseStack.scale(scale, scale, scale);
					try {
						Field field = EntityRenderer.class.getDeclaredField("entityRenderDispatcher");
						field.setAccessible(true);
						//poseStack.mulPose(((EntityRenderDispatcher) field.get(renderer)).cameraOrientation());
						poseStack.rotateAround(((EntityRenderDispatcher) field.get(renderer)).cameraOrientation(), 0, 0.25f, 0);
					} catch (Exception e) {
					}
					PoseStack.Pose posestack$pose = poseStack.last();
					VertexConsumer vertexconsumer = bufferSource.getBuffer(rend.getRender());
					vertex(vertexconsumer, posestack$pose, light, 0.0F, 0, 0, 1);
					vertex(vertexconsumer, posestack$pose, light, 1.0F, 0, 1, 1);
					vertex(vertexconsumer, posestack$pose, light, 1.0F, 1, 1, 0);
					vertex(vertexconsumer, posestack$pose, light, 0.0F, 1, 0, 0);
					poseStack.popPose();
				}
			}
		}
	}
	private static void vertex(VertexConsumer consumer, PoseStack.Pose p_324420_, int p_253829_, float p_253995_, int p_254031_, int p_253641_, int p_254243_) {
		consumer.addVertex(p_324420_, p_253995_ - 0.5F, (float) p_254031_ - 0.25F, 0.0F).setColor(-1).setUv((float) p_253641_, (float) p_254243_).setOverlay(OverlayTexture.NO_OVERLAY).setLight(p_253829_).setNormal(p_324420_, 0.0F, 1.0F, 0.0F);
	}
}
