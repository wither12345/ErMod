package net.wither.er.client.screens;

import net.wither.er.shield.HeartChangingShield;
import net.wither.er.shield.ErShield;
import net.wither.er.entity.ErShieldEntity;

import net.neoforged.neoforge.event.entity.player.PlayerHeartTypeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.entity.player.Player;

import java.util.List;

@EventBusSubscriber(value = {Dist.CLIENT})
public class HeartShieldOverlay {
	@SubscribeEvent
	public static void HeartTypeChanging(PlayerHeartTypeEvent event) {
		Player player = event.getEntity();
		List<ErShield> shields = (ErShieldEntity.getShields(player));
		for (ErShield shield : shields) {
			if (shield instanceof HeartChangingShield) {
				event.setType(((HeartChangingShield) shield).getType());
				return;
			}
		}
	}
}
