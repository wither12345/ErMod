package net.wither.er.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.BowItem;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.AbstractSkeleton;
import net.minecraft.world.entity.ai.goal.RangedBowAttackGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.Difficulty;

@Mixin(AbstractSkeleton.class)
public abstract class AbstractSkeletonMixin extends Monster implements RangedAttackMob {
	@Shadow
	private final RangedBowAttackGoal<AbstractSkeleton> bowGoal = new RangedBowAttackGoal<>(this, 1.0, 20, 15.0F);
	@Shadow
	private final MeleeAttackGoal meleeGoal = new MeleeAttackGoal(this, 1.2, false);

	@Shadow
	protected abstract int getHardAttackInterval();

	@Shadow
	protected abstract int getAttackInterval();

	protected AbstractSkeletonMixin(EntityType<? extends AbstractSkeleton> p_32133_, Level p_32134_) {
		super(p_32133_, p_32134_);
	}

	@Inject(method = "reassessWeaponGoal", at = @At("TAIL"))
	public void reassessWeaponGoal(CallbackInfo info) {
		if (this.level() != null && !this.level().isClientSide) {
			ItemStack itemstack = this.getItemInHand(ProjectileUtil.getWeaponHoldingHand(this, item -> item instanceof net.minecraft.world.item.BowItem));
			if (itemstack.getItem() instanceof BowItem) {
				this.goalSelector.removeGoal(meleeGoal);
				this.goalSelector.removeGoal(bowGoal);
				int i = this.getHardAttackInterval();
				if (this.level().getDifficulty() != Difficulty.HARD) {
					i = this.getAttackInterval();
				}
				this.bowGoal.setMinAttackInterval(i);
				this.goalSelector.addGoal(4, this.bowGoal);
			}
		}
	}
}
