package net.wither.er.entity;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.wither.er.shield.ErShield;
import net.wither.er.shield.ShieldStack;

import java.util.List;

public interface ErEntityInterface {

    abstract List<ShieldStack> getShieldStacks();
    abstract List<ErShield> getShields();
    abstract void setShields(CompoundTag tag);
    abstract void addShield(ShieldStack shield) ;
    abstract void removeShield(ErShield shield);
    abstract void cleanShield();
    abstract void syncShield() ;
    abstract void syncShield(ServerPlayer player) ;
}
