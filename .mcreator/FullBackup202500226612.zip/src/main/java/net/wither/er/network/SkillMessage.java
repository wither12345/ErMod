package net.wither.er.network;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.RegistryFriendlyByteBuf;

import net.mcreator.er.StellaFortunas;
import net.mcreator.er.ErMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public record SkillMessage(int eventType, int pressedms) implements CustomPacketPayload {
	public static final Type<SkillMessage> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(ErMod.MODID, "key_key_r"));
	public static final StreamCodec<RegistryFriendlyByteBuf, SkillMessage> STREAM_CODEC = StreamCodec.of((RegistryFriendlyByteBuf buffer, SkillMessage message) -> {
		buffer.writeInt(message.eventType);
		buffer.writeInt(message.pressedms);
	}, (RegistryFriendlyByteBuf buffer) -> new SkillMessage(buffer.readInt(), buffer.readInt()));

	@Override
	public Type<SkillMessage> type() {
		return TYPE;
	}

	public static void handleData(final SkillMessage message, final IPayloadContext context) {
		if (context.flow() == PacketFlow.SERVERBOUND) {
			context.enqueueWork(() -> {
				pressAction(context.player(), message.eventType, message.pressedms);
			}).exceptionally(e -> {
				context.connection().disconnect(Component.literal(e.getMessage()));
				return null;
			});
		}
	}

	public static void pressAction(Player entity, int type, int pressedms) {
		Level world = entity.level();
		double x = entity.getX();
		double y = entity.getY();
		double z = entity.getZ();
		if (!world.hasChunkAt(entity.blockPosition()))
			return;
		if (type == 0) {
			onDown(entity);
		}
		if (type == 1) {
			release(entity);
		}
	}

	public static void onDown(Player player) {
		player.getPersistentData().putBoolean("skillPressing", true);
		ItemStack stack = player.getData(ErItemVariables.PLAYER_VARIABLES).Stella_Fortuna;
		if (stack.getItem() instanceof StellaFortunas SF) {
			SF.ElementalSkillStart(player);
		}
	}

	public static void release(Player player) {
		player.getPersistentData().putBoolean("skillPressing", false);
		ItemStack stack = player.getData(ErItemVariables.PLAYER_VARIABLES).Stella_Fortuna;
		if (stack.getItem() instanceof StellaFortunas SF) {
			SF.ElementalSkillEnd(player);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		ErMod.addNetworkMessage(SkillMessage.TYPE, SkillMessage.STREAM_CODEC, SkillMessage::handleData);
	}
}