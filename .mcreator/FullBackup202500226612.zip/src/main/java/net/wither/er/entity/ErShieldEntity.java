package net.wither.er.entity;

import net.wither.er.shield.ShieldStack;
import net.wither.er.shield.ShieldRegistrie;
import net.wither.er.shield.ErShield;
import net.wither.er.network.ErShieldData;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.nbt.CompoundTag;

import java.util.Set;
import java.util.List;
import java.util.ArrayList;

public class ErShieldEntity {
	public static List<ShieldStack> getShieldStacks(LivingEntity entity) {
		List<ShieldStack> shields = new ArrayList<>();
		CompoundTag tag = entity.getPersistentData().getCompound("ErShield");
		Set<String> keys = tag.getAllKeys();
		for (String key : keys) {
			ErShield shield = ShieldRegistrie.SHIELD_REGISTRY.get(ResourceLocation.parse(key));
			shields.add(new ShieldStack(shield, tag.getCompound(key)));
		}
		return shields;
	}

	public static List<ErShield> getShields(LivingEntity entity) {
		List<ErShield> shields = new ArrayList<>();
		CompoundTag tag = entity.getPersistentData().getCompound("ErShield");
		Set<String> keys = tag.getAllKeys();
		for (String key : keys) {
			ErShield shield = ShieldRegistrie.SHIELD_REGISTRY.get(ResourceLocation.parse(key));
			shields.add(shield);
		}
		return shields;
	}

	public static void addShield(LivingEntity entity, ShieldStack shield) {
		shield.getShield().start(entity);
		CompoundTag tag = entity.getPersistentData().getCompound("ErShield");
		tag.put(ShieldRegistrie.SHIELD_REGISTRY.getKey(shield.getShield()).toString(), shield.toTag());
		entity.getPersistentData().put("ErShield", tag);
		PacketDistributor.sendToAllPlayers(new ErShieldData(entity.getId(), tag));
	}

	public static void removeShield(LivingEntity entity, ShieldStack shield) {
		shield.getShield().end(entity);
		removeShield(entity, ShieldRegistrie.SHIELD_REGISTRY.getKey(shield.getShield()).toString());
	}

	public static void removeShield(LivingEntity entity, ErShield shield) {
		shield.end(entity);
		removeShield(entity, ShieldRegistrie.SHIELD_REGISTRY.getKey(shield).toString());
	}

	public static void removeShield(LivingEntity entity, String shield) {
		CompoundTag tag = entity.getPersistentData().getCompound("ErShield");
		if (tag.contains(shield)) {
			tag.remove(shield);
			entity.getPersistentData().put("ErShield", tag);
			PacketDistributor.sendToAllPlayers(new ErShieldData(entity.getId(), tag));
		}
	}
}
