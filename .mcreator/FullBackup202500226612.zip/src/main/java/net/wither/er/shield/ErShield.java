package net.wither.er.shield;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageSource;

public abstract class ErShield {
	public abstract void start(Entity owner);

	public boolean tick(ShieldStack stack, Entity owner) {
		return stack.time-- > 0;
	}

	public abstract void end(Entity owner);

	public abstract float onHurt(ShieldStack stack, Entity owner, DamageSource source, float damage, int elemental_type);
}
