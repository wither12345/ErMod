package net.wither.er;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.core.Holder;

import javax.annotation.Nullable;

public class ErDamageSource extends DamageSource {
	private final int elemental_type;
	private final int elemental_strength;

	public ErDamageSource(Holder<DamageType> p_270906_, @Nullable Entity p_270796_, @Nullable Entity p_270459_, @Nullable Vec3 p_270623_, int type, int strength) {
		super(p_270906_, p_270796_, p_270459_, p_270623_);
		this.elemental_type = type;
		this.elemental_strength = strength;
	}

	public ErDamageSource(Holder<DamageType> p_270818_, @Nullable Entity p_270162_, @Nullable Entity p_270115_, int type, int strength) {
		super(p_270818_, p_270162_, p_270115_, null);
		this.elemental_type = type;
		this.elemental_strength = strength;
	}

	public ErDamageSource(Holder<DamageType> p_270690_, Vec3 p_270579_, int type, int strength) {
		super(p_270690_, null, null, p_270579_);
		this.elemental_type = type;
		this.elemental_strength = strength;
	}

	public ErDamageSource(Holder<DamageType> p_270811_, @Nullable Entity p_270660_, int type, int strength) {
		super(p_270811_, p_270660_, p_270660_);
		this.elemental_type = type;
		this.elemental_strength = strength;
	}

	public ErDamageSource(Holder<DamageType> p_270475_, int type, int strength) {
		super(p_270475_, null, null, null);
		this.elemental_type = type;
		this.elemental_strength = strength;
	}

	public int getType() {
		return this.elemental_type;
	}

	public int getStrength() {
		return this.elemental_strength;
	}
}
