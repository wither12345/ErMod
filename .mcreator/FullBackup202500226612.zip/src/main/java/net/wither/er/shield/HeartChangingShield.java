package net.wither.er.shield;

import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.gui.Gui;

public interface HeartChangingShield {
	@OnlyIn(Dist.CLIENT)
	Gui.HeartType getType();
}
