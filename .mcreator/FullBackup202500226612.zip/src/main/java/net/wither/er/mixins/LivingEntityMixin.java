package net.wither.er.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import org.checkerframework.common.aliasing.qual.Unique;

import net.wither.er.shield.ShieldStack;
import net.wither.er.shield.ShieldRegistrie;
import net.wither.er.shield.ErShield;
import net.wither.er.network.ErShieldData;
import net.wither.er.entity.ErEntityInterface;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Attackable;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.nbt.CompoundTag;

import java.util.Set;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin extends Entity implements Attackable, ErEntityInterface {
	@Unique
	private ArrayList<ShieldStack> shields = new ArrayList<>();

	//private static final EntityDataAccessor<ErShield> DATA_ERSHIELD = SynchedEntityData.defineId(LivingEntity.class, ErShieldData.STREAM_CODEC);
	public LivingEntityMixin(EntityType<?> p_19870_, Level p_19871_) {
		super(p_19870_, p_19871_);
	}

	public List<ShieldStack> getShieldStacks() {
		return this.shields;
	}

	public List<ErShield> getShields() {
		List<ErShield> erShields = new ArrayList<>();
		for (ShieldStack shield : shields)
			erShields.add(shield.getShield());
		return erShields;
	}

	public void addShield(ShieldStack shield) {
		shield.getShield().start(this);
		this.shields.add(shield);
		syncShield();
	}

	@Inject(method = "addAdditionalSaveData", at = @At("HEAD"))
	public void addAdditionalSaveData(CompoundTag compound, CallbackInfo info) {
		CompoundTag tag = new CompoundTag();
		for (ShieldStack shield : shields) {
			tag.put(ShieldRegistrie.SHIELD_REGISTRY.getKey(shield.getShield()).toString(), shield.toTag());
		}
		compound.put("ErShield", tag);
	}

	@Inject(method = "readAdditionalSaveData", at = @At("HEAD"))
	public void readAdditionalSaveData(CompoundTag compound, CallbackInfo info) {
		setShields(compound.getCompound("ErShield"));
	}

	public void removeShield(ErShield shield) {
		shield.end(this);
		Iterator<ShieldStack> iterator = this.shields.iterator();
		while (iterator.hasNext()) {
			ShieldStack shieldstack = iterator.next();
			if (shieldstack.getShield() == shield) {
				iterator.remove();
			}
		}
		syncShield();
	}

	public void setShields(CompoundTag tag) {
		Set<String> keys = tag.getAllKeys();
		this.shields.clear();
		for (String key : keys) {
			ErShield shield = ShieldRegistrie.SHIELD_REGISTRY.get(ResourceLocation.parse(key));
			this.shields.add(new ShieldStack(shield, tag.getCompound(key)));
		}
	}

	public void cleanShield() {
		shields.clear();
		syncShield();
	}

	public void syncShield() {
		CompoundTag tag = new CompoundTag();
		for (ShieldStack shield : shields) {
			tag.put(ShieldRegistrie.SHIELD_REGISTRY.getKey(shield.getShield()).toString(), shield.toTag());
		}
		PacketDistributor.sendToPlayersTrackingEntityAndSelf(this, new ErShieldData(this.getId(), tag));
	}

	public void syncShield(ServerPlayer player) {
		CompoundTag tag = new CompoundTag();
		for (ShieldStack shield : shields) {
			tag.put(ShieldRegistrie.SHIELD_REGISTRY.getKey(shield.getShield()).toString(), shield.toTag());
		}
		PacketDistributor.sendToPlayer(player, new ErShieldData(this.getId(), tag));
	}
}
