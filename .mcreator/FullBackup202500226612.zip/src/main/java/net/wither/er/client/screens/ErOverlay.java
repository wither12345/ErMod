package net.wither.er.client.screens;

import org.checkerframework.checker.units.qual.h;

import net.wither.er.network.ErItemVariables;
import net.wither.er.network.ErCombatVariables;

import net.neoforged.neoforge.client.event.RenderGuiEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.util.Mth;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.Minecraft;

import net.mcreator.er.init.ErModAttributes;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.platform.GlStateManager;

@EventBusSubscriber({Dist.CLIENT})
public class ErOverlay {
	private static final ResourceLocation STAMINA_SPRITE = ResourceLocation.parse("er:hud/stamina_full");
	private static final ResourceLocation STAMINA_EMPTY_SPRITE = ResourceLocation.parse("er:hud/stamina_empty");

	@SubscribeEvent(priority = EventPriority.NORMAL)
	public static void eventHandler(RenderGuiEvent.Post event) {
		int w = event.getGuiGraphics().guiWidth();
		int h = event.getGuiGraphics().guiHeight();
		Player player = Minecraft.getInstance().player;
		MayberenderPlayerStamina(player, event.getGuiGraphics());
		renderElementalSkillIcon(player, event.getGuiGraphics(), w, h);
	}

	private static void renderElementalSkillIcon(Player player, GuiGraphics graphics, int w, int h) {
		if (player.getData(ErItemVariables.PLAYER_VARIABLES).Stella_Fortuna.getItem() == ItemStack.EMPTY.getItem())
			return;
		ErCombatVariables.PlayerVariables vars = player.getData(ErCombatVariables.PLAYER_VARIABLES);
		float chargingPercent = vars.skillCooldown / vars.stackedMaxSkillCooldown;
		if (chargingPercent > 0.5) {
			graphics.blit(ResourceLocation.parse("er:textures/screens/elemental_skill_l.png"), w - 97, h - 61, 0, 0, 32, (int) (32 * Math.sin(chargingPercent * Math.PI)), 32, 32);
		} else if (chargingPercent > 0) {
			graphics.blit(ResourceLocation.parse("er:textures/screens/elemental_skill_l.png"), w - 97, h - 61, 0, 0, 32, 32, 32, 32);
			graphics.blit(ResourceLocation.parse("er:textures/screens/elemental_skill_r.png"), w - 97, h - 61 + (int) (32 * Math.sin(chargingPercent * Math.PI)), 0, (int) (32 * Math.sin(chargingPercent * Math.PI)), 32,
					(int) (33 - 32 * Math.sin(chargingPercent * Math.PI)), 32, -32);
		} else {
			graphics.blit(ResourceLocation.parse("er:textures/screens/elemental_skill_l.png"), w - 97, h - 61, 0, 0, 32, 32, 32, 32);
			graphics.blit(ResourceLocation.parse("er:textures/screens/elemental_skill_r.png"), w - 97, h - 61, 0, 32, 32, 32, 32, -32);
		}
	}

	private static void MayberenderPlayerStamina(Player player, GuiGraphics graphics) {
		Minecraft minecraft = Minecraft.getInstance();
		Gui gui = minecraft.gui;
		if (minecraft.gameMode.canHurtPlayer()) {
			if (player != null) {
				int i1 = graphics.guiWidth() / 2 + 91;
				minecraft.getProfiler().push("stamina");
				double maxStamina = player.getAttribute(ErModAttributes.MAX_STAMINA).getValue();
				ErCombatVariables.PlayerVariables vars = player.getData(ErCombatVariables.PLAYER_VARIABLES);
				int i3 = 20;
				int j3 = (int) (vars.stamina / maxStamina * 20);
				int rightHeight = gui.rightHeight;
				if (j3 < i3) {
					int j2 = graphics.guiHeight() - rightHeight;
					int l3 = Mth.ceil((double) (j3 - 2) * 10.0 / (double) i3);
					int i4 = Mth.ceil((double) j3 * 10.0 / (double) i3) - l3;
					RenderSystem.disableDepthTest();
					RenderSystem.depthMask(false);
					RenderSystem.enableBlend();
					RenderSystem.setShader(GameRenderer::getPositionTexShader);
					RenderSystem.blendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
					RenderSystem.setShaderColor(1, 1, 1, 1);
					for (int j4 = 0; j4 < l3 + i4; j4++) {
						graphics.blitSprite(STAMINA_SPRITE, i1 - j4 * 8 - 9, j2, 9, 9);
					}
					RenderSystem.disableBlend();
					RenderSystem.depthMask(true);
					RenderSystem.defaultBlendFunc();
					RenderSystem.enableDepthTest();
					RenderSystem.setShaderColor(1, 1, 1, 1);
					rightHeight += 10;
				}
				minecraft.getProfiler().pop();
				gui.rightHeight = rightHeight;
			}
		}
	}
}