package net.wither.er.shield;

import net.minecraft.world.entity.Entity;
import net.neoforged.fml.common.asm.enumextension.EnumProxy;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.gui.Gui;

import net.mcreator.er.init.ErModAttributes;

import ca.weblite.objc.Client;

public class CryoCrystallizeShield extends ErShield implements HeartChangingShield, RenderShield {
	private static final ResourceLocation resourcelocation = ResourceLocation.parse("er:cryo_crystallize.kb_res");

	@OnlyIn(Dist.CLIENT)
	public class Client {
		private static final ResourceLocation TEXTURE_LOCATION = ResourceLocation.parse("er:textures/entities/cryo_crystallize_shield.png");
		private static final RenderType RENDER_TYPE = RenderType.entityCutoutNoCull(TEXTURE_LOCATION);
		public static final EnumProxy<Gui.HeartType> CRYO = new EnumProxy<>(Gui.HeartType.class, ResourceLocation.parse("er:heart/cryo_crystallize/full"), ResourceLocation.parse("er:heart/cryo_crystallize/full_blinking"),
				ResourceLocation.parse("er:heart/cryo_crystallize/half"), ResourceLocation.parse("er:heart/cryo_crystallize/half_blinking"), ResourceLocation.parse("er:heart/cryo_crystallize/hardcore_full"),
				ResourceLocation.parse("er:heart/cryo_crystallize/hardcore_full_blinking"), ResourceLocation.parse("er:heart/cryo_crystallize/hardcore_half"), ResourceLocation.parse("er:heart/cryo_crystallize/hardcore_half_blinking"));
	}

	@OnlyIn(Dist.CLIENT)
	public Gui.HeartType getType() {
		return Client.CRYO.getValue();
	}

	public void start(Entity owner) {
		if(owner instanceof  LivingEntity living)
			living.getAttribute(Attributes.KNOCKBACK_RESISTANCE).addOrReplacePermanentModifier(new AttributeModifier(resourcelocation, 100, AttributeModifier.Operation.ADD_VALUE));
	}

	public void end(Entity owner) {
		if(owner instanceof  LivingEntity living)
			living.getAttribute(Attributes.KNOCKBACK_RESISTANCE).removeModifier(new AttributeModifier(resourcelocation, 100, AttributeModifier.Operation.ADD_VALUE));
	}

	public float onHurt(ShieldStack stack, Entity owner, DamageSource source, float damage, int elemental_type) {
		float multi = 1.0f ;
		if(owner instanceof  LivingEntity living)
			multi = (float) living.getAttribute(ErModAttributes.SHIELD_STRENGTH).getValue() / 100f + 1f;
		if (elemental_type == 2)
			multi *= 2.5f;
		if (stack.health * multi > damage) {
			stack.health -= damage / multi;
			return damage;
		}
		stack.health = -1;
		stack.time = 0;
		return stack.health * multi;
	}

	@Override
	public boolean tick(ShieldStack stack, Entity owner) {
		return super.tick(stack,owner) && stack.health > 0 ;
	}

	@OnlyIn(Dist.CLIENT)
	public RenderType getRender() {
		return Client.RENDER_TYPE;
	}
}
