package net.mcreator.er.potion;

import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.client.extensions.common.IClientMobEffectExtensions;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.er.procedures.ElectroChargedDoProcedure;
import net.mcreator.er.procedures.ElectroChargedActiveProcedure;
import net.mcreator.er.init.ErModMobEffects;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class ElectroChargedMobEffect extends MobEffect {
	public ElectroChargedMobEffect() {
		super(MobEffectCategory.HARMFUL, -6749953);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return ElectroChargedActiveProcedure.execute(duration);
	}

	@Override
	public boolean applyEffectTick(LivingEntity entity, int amplifier) {
		ElectroChargedDoProcedure.execute(entity.level(), entity, amplifier);
		return super.applyEffectTick(entity, amplifier);
	}

	@SubscribeEvent
	public static void registerMobEffectExtensions(RegisterClientExtensionsEvent event) {
		event.registerMobEffect(new IClientMobEffectExtensions() {
			@Override
			public boolean isVisibleInGui(MobEffectInstance effect) {
				return false;
			}
		}, ErModMobEffects.ELECTRO_CHARGED.get());
	}
}