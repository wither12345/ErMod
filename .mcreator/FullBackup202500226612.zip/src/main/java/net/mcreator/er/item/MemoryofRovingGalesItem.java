package net.mcreator.er.item;

import net.wither.er.network.ErCombatVariables;
import net.wither.er.ErDamageSource;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.client.animation.AnimationDefinition;

import net.mcreator.er.init.ErModParticleTypes;
import net.mcreator.er.client.model.animations.travelerAnimation;
import net.mcreator.er.StellaFortunas;

import java.util.Comparator;

public class MemoryofRovingGalesItem extends StellaFortunas {
	public MemoryofRovingGalesItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.RARE));
	}

	public void onTick(LevelAccessor world, LivingEntity entity, double x, double y, double z) {
		ErCombatVariables.PlayerVariables vars = entity.getData(ErCombatVariables.PLAYER_VARIABLES);
	}

	public void ElementalSkillStart(LivingEntity entity) {
		ErCombatVariables.PlayerVariables vars = entity.getData(ErCombatVariables.PLAYER_VARIABLES);
		if (vars.skillCooldown <= 0) {
			vars.Animation_Time = 1000;
			vars.Combo = 20;
		}
		vars.syncPlayerVariables(entity);
	}

	public void ElementalSkillEnd(LivingEntity entity) {
		ErCombatVariables.PlayerVariables vars = entity.getData(ErCombatVariables.PLAYER_VARIABLES);
		if (vars.Animation_Time > 0) {
			vars.Animation_Time = 14;
			vars.Combo = 21;
			Level world = entity.level();
			if (vars.Animation_Time < 990) {
				entity.getPersistentData().putBoolean("skillPressed", true);
				vars.skillCooldown = 8;
				vars.stackedMaxSkillCooldown = 8;
			} else {
				vars.skillCooldown = 5;
				vars.stackedMaxSkillCooldown = 5;
				entity.getPersistentData().putBoolean("skillPressed", false);
			}
		}
		vars.syncPlayerVariables(entity);
	}

	public void ElementalBurstStart(LivingEntity entity) {
	}

	public void ElementalBurstEnd(LivingEntity entity) {
	}

	public AnimationDefinition getAnimation(int combo) {
		if (combo == 20)
			return travelerAnimation.ElementalSkillAnemoStart;
		if (combo == 21)
			return travelerAnimation.ElementalSkillAnemoEnd;
		if (combo == 10)
			return travelerAnimation.ChargedAttack;
		if (combo % 4 == 0)
			return travelerAnimation.NormalAttack1;
		if (combo % 4 == 1)
			return travelerAnimation.NormalAttack2;
		if (combo % 4 == 2)
			return travelerAnimation.NormalAttack3;
		return travelerAnimation.NormalAttack4;
	}

	public int getMaxCombo(LivingEntity entity) {
		return 5;
	}

	public boolean hasAnimation(LivingEntity entity) {
		return entity.getMainHandItem().getItem() instanceof SwordItem;
	}

	public int getAnimationTick(LivingEntity entity, int combo, float speed) {
		if (combo == 2)
			return (int) (29 / speed) + 1;
		return (int) (27 / speed) + 1;
	}

	public int getFinishTick(LivingEntity entity, int combo, float speed) {
		if (combo == 20)
			return 0;
		if (combo == 21)
			return 6;
		if (combo == 2)
			return (int) (18 / speed) + 1;
		return (int) (19 / speed) + 1;
	}

	public int getChargedAttackCost(LivingEntity entity) {
		return 20;
	}

	public void AnimationTicking(LivingEntity entity, int combo, double time, float speed) {
		if (entity.level() instanceof ServerLevel)
			if (combo == 10 && time == (int) (24 / speed) + 1) {
				{
					PerformAttack(entity, 1, 2.2, 2.5, entity.getEyePosition(), DamageMulti(combo, 0));
				}
				if (combo == 2 & time == (int) (21 / speed) + 1)
					PerformAttack(entity, 1, 2.2, 2.5, entity.getEyePosition(), DamageMulti(2, 0));
				if (combo != 2 && time == (int) (22 / speed) + 1) {
					PerformAttack(entity, 1, 2.2, 2.5, entity.getEyePosition(), DamageMulti(combo, 1));
				}
			}
		if (time <= this.getFinishTick(entity, combo, speed) && combo <= this.getMaxCombo(entity) && entity.getPersistentData().getBoolean("WaitingChargeAttack")) {
			ErCombatVariables.PlayerVariables vars = entity.getData(ErCombatVariables.PLAYER_VARIABLES);
			if (vars.stamina >= this.getChargedAttackCost(entity)) {
				vars.stamina -= this.getChargedAttackCost(entity);
				vars.Combo = 10;
				vars.Animation_Time = this.getAnimationTick(entity, 10, speed);
				vars.staminaRecoveryCooldown = 50;
				vars.syncAnimation(entity);
				entity.getPersistentData().putBoolean("WaitingChargeAttack", false);
			}
		}
		if (combo == 20) {
			Level world = entity.level();
			float yaw = entity.getYRot();
			Vec3 lookVec = new Vec3(-Math.sin(yaw * Math.PI / 180), 0, Math.cos(yaw * Math.PI / 180)).normalize().scale(2);
			final Vec3 _center = (new Vec3(entity.getX(), entity.getY() + 1.2, entity.getZ())).add(lookVec);
			world.addParticle((SimpleParticleType) (ErModParticleTypes.ANEMO_EXPLOSION.get()), _center.x, _center.y, _center.z, 0, 0, 0);
			if (time == 993 || time == 995) {
				for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(1), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
					if (entityiterator instanceof LivingEntity living) {
						entityiterator.hurt(
								new ErDamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:elemental_skill_damage"))), entity, 1, 200),
								(float) (entity.getAttribute(Attributes.ATTACK_DAMAGE).getValue() * DamageMulti(20, 0)));
					}
				}
			}
			if (time == 983 || time == 973 || time == 970) {
				for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(1), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
					if (entityiterator instanceof LivingEntity living) {
						entityiterator.hurt(
								new ErDamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:elemental_skill_damage"))), entity, 1, 200),
								(float) (entity.getAttribute(Attributes.ATTACK_DAMAGE).getValue() * DamageMulti(20, 1)));
					}
				}
			}
			if (time < 970) {
				ElementalSkillEnd(entity);
			}
		}
		if (combo == 21) {
			if (time == 9) {
				float yaw = entity.getYRot();
				Vec3 lookVec = new Vec3(-Math.sin(yaw * Math.PI / 180), 0, Math.cos(yaw * Math.PI / 180)).normalize().scale(2);
				final Vec3 _center = (new Vec3(entity.getX(), entity.getY() + 1.2, entity.getZ())).add(lookVec);
				Level world = entity.level();
				for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(3), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
					if (entityiterator instanceof LivingEntity living) {
						entityiterator.hurt(
								new ErDamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:elemental_skill_damage"))), entity, 1, 200),
								(float) (entity.getAttribute(Attributes.ATTACK_DAMAGE).getValue() * DamageMulti(21, entity.getPersistentData().getBoolean("skillPressed") ? 1 : 0)));
					}
				}
			}
		}
	}

	public float DamageMulti(int combo, int index) {
		if (combo == 0)
			return 0.445f;
		else if (combo == 1)
			return 0.434f;
		else if (combo == 2)
			return 0.53f;
		else if (combo == 3)
			return 0.583f;
		else if (combo == 4)
			return 0.708f;
		else if (combo == 10)
			return index == 0 ? 0.559f : 0.772f;
		else if (combo == 20)
			return index == 0 ? 0.12f : 0.168f;
		else if (combo == 21)
			return index == 0 ? 1.76f : 1.92f;
		return 1;
	}
}