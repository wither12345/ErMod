/**
 * The code of this mod element is always locked.
 *
 * You can register new events in this class too.
 *
 * If you want to make a plain independent class, create it using
 * Project Browser -> New... and make sure to make the class
 * outside net.mcreator.er as this package is managed by MCreator.
 *
 * If you change workspace package, modid or prefix, you will need
 * to manually adapt this file to these changes or remake it.
 *
 * This class will be added in the mod root package.
*/
package net.mcreator.er;

import net.neoforged.neoforge.event.entity.player.ItemTooltipEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.BowItem;
import net.minecraft.network.chat.Component;
import net.minecraft.core.component.DataComponents;

import net.mcreator.er.procedures.GetWeaponMaxExpProcedure;

import java.util.List;

@EventBusSubscriber(value = {Dist.CLIENT})
public class WeaponDescription {
	@SubscribeEvent //(priority = EventPriority.HIGHEST)
	public static void onItemTooltip(ItemTooltipEvent event) {
		List<Component> list = event.getToolTip();
		ItemStack item = event.getItemStack();
		if (item.getItem() instanceof SwordItem || item.getItem() instanceof BowItem) {
			list.add(1, Component.literal(new java.text.DecimalFormat("+##").format(item.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getInt("level") + 1)));
			list.add(2, Component.literal(
					new java.text.DecimalFormat("##").format(item.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getInt("experience")) + "/" + new java.text.DecimalFormat("##").format(GetWeaponMaxExpProcedure.execute(item))));
		}
	}
}
