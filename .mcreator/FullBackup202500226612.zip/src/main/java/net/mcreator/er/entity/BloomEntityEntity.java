package net.mcreator.er.entity;

import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.common.NeoForgeMod;

import net.minecraft.world.level.pathfinder.PathType;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.Mth;

import net.mcreator.er.procedures.BloomEntityUpdateProcedure;

public class BloomEntityEntity extends PathfinderMob {
	public BloomEntityEntity(EntityType<BloomEntityEntity> type, Level world) {
		super(type, world);
		xpReward = 0;
		setNoAi(true);
		setPersistenceRequired();
		this.setPathfindingMalus(PathType.WATER, 0);
		this.moveControl = new MoveControl(this) {
			@Override
			public void tick() {
				if (BloomEntityEntity.this.isInWater())
					BloomEntityEntity.this.setDeltaMovement(BloomEntityEntity.this.getDeltaMovement().add(0, 0.005, 0));
				if (this.operation == MoveControl.Operation.MOVE_TO && !BloomEntityEntity.this.getNavigation().isDone()) {
					double dx = this.wantedX - BloomEntityEntity.this.getX();
					double dy = this.wantedY - BloomEntityEntity.this.getY();
					double dz = this.wantedZ - BloomEntityEntity.this.getZ();
					float f = (float) (Mth.atan2(dz, dx) * (double) (180 / Math.PI)) - 90;
					float f1 = (float) (this.speedModifier * BloomEntityEntity.this.getAttribute(Attributes.MOVEMENT_SPEED).getValue());
					BloomEntityEntity.this.setYRot(this.rotlerp(BloomEntityEntity.this.getYRot(), f, 10));
					BloomEntityEntity.this.yBodyRot = BloomEntityEntity.this.getYRot();
					BloomEntityEntity.this.yHeadRot = BloomEntityEntity.this.getYRot();
					if (BloomEntityEntity.this.isInWater()) {
						BloomEntityEntity.this.setSpeed((float) BloomEntityEntity.this.getAttribute(Attributes.MOVEMENT_SPEED).getValue());
						float f2 = -(float) (Mth.atan2(dy, (float) Math.sqrt(dx * dx + dz * dz)) * (180 / Math.PI));
						f2 = Mth.clamp(Mth.wrapDegrees(f2), -85, 85);
						BloomEntityEntity.this.setXRot(this.rotlerp(BloomEntityEntity.this.getXRot(), f2, 5));
						float f3 = Mth.cos(BloomEntityEntity.this.getXRot() * (float) (Math.PI / 180.0));
						BloomEntityEntity.this.setZza(f3 * f1);
						BloomEntityEntity.this.setYya((float) (f1 * dy));
					} else {
						BloomEntityEntity.this.setSpeed(f1 * 0.05F);
					}
				} else {
					BloomEntityEntity.this.setSpeed(0);
					BloomEntityEntity.this.setYya(0);
					BloomEntityEntity.this.setZza(0);
				}
			}
		};
	}

	@Override
	protected PathNavigation createNavigation(Level world) {
		return new WaterBoundPathNavigation(this, world);
	}

	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}

	@Override
	public void baseTick() {
		super.baseTick();
		BloomEntityUpdateProcedure.execute(this.level(), this.getX(), this.getY(), this.getZ(), this);
	}

	@Override
	public boolean checkSpawnObstruction(LevelReader world) {
		return world.isUnobstructed(this);
	}

	@Override
	public boolean canDrownInFluidType(FluidType type) {
		double x = this.getX();
		double y = this.getY();
		double z = this.getZ();
		Level world = this.level();
		Entity entity = this;
		return false;
	}

	public static void init(RegisterSpawnPlacementsEvent event) {
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0);
		builder = builder.add(Attributes.MAX_HEALTH, 6);
		builder = builder.add(Attributes.ARMOR, 0);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 0);
		builder = builder.add(Attributes.FOLLOW_RANGE, 16);
		builder = builder.add(Attributes.STEP_HEIGHT, 0);
		builder = builder.add(NeoForgeMod.SWIM_SPEED, 0);
		return builder;
	}
}