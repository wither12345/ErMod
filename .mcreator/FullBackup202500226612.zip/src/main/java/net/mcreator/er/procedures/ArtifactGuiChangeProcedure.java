package net.mcreator.er.procedures;

import net.minecraft.world.level.GameType;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.Minecraft;

import net.mcreator.er.init.ErModMenus;

public class ArtifactGuiChangeProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		ItemStack item = ItemStack.EMPTY;
		if (getEntityGameType(entity) == GameType.CREATIVE) {
			item = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(0).getItem() : ItemStack.EMPTY).copy();
			{
				final String _tagName = "main_attribute_name";
				final String _tagValue = ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(1).getItem() : ItemStack.EMPTY)
						.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getString("attribute_name"));
				CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putString(_tagName, _tagValue));
			}
			{
				final String _tagName = "main_attribute_count";
				final double _tagValue = ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(1).getItem() : ItemStack.EMPTY)
						.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("attribute_count"));
				CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putDouble(_tagName, _tagValue));
			}
			{
				final String _tagName = "main_attribute_multiplied";
				final boolean _tagValue = ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(1).getItem() : ItemStack.EMPTY)
						.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBoolean("multiplied"));
				CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putBoolean(_tagName, _tagValue));
			}
			{
				final String _tagName = "rarity";
				final double _tagValue = ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(6).getItem() : ItemStack.EMPTY).getCount() - 1);
				CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putDouble(_tagName, _tagValue));
			}
			for (int index = 2; index <= 5; index++) {
				{
					final String _tagName = ("minor_attribute_name_" + new java.text.DecimalFormat("##").format(index - 2));
					final String _tagValue = ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get((int) index).getItem() : ItemStack.EMPTY)
							.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getString("attribute_name"));
					CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putString(_tagName, _tagValue));
				}
				{
					final String _tagName = ("minor_attribute_count_" + new java.text.DecimalFormat("##").format(index - 2));
					final double _tagValue = ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get((int) index).getItem() : ItemStack.EMPTY)
							.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("attribute_count"));
					CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putDouble(_tagName, _tagValue));
				}
				{
					final String _tagName = ("minor_count_multiplier_" + new java.text.DecimalFormat("##").format(index - 2));
					final double _tagValue = ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get((int) index).getItem() : ItemStack.EMPTY)
							.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getDouble("count_multiplier"));
					CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putDouble(_tagName, _tagValue));
				}
				{
					final String _tagName = ("minor_attribute_multiplied_" + new java.text.DecimalFormat("##").format(index - 2));
					final boolean _tagValue = ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get((int) index).getItem() : ItemStack.EMPTY)
							.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag().getBoolean("multiplied"));
					CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putBoolean(_tagName, _tagValue));
				}
			}
			if (entity instanceof Player _player && _player.containerMenu instanceof ErModMenus.MenuAccessor _menu) {
				ItemStack _setstack = item.copy();
				_setstack.setCount(1);
				_menu.getSlots().get(0).set(_setstack);
				_player.containerMenu.broadcastChanges();
			}
			if (entity instanceof LivingEntity _entity) {
				ItemStack _setstack = item.copy();
				_setstack.setCount(1);
				_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
				if (_entity instanceof Player _player)
					_player.getInventory().setChanged();
			}
			{
				final String _tagName = "minor_upgrade_times";
				final double _tagValue = ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(7).getItem() : ItemStack.EMPTY).getCount());
				CustomData.update(DataComponents.CUSTOM_DATA, item, tag -> tag.putDouble(_tagName, _tagValue));
			}
		}
	}

	private static GameType getEntityGameType(Entity entity) {
		if (entity instanceof ServerPlayer serverPlayer) {
			return serverPlayer.gameMode.getGameModeForPlayer();
		} else if (entity instanceof Player player && player.level().isClientSide()) {
			PlayerInfo playerInfo = Minecraft.getInstance().getConnection().getPlayerInfo(player.getGameProfile().getId());
			if (playerInfo != null)
				return playerInfo.getGameMode();
		}
		return null;
	}
}