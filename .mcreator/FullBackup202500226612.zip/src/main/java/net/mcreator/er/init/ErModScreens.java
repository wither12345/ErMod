/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.er.client.gui.LeyLineMapGuiScreen;
import net.mcreator.er.client.gui.ErEquipmentGUIScreen;
import net.mcreator.er.client.gui.ElementAnvilGUIScreen;
import net.mcreator.er.client.gui.ArtifactGUIScreen;
import net.mcreator.er.client.gui.AlchemyCraftGuiScreen;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ErModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(ErModMenus.ER_EQUIPMENT_GUI.get(), ErEquipmentGUIScreen::new);
		event.register(ErModMenus.ARTIFACT_GUI.get(), ArtifactGUIScreen::new);
		event.register(ErModMenus.ELEMENT_ANVIL_GUI.get(), ElementAnvilGUIScreen::new);
		event.register(ErModMenus.ALCHEMY_CRAFT_GUI.get(), AlchemyCraftGuiScreen::new);
		event.register(ErModMenus.LEY_LINE_MAP_GUI.get(), LeyLineMapGuiScreen::new);
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}