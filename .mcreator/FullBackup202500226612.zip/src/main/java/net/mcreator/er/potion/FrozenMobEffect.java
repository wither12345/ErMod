package net.mcreator.er.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.mcreator.er.procedures.FrozenStartProcedure;

public class FrozenMobEffect extends MobEffect {
	public FrozenMobEffect() {
		super(MobEffectCategory.HARMFUL, -16711681);
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		FrozenStartProcedure.execute(entity);
	}
}