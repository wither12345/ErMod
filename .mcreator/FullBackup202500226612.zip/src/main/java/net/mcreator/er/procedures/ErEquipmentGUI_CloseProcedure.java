package net.mcreator.er.procedures;

import net.wither.er.network.ErItemVariables;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.er.init.ErModMenus;

public class ErEquipmentGUI_CloseProcedure {
	public static void execute(Entity entity) {
		String type = "";
		String uuid = "";
		double count = 0;
		ItemStack item = ItemStack.EMPTY;
		if (entity instanceof LivingEntity) {
			ErItemVariables.PlayerVariables _vars = entity.getData(ErItemVariables.PLAYER_VARIABLES);
			_vars.Vision = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(0).getItem() : ItemStack.EMPTY).copy();
			_vars.Stella_Fortuna = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(1).getItem() : ItemStack.EMPTY).copy();
			item = _vars.Flower_Of_Life.copy();
			ArtifactAttrRemoveProcedure.execute(entity, item);
			item = _vars.Plume_of_Death.copy();
			ArtifactAttrRemoveProcedure.execute(entity, item);
			item = _vars.Sands_Of_Eon.copy();
			ArtifactAttrRemoveProcedure.execute(entity, item);
			item = _vars.Goblet_Of_Eonothem.copy();
			ArtifactAttrRemoveProcedure.execute(entity, item);
			item = _vars.Circlet_Of_Logos.copy();
			ArtifactAttrRemoveProcedure.execute(entity, item);
			_vars.Flower_Of_Life = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(2).getItem() : ItemStack.EMPTY).copy();
			ArtifactAttrAddProcedure.execute(entity, _vars.Flower_Of_Life);
			_vars.Plume_of_Death = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(3).getItem() : ItemStack.EMPTY).copy();
			ArtifactAttrAddProcedure.execute(entity, _vars.Plume_of_Death);
			_vars.Sands_Of_Eon = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(4).getItem() : ItemStack.EMPTY).copy();
			ArtifactAttrAddProcedure.execute(entity, _vars.Sands_Of_Eon);
			_vars.Goblet_Of_Eonothem = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(5).getItem() : ItemStack.EMPTY).copy();
			ArtifactAttrAddProcedure.execute(entity, _vars.Goblet_Of_Eonothem);
			_vars.Circlet_Of_Logos = (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ErModMenus.MenuAccessor _menu ? _menu.getSlots().get(6).getItem() : ItemStack.EMPTY).copy();
			ArtifactAttrAddProcedure.execute(entity, _vars.Circlet_Of_Logos);
			_vars.syncPlayerVariables(entity);
		}
	}
}