package net.mcreator.er.procedures;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.er.ErMod;

public class LuckyDogStartProcedure {
	private static ResourceLocation resourcelocation = ResourceLocation.withDefaultNamespace("er.luckydog.armor");

	public static void execute(Entity entity, double amplifier) {
		if (entity == null)
			return;
		if (amplifier < 1) {
			((LivingEntity) entity).getAttribute(Attributes.ARMOR).removeModifier(new AttributeModifier(resourcelocation, 5, AttributeModifier.Operation.ADD_VALUE));
			return;
		}
		((LivingEntity) entity).getAttribute(Attributes.ARMOR).addOrUpdateTransientModifier(new AttributeModifier(resourcelocation, 5, AttributeModifier.Operation.ADD_VALUE));
	}
}