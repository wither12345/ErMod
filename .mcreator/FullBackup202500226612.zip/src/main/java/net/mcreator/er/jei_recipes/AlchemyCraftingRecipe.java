package net.mcreator.er.jei_recipes;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeInput;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.core.NonNullList;
import net.minecraft.core.HolderLookup;

import java.util.List;

import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.Codec;

public class AlchemyCraftingRecipe implements Recipe<RecipeInput> {
	private final ItemStack output;
	private final NonNullList<Ingredient> recipeItems;
	private final List<Integer> counts;

	public AlchemyCraftingRecipe(ItemStack output, NonNullList<Ingredient> recipeItems, List<Integer> counts) {
		this.output = output;
		this.recipeItems = recipeItems;
		this.counts = counts;
	}

	/*
		public AlchemyCraftingRecipe(ItemStack output, NonNullList<Ingredient> recipeItems) {
			this.output = output;
			this.recipeItems = recipeItems;
		}
	*/
	@Override
	public boolean matches(RecipeInput pContainer, Level pLevel) {
		if (pLevel.isClientSide()) {
			return false;
		}
		return false;
	}

	public int getCount(int i) {
		if (counts.size() <= i)
			return 0;
		return counts.get(i);
	}

	public List<Integer> getCounts() {
		return counts;
	}

	@Override
	public NonNullList<Ingredient> getIngredients() {
		return recipeItems;
	}

	@Override
	public ItemStack assemble(RecipeInput input, HolderLookup.Provider holder) {
		return output;
	}

	@Override
	public boolean canCraftInDimensions(int pWidth, int pHeight) {
		return true;
	}

	@Override
	public ItemStack getResultItem(HolderLookup.Provider provider) {
		return output.copy();
	}

	@Override
	public RecipeType<?> getType() {
		return Type.INSTANCE;
	}

	@Override
	public RecipeSerializer<?> getSerializer() {
		return Serializer.INSTANCE;
	}

	public static class Type implements RecipeType<AlchemyCraftingRecipe> {
		private Type() {
		}

		public static final RecipeType<AlchemyCraftingRecipe> INSTANCE = new Type();
	}

	public static class Serializer implements RecipeSerializer<AlchemyCraftingRecipe> {
		public static final Serializer INSTANCE = new Serializer();
		private static final MapCodec<AlchemyCraftingRecipe> CODEC = RecordCodecBuilder
				.mapCodec(builder -> builder.group(ItemStack.STRICT_CODEC.fieldOf("output").forGetter(recipe -> recipe.output), Ingredient.CODEC_NONEMPTY.listOf().fieldOf("ingredients").flatXmap(ingredients -> {
					Ingredient[] aingredient = ingredients.toArray(Ingredient[]::new); // Skip the empty check and create the array.
					if (aingredient.length == 0) {
						return DataResult.error(() -> "No ingredients found in custom recipe");
					} else {
						return DataResult.success(NonNullList.of(Ingredient.EMPTY, aingredient));
					}
				}, DataResult::success).forGetter(recipe -> recipe.recipeItems), Codec.INT.listOf().fieldOf("counts").forGetter(recipe -> recipe.counts)).apply(builder, AlchemyCraftingRecipe::new));
		public static final StreamCodec<RegistryFriendlyByteBuf, AlchemyCraftingRecipe> STREAM_CODEC = StreamCodec.of(Serializer::toNetwork, Serializer::fromNetwork);

		@Override
		public MapCodec<AlchemyCraftingRecipe> codec() {
			return CODEC;
		}

		@Override
		public StreamCodec<RegistryFriendlyByteBuf, AlchemyCraftingRecipe> streamCodec() {
			return STREAM_CODEC;
		}

		private static AlchemyCraftingRecipe fromNetwork(RegistryFriendlyByteBuf buf) {
			NonNullList<Ingredient> inputs = NonNullList.withSize(buf.readVarInt(), Ingredient.EMPTY);
			inputs.replaceAll(ingredients -> Ingredient.CONTENTS_STREAM_CODEC.decode(buf));
			NonNullList<Integer> count = NonNullList.withSize(buf.readVarInt(), Integer.valueOf(0));
			count.replaceAll(ingredients -> ByteBufCodecs.INT.decode(buf));
			return new AlchemyCraftingRecipe(ItemStack.STREAM_CODEC.decode(buf), inputs, count);
		}

		private static void toNetwork(RegistryFriendlyByteBuf buf, AlchemyCraftingRecipe recipe) {
			buf.writeVarInt(recipe.getIngredients().size());
			for (Ingredient ing : recipe.getIngredients()) {
				Ingredient.CONTENTS_STREAM_CODEC.encode(buf, ing);
			}
			buf.writeVarInt(recipe.getCounts().size());
			for (Integer i : recipe.counts) {
				ByteBufCodecs.INT.encode(buf, i);
			}
			ItemStack.STREAM_CODEC.encode(buf, recipe.getResultItem(null));
		}
	}
}
