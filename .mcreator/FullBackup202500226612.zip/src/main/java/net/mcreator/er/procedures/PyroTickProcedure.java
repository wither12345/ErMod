package net.mcreator.er.procedures;

public class PyroTickProcedure {
	public static void execute() {
	}
}