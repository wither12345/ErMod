package net.mcreator.er.item;

import net.minecraft.world.item.Item;

public class RarityGemstoneItem extends Item {
	public RarityGemstoneItem() {
		super(new Item.Properties().stacksTo(8));
	}
}