/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.neoforged.neoforge.client.event.RegisterParticleProvidersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.er.client.particle.SmallPyroParticleParticle;
import net.mcreator.er.client.particle.SmallHydroParticleParticle;
import net.mcreator.er.client.particle.SmallGeoParticleParticle;
import net.mcreator.er.client.particle.SmallElectroParticleParticle;
import net.mcreator.er.client.particle.SmallDendroParticleParticle;
import net.mcreator.er.client.particle.SmallCryoParticleParticle;
import net.mcreator.er.client.particle.SmallAnemoParticleParticle;
import net.mcreator.er.client.particle.PyroParticleParticle;
import net.mcreator.er.client.particle.PPyroParticle;
import net.mcreator.er.client.particle.PHydroParticle;
import net.mcreator.er.client.particle.PGeoParticle;
import net.mcreator.er.client.particle.PElectroParticle;
import net.mcreator.er.client.particle.PDendroParticle;
import net.mcreator.er.client.particle.PDendroExplosionParticle;
import net.mcreator.er.client.particle.PCryoParticle;
import net.mcreator.er.client.particle.PAnemoParticle;
import net.mcreator.er.client.particle.HydroParticleParticle;
import net.mcreator.er.client.particle.AnemoExplosionParticle;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ErModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(ErModParticleTypes.P_ANEMO.get(), PAnemoParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.P_CRYO.get(), PCryoParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.P_DENDRO.get(), PDendroParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.P_ELECTRO.get(), PElectroParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.P_GEO.get(), PGeoParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.P_HYDRO.get(), PHydroParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.P_PYRO.get(), PPyroParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.P_DENDRO_EXPLOSION.get(), PDendroExplosionParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.PYRO_PARTICLE.get(), PyroParticleParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.HYDRO_PARTICLE.get(), HydroParticleParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.SMALL_HYDRO_PARTICLE.get(), SmallHydroParticleParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.SMALL_ELECTRO_PARTICLE.get(), SmallElectroParticleParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.SMALL_PYRO_PARTICLE.get(), SmallPyroParticleParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.SMALL_CRYO_PARTICLE.get(), SmallCryoParticleParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.SMALL_DENDRO_PARTICLE.get(), SmallDendroParticleParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.SMALL_ANEMO_PARTICLE.get(), SmallAnemoParticleParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.SMALL_GEO_PARTICLE.get(), SmallGeoParticleParticle::provider);
		event.registerSpriteSet(ErModParticleTypes.ANEMO_EXPLOSION.get(), AnemoExplosionParticle::provider);
	}
}