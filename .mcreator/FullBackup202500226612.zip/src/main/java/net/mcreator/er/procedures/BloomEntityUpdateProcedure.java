package net.mcreator.er.procedures;

import net.wither.er.ErDamageSource;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;

import net.mcreator.er.init.ErModParticleTypes;
import net.mcreator.er.init.ErModAttributes;
import net.mcreator.er.EntityHurtEvent;

import java.util.List;
import java.util.Comparator;

public class BloomEntityUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		LivingEntity DMGentity = null;
		boolean find = false;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) > 0.05) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 114, false, false));
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth((float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getHealth() : -1) - 0.05));
			if (entity.getPersistentData().getInt("Pyro") > 0) {
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_DENDRO_EXPLOSION.get()), x, (y + 0.2), z, 1, 0, 0, 0, 0);
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(16 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (Entity entityiterator : _entfound) {
						if ((entityiterator.getStringUUID()).equals(entity.getPersistentData().getString("UUID")) && entityiterator instanceof LivingEntity living) {
							find = true;
							DMGentity = living;
						}
					}
				}
				if (find) {
					{
						final Vec3 _center = new Vec3(x, y, z);
						List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
						for (Entity entityiterator : _entfound) {
							if (entityiterator instanceof LivingEntity) {
								entityiterator.hurt(
										new ErDamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), DMGentity, 3, 0),
										7f * EntityHurtEvent.getElementalMasteryMultiply(1, DMGentity.getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue()));
							}
						}
					}
				} else {
					{
						final Vec3 _center = new Vec3(x, y, z);
						List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
						for (Entity entityiterator : _entfound) {
							if (entityiterator instanceof LivingEntity) {
								entityiterator.hurt(new ErDamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), 3, 0), 7f);
							}
						}
					}
				}
				entity.discard();
			} else if (entity.getPersistentData().getInt("Electro") > 0) {
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<LivingEntity> _entfound = world.getEntitiesOfClass(LivingEntity.class, new AABB(_center, _center).inflate(16 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (LivingEntity entityiterator : _entfound) {
						if ((entityiterator.getStringUUID()).equals(entity.getPersistentData().getString("UUID"))) {
							find = true;
							DMGentity = entityiterator;
						}
					}
				}
				if (find) {
					{
						final Vec3 _center = new Vec3(x, y, z);
						List<LivingEntity> _entfound = world.getEntitiesOfClass(LivingEntity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
								.toList();
						for (LivingEntity entityiterator : _entfound) {
							if (entityiterator != entity && EntityHurtEvent.shouldHurt(entityiterator, DMGentity)) {
								entityiterator.hurt(
										new ErDamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), DMGentity, 3, 0),
										6f * EntityHurtEvent.getElementalMasteryMultiply(1, DMGentity.getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue()));
								break;
							}
						}
					}
				} else {
					{
						final Vec3 _center = new Vec3(x, y, z);
						List<LivingEntity> _entfound = world.getEntitiesOfClass(LivingEntity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center)))
								.toList();
						for (LivingEntity entityiterator : _entfound) {
							if (entityiterator != entity) {
								entityiterator.hurt(new ErDamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), 3, 0), 6f);
								break;
							}
						}
					}
				}
				entity.discard();
			}
		} else {
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (ErModParticleTypes.P_DENDRO_EXPLOSION.get()), x, (y + 0.2), z, 1, 0, 0, 0, 0);
			{
				final Vec3 _center = new Vec3(x, y, z);
				List<LivingEntity> _entfound = world.getEntitiesOfClass(LivingEntity.class, new AABB(_center, _center).inflate(16 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
				for (LivingEntity entityiterator : _entfound) {
					if ((entityiterator.getStringUUID()).equals(entity.getPersistentData().getString("UUID"))) {
						find = true;
						DMGentity = entityiterator;
					}
				}
			}
			if (find) {
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<LivingEntity> _entfound = world.getEntitiesOfClass(LivingEntity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (LivingEntity entityiterator : _entfound) {
						entityiterator.hurt(new ErDamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), DMGentity, 3, 0),
								4f * EntityHurtEvent.getElementalMasteryMultiply(1, DMGentity.getAttribute(ErModAttributes.ELEMENTAL_MASTERY).getValue()));
					}
				}
			} else {
				{
					final Vec3 _center = new Vec3(x, y, z);
					List<LivingEntity> _entfound = world.getEntitiesOfClass(LivingEntity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList();
					for (LivingEntity entityiterator : _entfound) {
						entityiterator.hurt(new ErDamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, ResourceLocation.parse("er:reaction"))), 3, 0), 4f);
					}
				}
			}
			if (!entity.level().isClientSide())
				entity.discard();
		}
	}
}
