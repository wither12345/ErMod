package net.mcreator.er.client.gui;

import net.wither.er.network.LeyLineLeapData;

import net.neoforged.neoforge.network.PacketDistributor;

import net.minecraft.world.level.saveddata.maps.MapItemSavedData;
import net.minecraft.world.level.saveddata.maps.MapId;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.component.DataComponents;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.WidgetSprites;
import net.minecraft.client.gui.components.ImageButton;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.er.world.inventory.LeyLineMapGuiMenu;
import net.mcreator.er.item.LeyLineMapItem;
import net.mcreator.er.ErMod;

import javax.annotation.Nullable;

import java.util.Set;
import java.util.HashMap;
import java.util.ArrayList;

public class LeyLineMapGuiScreen extends AbstractContainerScreen<LeyLineMapGuiMenu> {
	private final static HashMap<String, Object> guistate = LeyLineMapGuiMenu.guistate;
	private final Level world;
	private final Player entity;
	private final ItemStack mapItem;
	ImageButton imagebutton_map_statue_of_the_seven;
	private final ArrayList<ImageButton> imagebuttons;

	public LeyLineMapGuiScreen(LeyLineMapGuiMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.entity = container.entity;
		this.mapItem = container.mapItem;
		this.imageWidth = 176;
		this.imageHeight = 166;
		imagebuttons = new ArrayList();
	}

	private static final ResourceLocation texture = ResourceLocation.parse("er:textures/screens/ley_line_map_gui.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics, mouseX, mouseY, partialTicks);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		Player player = this.menu.entity;
		if (mapItem.getItem() instanceof LeyLineMapItem) {
			MapId mapid = mapItem.get(DataComponents.MAP_ID);
			boolean flag = false;
			MapItemSavedData mapitemsaveddata;
			if (mapid != null) {
				mapitemsaveddata = MapItem.getSavedData(mapid, this.minecraft.level);
			} else {
				mapitemsaveddata = null;
			}
			this.renderMap(guiGraphics, mapid, mapitemsaveddata, this.leftPos, this.topPos, 1.5F);
		}
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
	}

	@Override
	public void init() {
		super.init();
		CompoundTag tag = mapItem.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
		Set<String> keys = tag.getCompound("WayPoints").getAllKeys();
		for (String key : keys) {
			String pos[] = key.split(",");
			MapItemSavedData data = MapItem.getSavedData(mapItem, world);
			int scale = 1 << data.scale;
			int posX = (Integer.parseInt(pos[0]) - tag.getInt("centerX")) * 3 / 2;
			int posZ = (Integer.parseInt(pos[2]) - tag.getInt("centerZ")) * 3 / 2;
			ImageButton button = new ImageButton(this.leftPos + posX / scale + 80, this.topPos + posZ / scale + 80, 16, 16,
					new WidgetSprites(ResourceLocation.parse("er:textures/screens/map_statue_of_the_seven.png"), ResourceLocation.parse("er:textures/screens/map_statue_of_the_sevent_hold.png")), e -> {
						PacketDistributor.sendToServer(new LeyLineLeapData(Integer.parseInt(pos[0]), Integer.parseInt(pos[1]), Integer.parseInt(pos[2])));
						//
					}) {
				@Override
				public void renderWidget(GuiGraphics guiGraphics, int x, int y, float partialTicks) {
					guiGraphics.pose().pushPose();
					guiGraphics.pose().translate(0.0F, 0.0F, 1.0F);
					guiGraphics.blit(sprites.get(isActive(), isHoveredOrFocused()), getX(), getY(), 0, 0, width, height, width, height);
					guiGraphics.pose().popPose();
				}
			};;
			imagebuttons.add(button);
			this.addRenderableWidget(button);
			//this.addRenderableWidget(button);
		}
	}

	private void renderMap(GuiGraphics graphics, @Nullable MapId id, @Nullable MapItemSavedData data, int x, int y, float scale) {
		if (id != null && data != null) {
			graphics.pose().pushPose();
			graphics.pose().translate((float) x, (float) y, 1.0F);
			graphics.pose().scale(scale, scale, 1.0F);
			this.minecraft.gameRenderer.getMapRenderer().render(graphics.pose(), graphics.bufferSource(), id, data, true, 15728880);
			//graphics.flush();
			graphics.pose().popPose();
		}
	}
}
