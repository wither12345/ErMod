
/*
*    MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.er.init;

import net.wither.er.entity.ArcEntity;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;

import net.mcreator.er.entity.TartagliaEntity;
import net.mcreator.er.entity.PyroCrystallizeEntity;
import net.mcreator.er.entity.MistFlowerEntity;
import net.mcreator.er.entity.HydroCrystallizeEntity;
import net.mcreator.er.entity.HilichurlEntity;
import net.mcreator.er.entity.FlamingFlowerEntity;
import net.mcreator.er.entity.FatuiElectroCicinMageEntity;
import net.mcreator.er.entity.ElementalProjectileEntity;
import net.mcreator.er.entity.ElectroCrystallizeEntity;
import net.mcreator.er.entity.ElectroCicinEntity;
import net.mcreator.er.entity.CryoCrystallizeEntity;
import net.mcreator.er.entity.BloomEntityEntity;
import net.mcreator.er.entity.AnemoCrystalflyEntity;
import net.mcreator.er.ErMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class ErModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, ErMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<BloomEntityEntity>> BLOOM_ENTITY = register("bloom_entity",
			EntityType.Builder.<BloomEntityEntity>of(BloomEntityEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).sized(0.4f, 0.4f));
	public static final DeferredHolder<EntityType<?>, EntityType<PyroCrystallizeEntity>> PYRO_CRYSTALLIZE = register("pyro_crystallize",
			EntityType.Builder.<PyroCrystallizeEntity>of(PyroCrystallizeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<CryoCrystallizeEntity>> CRYO_CRYSTALLIZE = register("cryo_crystallize",
			EntityType.Builder.<CryoCrystallizeEntity>of(CryoCrystallizeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<ElectroCrystallizeEntity>> ELECTRO_CRYSTALLIZE = register("electro_crystallize",
			EntityType.Builder.<ElectroCrystallizeEntity>of(ElectroCrystallizeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<HydroCrystallizeEntity>> HYDRO_CRYSTALLIZE = register("hydro_crystallize",
			EntityType.Builder.<HydroCrystallizeEntity>of(HydroCrystallizeEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).fireImmune().sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<MistFlowerEntity>> MIST_FLOWER = register("mist_flower",
			EntityType.Builder.<MistFlowerEntity>of(MistFlowerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).sized(0.6f, 0.9f));
	public static final DeferredHolder<EntityType<?>, EntityType<FlamingFlowerEntity>> FLAMING_FLOWER = register("flaming_flower",
			EntityType.Builder.<FlamingFlowerEntity>of(FlamingFlowerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).sized(0.6f, 0.9f));
	public static final DeferredHolder<EntityType<?>, EntityType<AnemoCrystalflyEntity>> ANEMO_CRYSTALFLY = register("anemo_crystalfly",
			EntityType.Builder.<AnemoCrystalflyEntity>of(AnemoCrystalflyEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).sized(0.5f, 0.3f));
	public static final DeferredHolder<EntityType<?>, EntityType<TartagliaEntity>> TARTAGLIA = register("tartaglia",
			EntityType.Builder.<TartagliaEntity>of(TartagliaEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<HilichurlEntity>> HILICHURL = register("hilichurl",
			EntityType.Builder.<HilichurlEntity>of(HilichurlEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<ElectroCicinEntity>> ELECTRO_CICIN = register("electro_cicin",
			EntityType.Builder.<ElectroCicinEntity>of(ElectroCicinEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).sized(0.5f, 0.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<ElementalProjectileEntity>> ELEMENTAL_PROJECTILE = register("elemental_projectile",
			EntityType.Builder.<ElementalProjectileEntity>of(ElementalProjectileEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<FatuiElectroCicinMageEntity>> FATUI_ELECTRO_CICIN_MAGE = register("fatui_electro_cicin_mage",
			EntityType.Builder.<FatuiElectroCicinMageEntity>of(FatuiElectroCicinMageEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).sized(0.6f, 1.8f));
	// Start of user code block custom entities
	public static final DeferredHolder<EntityType<?>, EntityType<ArcEntity>> ARC = register("arc",
			EntityType.Builder.<ArcEntity>of(ArcEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).sized(0.2f, 0.2f));

	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		BloomEntityEntity.init(event);
		PyroCrystallizeEntity.init(event);
		CryoCrystallizeEntity.init(event);
		ElectroCrystallizeEntity.init(event);
		HydroCrystallizeEntity.init(event);
		MistFlowerEntity.init(event);
		FlamingFlowerEntity.init(event);
		AnemoCrystalflyEntity.init(event);
		TartagliaEntity.init(event);
		HilichurlEntity.init(event);
		ElectroCicinEntity.init(event);
		FatuiElectroCicinMageEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(BLOOM_ENTITY.get(), BloomEntityEntity.createAttributes().build());
		event.put(PYRO_CRYSTALLIZE.get(), PyroCrystallizeEntity.createAttributes().build());
		event.put(CRYO_CRYSTALLIZE.get(), CryoCrystallizeEntity.createAttributes().build());
		event.put(ELECTRO_CRYSTALLIZE.get(), ElectroCrystallizeEntity.createAttributes().build());
		event.put(HYDRO_CRYSTALLIZE.get(), HydroCrystallizeEntity.createAttributes().build());
		event.put(MIST_FLOWER.get(), MistFlowerEntity.createAttributes().build());
		event.put(FLAMING_FLOWER.get(), FlamingFlowerEntity.createAttributes().build());
		event.put(ANEMO_CRYSTALFLY.get(), AnemoCrystalflyEntity.createAttributes().build());
		event.put(TARTAGLIA.get(), TartagliaEntity.createAttributes().build());
		event.put(HILICHURL.get(), HilichurlEntity.createAttributes().build());
		event.put(ELECTRO_CICIN.get(), ElectroCicinEntity.createAttributes().build());
		event.put(FATUI_ELECTRO_CICIN_MAGE.get(), FatuiElectroCicinMageEntity.createAttributes().build());
	}
}
