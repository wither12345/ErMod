
package net.mcreator.er.item;

import net.wither.er.network.ErCombatVariables;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.core.registries.Registries;
import net.minecraft.client.animation.AnimationDefinition;

import net.mcreator.er.client.model.animations.travelerAnimation;
import net.mcreator.er.StellaFortunas;

import java.util.stream.Collectors;
import java.util.List;
import java.util.Comparator;

public class TestStellaFortunaItem extends StellaFortunas {
	public TestStellaFortunaItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.RARE));
	}

	public void AbilityE(LevelAccessor world, Entity entity, double x, double y, double z) {
		final Vec3 _center = new Vec3(x, y, z);
		List<Entity> _entfound = world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(4 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).collect(Collectors.toList());
		for (Entity entityiterator : _entfound) {
			if (entityiterator != entity)
				entityiterator.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(DamageTypes.OUTSIDE_BORDER)), 128);
		}
	}

	public AnimationDefinition getAnimation(int combo) {
		if (combo == 10)
			return travelerAnimation.ChargedAttack;
		if (combo % 4 == 0)
			return travelerAnimation.NormalAttack1;
		if (combo % 4 == 1)
			return travelerAnimation.NormalAttack2;
		if (combo % 4 == 2)
			return travelerAnimation.NormalAttack3;
		return travelerAnimation.NormalAttack4;
	}

	public int getMaxCombo(LivingEntity entity) {
		return 5;
	}

	public boolean hasAnimation(LivingEntity entity) {
		return entity.getMainHandItem().getItem() instanceof SwordItem;
	}

	public int getAnimationTick(LivingEntity entity, int combo, float speed) {
		if (combo == 2)
			return (int) (29 / speed) + 1;
		return (int) (27 / speed) + 1;
	}

	public int getFinishTick(LivingEntity entity, int combo, float speed) {
		if (combo == 2)
			return (int) (18 / speed) + 1;
		return (int) (19 / speed) + 1;
	}

	public int getChargedAttackCost(LivingEntity entity) {
		return 20;
	}

	public void AnimationTicking(LivingEntity entity, int combo, double time, float speed) {
		if (combo == 10 && time == (int) (24 / speed) + 1) {
			PerformAttack(entity, 1, 2.2, 2.5, entity.getEyePosition(), DamageMulti(combo, 0));
		}
		if (combo == 2 & time == (int) (21 / speed) + 1)
			PerformAttack(entity, 1, 2.2, 2.5, entity.getEyePosition(), DamageMulti(2, 0));
		if (combo != 2 && time == (int) (22 / speed) + 1) {
			PerformAttack(entity, 1, 2.2, 2.5, entity.getEyePosition(), DamageMulti(combo, 1));
			/*
			Level world = entity.level();
			double d0 = (double) (-Mth.sin(entity.getYRot() * (float) (Math.PI / 180.0)));
			double d1 = (double) Mth.cos(entity.getYRot() * (float) (Math.PI / 180.0));
			SimpleParticleType particle = ParticleTypes.SWEEP_ATTACK;
			((ServerLevel) entity.level()).sendParticles(particle, entity.getX() + d0, entity.getY(0.6), entity.getZ() + d1, 0, d0, 0.0, d1, 0.0);
			Vec3 looking = entity.getLookAngle().multiply(1, 0, 1).normalize()
					//attack range
					.scale(entity.getAttributes().hasAttribute(Attributes.ENTITY_INTERACTION_RANGE) ? entity.getAttribute(Attributes.ENTITY_INTERACTION_RANGE).getValue() : 3);
			Vec3 startPos = entity.getEyePosition();
			Vec3 endPos = startPos.add(looking);
			AABB attackArea = new AABB(startPos, endPos).inflate(1, 1, 1).expandTowards(0, 1, 0);
			for (LivingEntity entityiterator : world.getEntitiesOfClass(LivingEntity.class, attackArea)) {
				entityiterator.hurt(new DamageSource(world.holderOrThrow(DamageTypes.GENERIC)), (float) entity.getAttribute(Attributes.ATTACK_DAMAGE).getValue() * DamageMulti(combo, 0));
			}
			for (double x : new double[]{attackArea.minX, attackArea.maxX}) {
				for (double y : new double[]{attackArea.minY, attackArea.maxY}) {
					for (double z : new double[]{attackArea.minZ, attackArea.maxZ}) {
						((ServerLevel) world).sendParticles(ParticleTypes.END_ROD, x, y, z, 1, 0, 0, 0, 0);
					}
				}
			}
			*/
		}
		if (time <= this.getFinishTick(entity, combo, speed) && combo <= this.getMaxCombo(entity) && entity.getPersistentData().getBoolean("WaitingChargeAttack")) {
			ErCombatVariables.PlayerVariables vars = entity.getData(ErCombatVariables.PLAYER_VARIABLES);
			if (vars.stamina >= this.getChargedAttackCost(entity)) {
				vars.stamina -= this.getChargedAttackCost(entity);
				vars.Combo = 10;
				vars.Animation_Time = this.getAnimationTick(entity, 10, speed);
				vars.staminaRecoveryCooldown = 50;
				vars.syncPlayerVariables(entity);
				entity.getPersistentData().putBoolean("WaitingChargeAttack", false);
			}
		}
	}

	public float DamageMulti(int combo, int index) {
		if (combo == 0)
			return 0.445f;
		else if (combo == 1)
			return 0.434f;
		else if (combo == 2)
			return 0.53f;
		else if (combo == 3)
			return 0.583f;
		else if (combo == 4)
			return 0.708f;
		else if (combo == 10)
			return index == 0 ? 0.559f : 0.772f;
		return 1;
	}

	public void AbilityQ(LevelAccessor world, Entity entity, double x, double y, double z) {
	}

	public void OnTick(LevelAccessor world, Entity entity, double x, double y, double z) {
	}
}
