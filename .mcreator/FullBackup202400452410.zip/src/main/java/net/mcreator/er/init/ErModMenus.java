
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.er.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.core.registries.Registries;

import net.mcreator.er.world.inventory.LeyLineMapGuiMenu;
import net.mcreator.er.world.inventory.ErEquipmentGUIMenu;
import net.mcreator.er.world.inventory.ElementAnvilGUIMenu;
import net.mcreator.er.world.inventory.ArtifactGUIMenu;
import net.mcreator.er.world.inventory.AlchemyCraftGuiMenu;
import net.mcreator.er.ErMod;

public class ErModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, ErMod.MODID);
	public static final DeferredHolder<MenuType<?>, MenuType<ErEquipmentGUIMenu>> ER_EQUIPMENT_GUI = REGISTRY.register("er_equipment_gui", () -> IMenuTypeExtension.create(ErEquipmentGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ArtifactGUIMenu>> ARTIFACT_GUI = REGISTRY.register("artifact_gui", () -> IMenuTypeExtension.create(ArtifactGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<ElementAnvilGUIMenu>> ELEMENT_ANVIL_GUI = REGISTRY.register("element_anvil_gui", () -> IMenuTypeExtension.create(ElementAnvilGUIMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<AlchemyCraftGuiMenu>> ALCHEMY_CRAFT_GUI = REGISTRY.register("alchemy_craft_gui", () -> IMenuTypeExtension.create(AlchemyCraftGuiMenu::new));
	public static final DeferredHolder<MenuType<?>, MenuType<LeyLineMapGuiMenu>> LEY_LINE_MAP_GUI = REGISTRY.register("ley_line_map_gui", () -> IMenuTypeExtension.create(LeyLineMapGuiMenu::new));
}
