/**
 * The code of this mod element is always locked.
 *
 * You can register new events in this class too.
 *
 * If you want to make a plain independent class, create it using
 * Project Browser -> New... and make sure to make the class
 * outside net.mcreator.er as this package is managed by MCreator.
 *
 * If you change workspace package, modid or prefix, you will need
 * to manually adapt this file to these changes or remake it.
 *
 * This class will be added in the mod root package.
*/
package net.mcreator.er;

import org.checkerframework.checker.units.qual.t;
import org.checkerframework.checker.units.qual.min;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.client.animation.AnimationDefinition;

import java.util.Properties;

public abstract class StellaFortunas extends Item {
	public StellaFortunas(Properties properties) {
		super(properties.stacksTo(1));
	}

	public abstract void AbilityE(LevelAccessor world, Entity entity, double x, double y, double z);

	public abstract void AbilityQ(LevelAccessor world, Entity entity, double x, double y, double z);

	public abstract void OnTick(LevelAccessor world, Entity entity, double x, double y, double z);

	public abstract boolean hasAnimation(LivingEntity entity);

	public abstract int getMaxCombo(LivingEntity entity);

	public abstract int getAnimationTick(LivingEntity entity, int combo, float speed);

	public abstract void AnimationTicking(LivingEntity entity, int combo, double time, float speed);

	public abstract int getFinishTick(LivingEntity entity, int combo, float speed);

	public abstract AnimationDefinition getAnimation(int combo);

	public boolean vision(ItemStack item) {
		return true;
	}

	/*
		public static void PerformAttack(LivingEntity entity, double RangeMulti, double RectWidth, double RectHeight, float DamageMulti) {
			Level world = entity.level();
			double attackRange = (entity instanceof Player ? entity.getAttributeValue(Attributes.ENTITY_INTERACTION_RANGE) : 3) * RangeMulti;
			Vec3 lookVec = entity.getLookAngle().normalize();
			Vec3 eyePos = entity.getEyePosition();
			Vec3 forward = lookVec.scale(attackRange);
			Vec3 right = new Vec3(-lookVec.z, 0, lookVec.x).normalize().scale(RectWidth / 2);
			Vec3 up = new Vec3(0, RectHeight / 2, 0);
			Vec3[] corners = {eyePos.add(forward).add(right).add(up), eyePos.add(forward).add(right).subtract(up), eyePos.add(forward).subtract(right).add(up), eyePos.add(forward).subtract(right).subtract(up)};
			AABB roughArea = new AABB(eyePos, eyePos.add(forward)).inflate(RectWidth + 1, RectHeight + 1, RectWidth + 1);
			for (LivingEntity target : world.getEntitiesOfClass(LivingEntity.class, roughArea, e -> e != entity && isInRotatedRect(e.position(), eyePos, lookVec, attackRange, RectWidth, RectHeight))) {
				float damage = (float) entity.getAttributeValue(Attributes.ATTACK_DAMAGE) * DamageMulti;
				target.hurt(entity.damageSources().mobAttack(entity), damage);
			}
			if (world instanceof ServerLevel serverLevel) {
				Vec3 _forward = lookVec.scale(attackRange);
				Vec3 _right = new Vec3(-lookVec.z, 0, lookVec.x).normalize().scale(RectWidth / 2);
				Vec3 _up = new Vec3(0, RectHeight / 2, 0);
				for (int i = 0; i < 20; i++) {
					double t = i / 20.0;
					Vec3 p1 = eyePos.add(_forward.scale(t)).add(_right).add(_up);
					Vec3 p2 = eyePos.add(_forward.scale(t)).add(_right).subtract(_up);
					Vec3 p3 = eyePos.add(_forward.scale(t)).subtract(_right).add(_up);
					Vec3 p4 = eyePos.add(_forward.scale(t)).subtract(_right).subtract(_up);
					serverLevel.sendParticles(ParticleTypes.END_ROD, p1.x, p1.y, p1.z, 1, 0, 0, 0, 0);
					serverLevel.sendParticles(ParticleTypes.END_ROD, p2.x, p2.y, p2.z, 1, 0, 0, 0, 0);
					serverLevel.sendParticles(ParticleTypes.END_ROD, p3.x, p3.y, p3.z, 1, 0, 0, 0, 0);
					serverLevel.sendParticles(ParticleTypes.END_ROD, p4.x, p4.y, p4.z, 1, 0, 0, 0, 0);
				}
			}
		}
		private static boolean isInRotatedRect(Vec3 point, Vec3 origin, Vec3 direction, double length, double width, double height) {
			Vec3 localPos = point.subtract(origin);
			double forwardDist = localPos.dot(direction);
			if (forwardDist < 0 || forwardDist > length)
				return false;
			Vec3 right = new Vec3(-direction.z, 0, direction.x).normalize();
			double sideDist = Math.abs(localPos.dot(right));
			if (sideDist > width / 2)
				return false;
			double verticalDist = localPos.y;
			return verticalDist >= -height / 2 && verticalDist <= height / 2;
		}
		*/
	public static void PerformAttack(LivingEntity entity, double RangeMulti, double RectWidth, double RectHeight, Vec3 BasicPos, float DamageMulti) {
		Level world = entity.level();
		double attackRange = (entity instanceof Player ? entity.getAttributeValue(Attributes.ENTITY_INTERACTION_RANGE) : 3) * RangeMulti;
		// 获取水平方向向量（仅考虑yaw）
		float yaw = entity.getYRot();
		Vec3 lookVec = new Vec3(-Math.sin(yaw * Math.PI / 180), 0, Math.cos(yaw * Math.PI / 180)).normalize();
		Vec3 forward = lookVec.scale(attackRange);
		AABB roughArea = new AABB(BasicPos, BasicPos.add(forward)).inflate(RectWidth + 1, RectHeight + 1, RectWidth + 1);
		for (LivingEntity target : world.getEntitiesOfClass(LivingEntity.class, roughArea, e -> {
			if (e == entity)
				return false;
			AABB targetAABB = e.getBoundingBox().move(BasicPos.scale(-1)); // 转换到局部坐标系
			return isAABBInRotatedRect(targetAABB, lookVec, attackRange, RectWidth, RectHeight);
		})) {
			float damage = (float) entity.getAttributeValue(Attributes.ATTACK_DAMAGE) * DamageMulti;
			if (entity instanceof Player player)
				target.hurt(entity.damageSources().playerAttack(player), damage);
			else
				target.hurt(entity.damageSources().mobAttack(entity), damage);
		}
		if (world instanceof ServerLevel serverLevel) {
			Vec3 _forward = lookVec.scale(attackRange);
			Vec3 _right = new Vec3(-lookVec.z, 0, lookVec.x).normalize().scale(RectWidth / 2);
			Vec3 _up = new Vec3(0, RectHeight / 2, 0);
			for (int i = 0; i < 20; i++) {
				double t = i / 20.0;
				Vec3 p1 = BasicPos.add(_forward.scale(t)).add(_right).add(_up);
				Vec3 p2 = BasicPos.add(_forward.scale(t)).add(_right).subtract(_up);
				Vec3 p3 = BasicPos.add(_forward.scale(t)).subtract(_right).add(_up);
				Vec3 p4 = BasicPos.add(_forward.scale(t)).subtract(_right).subtract(_up);
				serverLevel.sendParticles(ParticleTypes.END_ROD, p1.x, p1.y, p1.z, 1, 0, 0, 0, 0);
				serverLevel.sendParticles(ParticleTypes.END_ROD, p2.x, p2.y, p2.z, 1, 0, 0, 0, 0);
				serverLevel.sendParticles(ParticleTypes.END_ROD, p3.x, p3.y, p3.z, 1, 0, 0, 0, 0);
				serverLevel.sendParticles(ParticleTypes.END_ROD, p4.x, p4.y, p4.z, 1, 0, 0, 0, 0);
			}
		}
	}

	private static boolean isAABBInRotatedRect(AABB aabb, Vec3 direction, double length, double width, double height) {
		Vec3 right = new Vec3(-direction.z, 0, direction.x).normalize();
		Vec3 up = new Vec3(0, 1, 0);
		double[] forwardProj = getAABBProjection(aabb, direction);
		if (forwardProj[1] < 0 || forwardProj[0] > length)
			return false;
		double[] rightProj = getAABBProjection(aabb, right);
		if (rightProj[1] < -width / 2 || rightProj[0] > width / 2)
			return false;
		double[] upProj = getAABBProjection(aabb, up);
		return !(upProj[1] < -height / 2) && !(upProj[0] > height / 2);
	}

	private static double[] getAABBProjection(AABB aabb, Vec3 axis) {
		double min = (axis.x > 0 ? aabb.minX : aabb.maxX) * axis.x + (axis.y > 0 ? aabb.minY : aabb.maxY) * axis.y + (axis.z > 0 ? aabb.minZ : aabb.maxZ) * axis.z;
		double max = (axis.x > 0 ? aabb.maxX : aabb.minX) * axis.x + (axis.y > 0 ? aabb.maxY : aabb.minY) * axis.y + (axis.z > 0 ? aabb.maxZ : aabb.minZ) * axis.z;
		return new double[]{min, max};
	}
}
