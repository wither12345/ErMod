package net.wither.er.mixins;

import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import net.wither.er.client.models.AnimatedPlayerModel;

import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.model.PlayerModel;


@Mixin(PlayerRenderer.class)
public abstract class PlayerRendererMixin extends LivingEntityRenderer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
	@Inject(method = "<init>", at = @At("TAIL"))
	private void onInit(EntityRendererProvider.Context context, boolean slim, CallbackInfo info) {
		this.model = new AnimatedPlayerModel(context.bakeLayer(slim ? AnimatedPlayerModel.SLIM_LAYER_LOCATION : AnimatedPlayerModel.LAYER_LOCATION), slim);
	}

	public PlayerRendererMixin(EntityRendererProvider.Context context, boolean slim) {
		super(context, new AnimatedPlayerModel(context.bakeLayer(slim ? AnimatedPlayerModel.SLIM_LAYER_LOCATION : AnimatedPlayerModel.LAYER_LOCATION), slim), 0.5f);
	}
}
