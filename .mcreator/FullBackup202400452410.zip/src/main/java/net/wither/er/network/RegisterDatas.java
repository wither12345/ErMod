package net.wither.er.network;

import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.network.handling.DirectionalPayloadHandler;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class RegisterDatas {
	@SubscribeEvent
	public static void Register(final RegisterPayloadHandlersEvent event) {
		final PayloadRegistrar registrar = event.registrar("1"); // All subsequent payloads will register on the network thread
		registrar.playBidirectional(ErShieldData.TYPE, ErShieldData.STREAM_CODEC, new DirectionalPayloadHandler<>(ErShieldData::handle, ErShieldData::handle));
		registrar.playBidirectional(LeyLineLeapData.TYPE, LeyLineLeapData.STREAM_CODEC, new DirectionalPayloadHandler<>(LeyLineLeapData::handle, LeyLineLeapData::handle));
	}
}
